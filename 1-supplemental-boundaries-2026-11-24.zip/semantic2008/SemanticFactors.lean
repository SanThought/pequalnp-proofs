import Mathlib.Order.Monotone.Basic
import Mathlib.Data.Bool.Basic
import Mathlib.Tactic.Tauto

namespace SemanticCross2008
variable {P L : Type*}

def LineSensitive (f : (P → Bool) → (L → Bool) → Bool) : Prop :=
  ∃ x, f x (fun _ => false) ≠ f x (fun _ => true)
def PointSensitive (f : (P → Bool) → (L → Bool) → Bool) : Prop :=
  ∃ y, f (fun _ => false) y ≠ f (fun _ => true) y

theorem line_invariant (f : (P → Bool) → (L → Bool) → Bool)
    (mono : ∀ x, Monotone (f x)) (quiet : ¬ LineSensitive f) :
    ∀ x y z, f x y = f x z := by
  intro x y z
  have endpoints : f x (fun _ => false) = f x (fun _ => true) := by
    by_contra h
    exact quiet ⟨x,h⟩
  have lowY := mono x (show (fun _ : L => false) ≤ y from fun _ => Bool.false_le _)
  have highY := mono x (show y ≤ (fun _ : L => true) from fun _ => Bool.le_true _)
  have lowZ := mono x (show (fun _ : L => false) ≤ z from fun _ => Bool.false_le _)
  have highZ := mono x (show z ≤ (fun _ : L => true) from fun _ => Bool.le_true _)
  exact (le_antisymm (endpoints ▸ highY) lowY).trans
    (le_antisymm (endpoints ▸ highZ) lowZ).symm

theorem point_invariant (f : (P → Bool) → (L → Bool) → Bool)
    (mono : ∀ y, Monotone (fun x => f x y)) (quiet : ¬ PointSensitive f) :
    ∀ x z y, f x y = f z y := by
  intro x z y
  exact line_invariant (fun y x => f x y) mono quiet y x z

theorem no_cross_pure_factors
    (f g : (P → Bool) → (L → Bool) → Bool)
    (crossFree : ¬ ((LineSensitive f ∧ LineSensitive g) ∨
      (PointSensitive f ∧ PointSensitive g))) :
    (¬ LineSensitive f ∨ ¬ LineSensitive g) ∧
    (¬ PointSensitive f ∨ ¬ PointSensitive g) := by
  tauto

theorem nonconstant_pure_factor_pair
    (f g : (P → Bool) → (L → Bool) → Bool)
    (fNonconstant : LineSensitive f ∨ PointSensitive f)
    (gNonconstant : LineSensitive g ∨ PointSensitive g)
    (crossFree : ¬ ((LineSensitive f ∧ LineSensitive g) ∨
      (PointSensitive f ∧ PointSensitive g))) :
    (PointSensitive f ∧ ¬ LineSensitive f ∧ LineSensitive g ∧ ¬ PointSensitive g) ∨
    (LineSensitive f ∧ ¬ PointSensitive f ∧ PointSensitive g ∧ ¬ LineSensitive g) := by
  tauto
end SemanticCross2008
#print axioms SemanticCross2008.line_invariant
#print axioms SemanticCross2008.nonconstant_pure_factor_pair
