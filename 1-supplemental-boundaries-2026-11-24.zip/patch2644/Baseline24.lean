import PEqualNP.Defs
import Mathlib.Tactic.NormNum
namespace Patch2644
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
def baseline : Circuit := ⟨[
⟨.or, [5, 9]⟩,
⟨.or, [17, 14]⟩,
⟨.or, [18, 16]⟩,
⟨.and, [0, 19]⟩,
⟨.or, [5, 6]⟩,
⟨.or, [21, 10]⟩,
⟨.or, [22, 15]⟩,
⟨.and, [1, 23]⟩,
⟨.or, [6, 7]⟩,
⟨.or, [25, 11]⟩,
⟨.or, [26, 16]⟩,
⟨.and, [2, 27]⟩,
⟨.or, [5, 7]⟩,
⟨.or, [29, 8]⟩,
⟨.or, [30, 12]⟩,
⟨.and, [3, 31]⟩,
⟨.or, [6, 8]⟩,
⟨.or, [33, 9]⟩,
⟨.or, [34, 13]⟩,
⟨.and, [4, 35]⟩,
⟨.or, [20, 24]⟩,
⟨.or, [37, 28]⟩,
⟨.or, [38, 32]⟩,
⟨.or, [39, 36]⟩], 40⟩
set_option maxRecDepth 10000 in
set_option maxHeartbeats 0 in
theorem budget24 : ∃ (x1 : PEqualNP.CircuitLowerBounds.Circuit),   PEqualNP.MetaComplexity.Monotone2 x1 ∧     PEqualNP.MetaComplexity.NestedCover.ReadsBack (17 : ℕ) x1 ∧       x1.size ≤ (24 : ℕ) ∧         (∀ x2 ∈ [(33 : ℕ), (513 : ℕ), (16385 : ℕ), (65537 : ℕ), (34 : ℕ), (66 : ℕ), (1026 : ℕ), (32770 : ℕ), (68 : ℕ), (132 : ℕ), (2052 : ℕ), (65540 : ℕ), (40 : ℕ), (136 : ℕ), (264 : ℕ), (4104 : ℕ), (80 : ℕ), (272 : ℕ), (528 : ℕ), (8208 : ℕ)], (PEqualNP.MetaComplexity.circuitFun (17 : ℕ) x1 fun (x4 : Fin (17 : ℕ)) => x2.testBit ↑x4) = Bool.true) ∧           ∀             x2 ∈               have x3 : List ℕ :=                 have x3 : List ℕ :=                   have x3 : List ℕ := [(92682 : ℕ), (97154 : ℕ), (117784 : ℕ), (122032 : ℕ), (126536 : ℕ), (131040 : ℕ)];                   (58892 : ℕ) :: (63268 : ℕ) :: (67610 : ℕ) :: (81946 : ℕ) :: (88210 : ℕ) :: x3;                 have x4 : List ℕ := (40973 : ℕ) :: (44105 : ℕ) :: (46341 : ℕ) :: (48577 : ℕ) :: (49180 : ℕ) :: (54324 : ℕ) :: x3;                 (29446 : ℕ) :: (33821 : ℕ) :: (34841 : ℕ) :: (36885 : ℕ) :: (40081 : ℕ) :: x4;               have x4 : List ℕ :=                 have x4 : List ℕ := (16414 : ℕ) :: (16910 : ℕ) :: (17436 : ℕ) :: (18458 : ℕ) :: (20502 : ℕ) :: (24590 : ℕ) :: x3;                 (8718 : ℕ) :: (9229 : ℕ) :: (10251 : ℕ) :: (12295 : ℕ) :: (14723 : ℕ) :: x4;               have x5 : List ℕ := (4243 : ℕ) :: (4359 : ℕ) :: (5141 : ℕ) :: (6163 : ℕ) :: (8207 : ℕ) :: (8455 : ℕ) :: x4;               (31 : ℕ) :: (2075 : ℕ) :: (2195 : ℕ) :: (3097 : ℕ) :: (4119 : ℕ) :: x5,             (PEqualNP.MetaComplexity.circuitFun (17 : ℕ) x1 fun (x4 : Fin (17 : ℕ)) => x2.testBit ↑x4) = Bool.false := by
  refine ⟨baseline, ?_, ?_, ?_, ?_, ?_⟩
  · intro g hg
    simp only [baseline, List.mem_cons, List.not_mem_nil, or_false] at hg
    rcases hg with h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h <;> subst g <;> norm_num
  · unfold NestedCover.ReadsBack NestedCover.gateAt
    change ∀ j < 24, ∀ i ∈ (baseline.gates.getD j ⟨.or, []⟩).inputs, i < 17 + j
    decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
end Patch2644
#print axioms Patch2644.budget24
