import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Fintype.Powerset
import Mathlib.Tactic.Tauto

namespace IndependentCompletion2644
variable {P L : Type*} [Fintype L] [DecidableEq P] [DecidableEq L]
variable (I : P → L → Prop) [DecidableRel I]

def completion (A : Finset P) : Finset L :=
  Finset.univ.filter (fun l => ∀ p ∈ A, ¬ I p l)

theorem independent_subset_completion (A : Finset P) (B : Finset L)
    (indep : ∀ p ∈ A, ∀ l ∈ B, ¬ I p l) : B ⊆ completion I A := by
  intro l hl
  simp only [completion, Finset.mem_filter, Finset.mem_univ, true_and]
  exact fun p hp => indep p hp l hl

theorem completed_input_independent (A : Finset P) :
    ∀ p ∈ A, ∀ l ∈ completion I A, ¬ I p l := by
  intro p hp l hl
  exact (Finset.mem_filter.mp hl).2 p hp

theorem monotone_tests_reduce_to_completions
    (F : Finset P → Finset L → Prop)
    (mono : ∀ A B D, B ⊆ D → F A B → F A D)
    (tests : Finset P → Prop)
    (reject : ∀ A, tests A → ¬ F A (completion I A)) :
    ∀ A B, tests A → (∀ p ∈ A, ∀ l ∈ B, ¬ I p l) → ¬ F A B := by
  intro A B htest indep accepted
  exact reject A htest (mono A B (completion I A)
    (independent_subset_completion I A B indep) accepted)
end IndependentCompletion2644
#print axioms IndependentCompletion2644.monotone_tests_reduce_to_completions
