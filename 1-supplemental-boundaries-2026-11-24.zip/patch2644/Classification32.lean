import Mathlib.Data.List.FinRange
import PEqualNP.Defs
namespace Patch2644
def positives : List Nat := [33, 513, 16385, 65537, 34, 66, 1026, 32770, 68, 132, 2052, 65540, 40, 136, 264, 4104, 80, 272, 528, 8208]
def negatives : List Nat := [92682, 97154, 117784, 122032, 126536, 131040, 58892, 63268, 67610, 81946, 88210, 40973, 44105, 46341, 48577, 49180, 54324, 29446, 33821, 34841, 36885, 40081, 16414, 16910, 17436, 18458, 20502, 24590, 8718, 9229, 10251, 12295, 14723, 4243, 4359, 5141, 6163, 8207, 8455, 31, 2075, 2195, 3097, 4119]
def exceptions : List Nat := [6291, 12551, 25102, 35865, 37909, 41997, 50204, 83994]
def completions : List Nat := [131040, 48577, 97154, 14723, 63268, 46341, 29446, 12551, 126536, 44105, 92682, 10251, 58892, 41997, 25102, 8207, 122032, 40081, 88210, 6291, 54324, 37909, 20502, 4119, 117784, 35865, 83994, 2075, 50204, 33821, 16414, 31]
set_option maxRecDepth 10000 in
set_option maxHeartbeats 0 in
theorem completed_masks_classified : ∀ m ∈ completions,
    (∃ y ∈ negatives, Nat.land m y = m) ∨ m ∈ exceptions := by
  decide +kernel
end Patch2644
#print axioms Patch2644.completed_masks_classified
