import PEqualNP.Defs
namespace Gct232
noncomputable section

def p0 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,1,2,3] (by decide)
def p1 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,1,3,2] (by decide)
def p2 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,2,1,3] (by decide)
def p3 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,2,3,1] (by decide)
def p4 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,3,1,2] (by decide)
def p5 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,3,2,1] (by decide)
def p6 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,0,2,3] (by decide)
def p7 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,0,3,2] (by decide)
def p8 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,2,0,3] (by decide)
def p9 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,2,3,0] (by decide)
def p10 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,3,0,2] (by decide)
def p11 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,3,2,0] (by decide)
def p12 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,0,1,3] (by decide)
def p13 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,0,3,1] (by decide)
def p14 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,1,0,3] (by decide)
def p15 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,1,3,0] (by decide)
def p16 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,3,0,1] (by decide)
def p17 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,3,1,0] (by decide)
def p18 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,0,1,2] (by decide)
def p19 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,0,2,1] (by decide)
def p20 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,1,0,2] (by decide)
def p21 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,1,2,0] (by decide)
def p22 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,2,0,1] (by decide)
def p23 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,2,1,0] (by decide)

lemma all_perms : (Finset.univ : Finset (Equiv.Perm (Fin 4))) = {p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23} := by decide

lemma permanent_four (M : Matrix (Fin 4) (Fin 4) ℂ) :
    M.permanent =
    M 0 0 * M 1 1 * M 2 2 * M 3 3 +
    M 0 0 * M 1 1 * M 3 2 * M 2 3 +
    M 0 0 * M 2 1 * M 1 2 * M 3 3 +
    M 0 0 * M 2 1 * M 3 2 * M 1 3 +
    M 0 0 * M 3 1 * M 1 2 * M 2 3 +
    M 0 0 * M 3 1 * M 2 2 * M 1 3 +
    M 1 0 * M 0 1 * M 2 2 * M 3 3 +
    M 1 0 * M 0 1 * M 3 2 * M 2 3 +
    M 1 0 * M 2 1 * M 0 2 * M 3 3 +
    M 1 0 * M 2 1 * M 3 2 * M 0 3 +
    M 1 0 * M 3 1 * M 0 2 * M 2 3 +
    M 1 0 * M 3 1 * M 2 2 * M 0 3 +
    M 2 0 * M 0 1 * M 1 2 * M 3 3 +
    M 2 0 * M 0 1 * M 3 2 * M 1 3 +
    M 2 0 * M 1 1 * M 0 2 * M 3 3 +
    M 2 0 * M 1 1 * M 3 2 * M 0 3 +
    M 2 0 * M 3 1 * M 0 2 * M 1 3 +
    M 2 0 * M 3 1 * M 1 2 * M 0 3 +
    M 3 0 * M 0 1 * M 1 2 * M 2 3 +
    M 3 0 * M 0 1 * M 2 2 * M 1 3 +
    M 3 0 * M 1 1 * M 0 2 * M 2 3 +
    M 3 0 * M 1 1 * M 2 2 * M 0 3 +
    M 3 0 * M 2 1 * M 0 2 * M 1 3 +
    M 3 0 * M 2 1 * M 1 2 * M 0 3 := by
  unfold Matrix.permanent
  rw [all_perms]
  norm_num [Finset.sum_insert, Finset.sum_singleton, Fin.prod_univ_succ, Equiv.ext_iff, Fin.forall_fin_succ, Equiv.coe_ofBijective, p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23]
  <;> ring



def diagonalLine (z : ℂ) : Matrix (Fin 4) (Fin 4) ℂ :=
  !![-Complex.I*z,-z,Complex.I*z,z;-z,-Complex.I*z,z,Complex.I*z;Complex.I*z,z,-z,-Complex.I*z;z,Complex.I*z,-Complex.I*z,-z]
lemma diagonalLine_level (z : ℂ) : Matrix.permanent (Matrix.of fun r c => 1+diagonalLine z r c) = 24 := by
  rw [permanent_four]
  norm_num [diagonalLine,Matrix.of_apply]
  ring_nf
  norm_num [Complex.I_sq]
  ring
lemma diagonalLine_nonzero_diagonal : diagonalLine 1 2 2 ≠ 0 := by
  norm_num [diagonalLine]
end
end Gct232
#print axioms Gct232.diagonalLine_level
