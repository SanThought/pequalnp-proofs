# A permanent-level direction with nonzero diagonals

November 24, 2026. A checked boundary example, not a solution of L-gct-232.

For every complex z, the following symmetric matrix T(z) satisfies permanent(J+T(z))=24:

    [-iz  -z   iz   z]
    [ -z -iz    z  iz]
    [ iz   z   -z -iz]
    [  z  iz  -iz  -z]

Here i is the imaginary unit and J is the all-ones matrix. The diagonal is not identically zero: T(1)[2,2] = -1. Thus it would be wrong to remove the zero-diagonal restriction in our sharp dimension theorem by asserting that every valid direction has zero diagonal.

`DiagonalLine.lean` proves the permanent identity for every complex z and a nonzero diagonal entry at z=1. `diagline2.log` records a successful Lean 4.36.0 check, with only propext, Classical.choice and Quot.sound. No sorry or new axiom is used. The matrix depends on only one scalar, so this example is not the requested three-dimensional space and does not refute the probe.

The proved general bounds remain 2 ≤ maximum possible dimension ≤ 4:
https://github.com/SanThought/pequalnp-proofs/commit/54ea6729ae9e2b13acd4269b927b434b44dcd9df

The sharp bound of 2 for zero-diagonal subspaces remains valid:
https://github.com/SanThought/pequalnp-proofs/commit/c974db9cfdb39f232ea45cc1908028f1ac96be69

No upstream proof submission or accepted credit is claimed.
