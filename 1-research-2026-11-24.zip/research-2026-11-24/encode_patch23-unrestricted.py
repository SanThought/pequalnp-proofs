import json,itertools
p=json.load(open('./patch-analysis.json')); rows=p['rows'];pick=p['pick'];lines=p['lines']
samples=[((1<<a)|(1<<(5+lines.index(l))),True) for a,l in p['positives']]+[(r,False) for r in rows]
n=17;t=23;clauses=[];nv=0
def var():
 global nv
 nv+=1;return nv
def onehot(xs):
 clauses.append(xs)
 for i in range(len(xs)):
  for j in range(i):clauses.append([-xs[i],-xs[j]])
vals=[[var() for _ in range(n+t)] for _ in samples];gates=[]
for r,(bits,target) in enumerate(samples):
 for i in range(n):clauses.append([vals[r][i] if bits>>i&1 else -vals[r][i]])
 clauses.append([vals[r][-1] if target else -vals[r][-1]])
for g in range(t):
 k=n+g;sa=[var() for _ in range(k)];sb=[var() for _ in range(k)];op=var();onehot(sa);onehot(sb)
 # Ordered operands, disallow redundant repeated-input gates except final padding? Can safely allow.
 for a in range(k):
  for b in range(a):clauses.append([-sa[a],-sb[b]])
 gates.append((sa,sb,op))
 for r in range(len(samples)):
  a=var();b=var();z=vals[r][k]
  for i in range(k):
   v=vals[r][i]
   clauses.extend([[-sa[i],-a,v],[-sa[i],a,-v],[-sb[i],-b,v],[-sb[i],b,-v]])
  # op=true AND, op=false OR.
  clauses.extend([[-op,-z,a],[-op,-z,b],[-op,z,-a,-b],[op,z,-a],[op,z,-b],[op,-z,a,b]])
with open('./patch23.cnf','w') as f:
 f.write(f'p cnf {nv} {len(clauses)}\n')
 for c in clauses:f.write(' '.join(map(str,c))+' 0\n')
json.dump({'gates':gates,'n':n,'t':t,'samples':samples},open('./patch23-map.json','w'))
print('variables',nv,'clauses',len(clauses),'samples',len(samples))
