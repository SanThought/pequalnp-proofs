import json,random,time,math
p=json.load(open('./patch-alt.json'));n=len(p['pick']);lines=p['lines'];k=5
samples=[(1<<a)|(1<<(k+lines.index(l))) for a,l in p['positives']]+p['rows'];target=(1<<len(p['positives']))-1
inputs=[sum(((r>>i)&1)<<j for j,r in enumerate(samples)) for i in range(n)]
g=[]
for a in range(k):
 ls=[k+lines.index(l) for b,l in p['positives'] if b==a];s=ls[0]
 for x in ls[1:]:g.append((1,s,x));s=n+len(g)-1
 g.append((0,a,s))
s=n+3
for a in range(1,k):g.append((1,s,n+4*a+3));s=n+len(g)-1
assert len(g)==24
best=100;start=time.time();count=0;witness=None
def evaluate(gs):
 v=inputs.copy()
 for op,a,b in gs:v.append(v[a]|v[b] if op else v[a]&v[b])
 return (v[-1]^target).bit_count()
def drop(gs,d,operand):
 out=[]
 for i,(op,a,b) in enumerate(gs):
  if i==d:continue
  def rep(x):
   if x==n+d:x=gs[d][operand]
   return x-1 if x>n+d else x
  out.append((op,rep(a),rep(b)))
 return out
while time.time()-start<175:
 d=random.randrange(23);gs=drop(g,d,random.choice([1,2]));score=evaluate(gs)
 for it in range(2500):
  count+=1;i=random.randrange(23);old=gs[i];op,a,b=old;q=random.randrange(5)
  if q==0:op=1-op
  elif q<3:a=random.randrange(n+i)
  else:b=random.randrange(n+i)
  gs[i]=(op,a,b);new=evaluate(gs);temp=.2+.6*(1-it/2500)
  if new<=score or random.random()<math.exp((score-new)/temp):score=new
  else:gs[i]=old
  if score<best:
   best=score;print('besterrors',best,'iterations',count,'elapsed',round(time.time()-start,1),flush=True)
   json.dump({'n':n,'gates':gs,'errors':score,'samples':samples,'target':target},open('./stochastic-best.json','w'))
  if score==0:witness=gs;break
 if witness:break
print('finished',best,count,round(time.time()-start,1))
