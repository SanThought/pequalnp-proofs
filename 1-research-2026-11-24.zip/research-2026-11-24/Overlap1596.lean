import PEqualNP.Defs.CircuitLowerBounds
import Mathlib.Data.Fintype.Pi
import Mathlib.Tactic.FinCases

namespace Overlap1596
open PEqualNP.CircuitLowerBounds

def C : Circuit := ⟨[
  ⟨.and,[2,3]⟩, ⟨.not,[7]⟩, ⟨.or,[0,1]⟩,
  ⟨.and,[9,8]⟩, ⟨.or,[4,5]⟩, ⟨.and,[11,2]⟩,
  ⟨.or,[10,12]⟩, ⟨.or,[9,2]⟩, ⟨.or,[11,6]⟩], 14⟩

def val (x : Fin 7 → Bool) (w : ℕ) : Bool := (C.wires (List.ofFn x)).getD w false

def light : Finset (Fin 7) := Finset.univ.filter fun p => val (fun i => decide (i = p)) 13

def heavy : Finset (Fin 7) := Finset.univ.filter fun p => p ∉ ({2,3} : Finset (Fin 7)) ∧
  val (fun i => decide (i ∈ ({2,3} : Finset (Fin 7)) ∨ i = p)) 13

set_option maxRecDepth 10000 in
set_option maxHeartbeats 0 in
lemma supports : light = {0,1} ∧ heavy = {4,5} := by decide +kernel

set_option maxRecDepth 10000 in
set_option maxHeartbeats 0 in
lemma outputs : ∀ x : Fin 7 → Bool,
    val x 14 = (x 0 || x 1 || x 2) ∧ val x 15 = (x 4 || x 5 || x 6) := by
  decide +kernel

set_option maxRecDepth 10000 in
set_option maxHeartbeats 0 in
lemma not_minimum : (∀ x : Fin 7 → Bool,
    (Finset.univ.filter fun p => x p = true).card < 2 → val x 8 = true) ∧
    val (fun p => decide (p ∈ ({2,3} : Finset (Fin 7)))) 8 = false := by
  decide +kernel

end Overlap1596

namespace Overlap1596
open PEqualNP.CircuitLowerBounds

def D : Circuit := ⟨C.gates ++ List.replicate 5 ⟨.or,[13,13]⟩,14⟩
def dval (x : Fin 7 → Bool) (w : ℕ) : Bool := (D.wires (List.ofFn x)).getD w false

def ls (j : Fin 14) : Finset (Fin 7) :=
  Finset.univ.filter fun p => dval (fun i => decide (i = p)) (7+j) = true

def hs (j : Fin 14) : Finset (Fin 7) :=
  Finset.univ.filter fun p => p ∉ ({2,3} : Finset (Fin 7)) ∧
    dval (fun i => decide (i ∈ ({2,3} : Finset (Fin 7)) ∨ i = p)) (7+j) = true

def ag : Finset (Fin 14) := Finset.univ.filter fun j =>
  ls j ⊆ {0,1,2} ∧ 2 ≤ (ls j).card

def bg : Finset (Fin 14) := Finset.univ.filter fun j =>
  hs j ⊆ {4,5,6} ∧ 2 ≤ (hs j).card

def refunds : Finset (Fin 14) := Finset.univ.filter fun j =>
  (ls j = {0,1,2} ∨ ls j = {4,5,6}) ∧ hs j = {4,5,6}

set_option maxRecDepth 10000 in
set_option maxHeartbeats 0 in
lemma raw_count_fails : ag.card = 9 ∧ bg.card = 9 ∧ refunds.card = 1 ∧
    D.size = 14 ∧ D.size + refunds.card < ag.card + bg.card := by
  decide +kernel

end Overlap1596
#print axioms Overlap1596.raw_count_fails
#print axioms Overlap1596.outputs
#print axioms Overlap1596.supports
#print axioms Overlap1596.not_minimum
