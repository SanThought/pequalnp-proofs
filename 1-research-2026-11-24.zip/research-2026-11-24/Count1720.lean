import Mathlib.Data.Fintype.Card
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Lean.Elab.Tactic.Omega

namespace Count1720

lemma split_cost {G : Type*} [Fintype G] [DecidableEq G]
    (x y m : Finset G) (sx sy : ℕ)
    (hxy : Disjoint x y) (hxm : Disjoint x m) (hym : Disjoint y m)
    (hx : sx ≤ x.card + 3*m.card) (hy : sy ≤ y.card + 2*m.card) :
    sx + sy ≤ 5 * Fintype.card G := by
  have h1 : (x ∪ y).card = x.card + y.card := Finset.card_union_of_disjoint hxy
  have h2 : Disjoint (x ∪ y) m := Finset.disjoint_union_left.mpr ⟨hxm,hym⟩
  have h3 := Finset.card_union_of_disjoint h2
  have h4 := Finset.card_le_univ ((x ∪ y) ∪ m)
  omega

lemma reverse_budget (adds scales copies inputs live : ℕ)
    (hedges : live ≤ 2*adds + scales + copies + 1)
    (hvertices : adds + scales + copies + inputs ≤ live) :
    inputs ≤ adds + 1 := by omega

end Count1720
#print axioms Count1720.split_cost
