import json,itertools,random,time
p=json.load(open('./patch-analysis.json'));lines=p['lines']
samples=[((1<<a)|(1<<(5+lines.index(l))),True) for a,l in p['positives']]+[(r,False) for r in p['rows']]
mask=(1<<len(samples))-1
inputs=[sum(1<<j for j,(r,t) in enumerate(samples) if r>>i&1) for i in range(17)]
pos=(1<<20)-1;neg=mask^pos
base=json.load(open('./baseline24.json'))
def values(gs):
 w=inputs[:]
 for op,(a,b) in gs:w.append(w[a]&w[b] if op=='and' else w[a]|w[b])
 return w
def prune(gs,out):
 need={out}
 for i in reversed(range(len(gs))):
  if 17+i in need:need.update(gs[i][1])
 mp={i:i for i in range(17)};ret=[]
 for i,(op,(a,b)) in enumerate(gs):
  if 17+i in need:
   mp[17+i]=17+len(ret);ret.append((op,[mp[a],mp[b]]))
 return ret,mp[out]
# Every single gate replacement by a smaller-depth expression from prior wires.
# Each trial recomputes the entire suffix and validates all64rows independently.
tested=0;best=24;found=None
for g in range(24):
 for a in range(17+g):
  for b in range(a,17+g):
   for op in ['and','or']:
    gs=list(base['gates']);gs[g]=(op,[a,b]);w=values(gs);out=base['output'];tested+=1
    if (w[out]&pos)==pos and not w[out]&neg:
     ret,o=prune(gs,out)
     if len(ret)<best:
      best=len(ret);found={'n':17,'gates':ret,'output':o,'replaced_gate':g,'replacement':[op,a,b]};print('improvement',best,found,flush=True)
print(json.dumps({'tested':tested,'best':best,'found':found}))
if found:json.dump(found,open('./local-witness.json','w'),indent=2)
