import Mathlib.Data.Finset.Card
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Data.Fintype.Card
import Lean.Elab.Tactic.Omega

namespace GroupBudget1720

lemma partition_group_cost {H : Type*} [DecidableEq H]
    (all left right : Finset H) (tx ty tm cx cy gx gy : ℕ)
    (hdis : Disjoint left right) (hunion : left ∪ right ⊆ all)
    (hboundary : all.card ≤ 2*tm)
    (hcx : cx ≤ tx+3*tm) (hcy : cy ≤ ty)
    (hgx : gx ≤ left.card) (hgy : gy ≤ right.card) :
    cx+cy+gx+gy ≤ tx+ty+5*tm := by
  have hcard := Finset.card_le_card hunion
  rw [Finset.card_union_of_disjoint hdis] at hcard
  omega

lemma grouping_cost {I H : Type*} [DecidableEq H] [DecidableEq I]
    (s : Finset I) (groups : I → Finset H)
    (hdis : (s : Set I).PairwiseDisjoint groups) :
    (∑ i ∈ s, ((groups i).card-1)) ≤ (s.biUnion groups).card := by
  rw [Finset.card_biUnion hdis]
  exact Finset.sum_le_sum (fun i hi => Nat.sub_le _ _)

end GroupBudget1720
#print axioms GroupBudget1720.partition_group_cost
#print axioms GroupBudget1720.grouping_cost
