import Mathlib.Data.Fintype.Basic
import Mathlib.Order.Monotone.Basic

namespace RectanglePreparation1720

variable {P L H : Type*}

lemma base_false (F : (P → Bool) → (L → Bool) → Prop)
    (B : (P → Bool) → Prop) (A : H → (P → Bool) → Prop)
    (V : H → (L → Bool) → Prop)
    (decomp : ∀ x y, F x y ↔ B x ∨ ∃ h, A h x ∧ V h y)
    (zero : ∀ x, ¬ F x (fun _ => false)) : ∀ x, ¬ B x := by
  intro x hb
  exact zero x ((decomp x (fun _ => false)).mpr (Or.inl hb))

lemma rectangle_sound (F : (P → Bool) → (L → Bool) → Prop)
    (B : (P → Bool) → Prop) (A : H → (P → Bool) → Prop)
    (V : H → (L → Bool) → Prop) (I : P → L → Prop)
    (small : (L → Bool) → Prop)
    (decomp : ∀ x y, F x y ↔ B x ∨ ∃ h, A h x ∧ V h y)
    (sound : ∀ x y, small y → F x y → ∃ p l, I p l ∧ x p = true ∧ y l = true) :
    ∀ h x y, small y → A h x → V h y → ∃ p l, I p l ∧ x p = true ∧ y l = true := by
  intro h x y hy ha hv
  exact sound x y hy ((decomp x y).mpr (Or.inr ⟨h,ha,hv⟩))

lemma unit_rectangle {P L H : Type*} [DecidableEq P] [DecidableEq L]
    (F : (P → Bool) → (L → Bool) → Prop)
    (B : (P → Bool) → Prop) (A : H → (P → Bool) → Prop)
    (V : H → (L → Bool) → Prop) (I : P → L → Prop)
    (decomp : ∀ x y, F x y ↔ B x ∨ ∃ h, A h x ∧ V h y)
    (sound : ∀ x y, F x y → ∃ p l, I p l ∧ x p = true ∧ y l = true) :
    ∀ h p l, A h (fun i => decide (i = p)) →
      V h (fun i => decide (i = l)) → I p l := by
  intro h p l ha hv
  obtain ⟨p',l',hi,hp,hl⟩ := sound _ _ ((decomp _ _).mpr (Or.inr ⟨h,ha,hv⟩))
  simp only [decide_eq_true_eq] at hp hl
  simpa only [hp,hl] using hi

end RectanglePreparation1720
#print axioms RectanglePreparation1720.unit_rectangle
