import Mathlib.Data.Finset.Card
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Lean.Elab.Tactic.Omega

namespace Transpose1720

variable {W : Type*} [DecidableEq W]

-- Each instruction replaces one destination by an OR of selected predecessor values.
-- Selection includes whichever scalar coefficients are true for the fixed point input.
def push (dst : W) (pred : Finset W) (state : W → Prop) (w : W) : Prop :=
  if w = dst then ∃ p ∈ pred, state p else state w

def pull (dst : W) (pred : Finset W) (demand : W → Prop) (w : W) : Prop :=
  (w ≠ dst ∧ demand w) ∨ (demand dst ∧ w ∈ pred)

lemma step (dst : W) (pred : Finset W) (state demand : W → Prop) :
    (∃ w, demand w ∧ push dst pred state w) ↔
    ∃ w, pull dst pred demand w ∧ state w := by
  constructor
  · rintro ⟨w,hd,hv⟩
    by_cases hw : w = dst
    · subst w
      obtain ⟨p,hp,hs⟩ := (if_pos rfl).mp hv
      exact ⟨p,Or.inr ⟨hd,hp⟩,hs⟩
    · exact ⟨w,Or.inl ⟨hw,hd⟩,by simpa [push,hw] using hv⟩
  · rintro ⟨w,(⟨hw,hd⟩ | ⟨hd,hp⟩),hs⟩
    · exact ⟨w,hd,by simpa [push,hw] using hs⟩
    · exact ⟨dst,hd,by simp only [push,ite_true]; exact ⟨w,hp,hs⟩⟩

def forward (ops : List (W × Finset W)) (state : W → Prop) : W → Prop :=
  ops.foldl (fun s op => push op.1 op.2 s) state

def backward (ops : List (W × Finset W)) (demand : W → Prop) : W → Prop :=
  ops.foldr (fun op s => pull op.1 op.2 s) demand

lemma transpose (ops : List (W × Finset W)) (state demand : W → Prop) :
    (∃ w, demand w ∧ forward ops state w) ↔
    ∃ w, backward ops demand w ∧ state w := by
  induction ops generalizing state with
  | nil => rfl
  | cons op ops ih =>
    change (∃ w, demand w ∧ forward ops (push op.1 op.2 state) w) ↔
      ∃ w, pull op.1 op.2 (backward ops demand) w ∧ state w
    exact (ih _).trans (step _ _ _ _)

lemma coefficient (ops : List (W × Finset W)) (src dst : W) :
    forward ops (fun w => w = src) dst ↔ backward ops (fun w => w = dst) src := by
  simpa using transpose ops (fun w => w = src) (fun w => w = dst)

end Transpose1720
#print axioms Transpose1720.coefficient
