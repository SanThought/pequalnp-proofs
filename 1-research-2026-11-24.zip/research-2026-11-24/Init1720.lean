import PEqualNP.Defs.LineDegree
import Mathlib.Algebra.Order.BigOperators.Group.List
import PEqualNP.Defs.MetaComplexityLgpMono
import Mathlib.Data.List.FinRange
import Lean.Elab.Tactic.Omega

namespace Extract1720
open PEqualNP.CircuitLowerBounds

def run (gs : List Gate) (x : List Bool) : List Bool :=
  gs.foldl (fun w g => w ++ [g.op.eval (g.inputs.map fun i => w.getD i false)]) x

lemma length_run (gs : List Gate) (x : List Bool) : (run gs x).length=x.length+gs.length := by
  induction gs generalizing x with
  | nil => simp [run]
  | cons g gs ih =>
    change (run gs (x++[g.op.eval (g.inputs.map fun i => x.getD i false)])).length=_
    rw [ih];simp;omega

lemma run_old (gs : List Gate) (x : List Bool) (w : ℕ) (hw : w<x.length) :
    (run gs x).getD w false=x.getD w false := by
  induction gs generalizing x with
  | nil => rfl
  | cons g gs ih =>
    change (run gs (x++[g.op.eval (g.inputs.map fun i => x.getD i false)])).getD w false=_
    rw [ih _ (by simp;omega),List.getD_append _ _ _ _ hw]

-- Mapping length is the number of original wires already processed.
-- A missing map entry means that wire is omitted from the extracted circuit.
def step (m : ℕ) (keep : Bool) (acc : List (Option ℕ) × List Gate) (g : Gate) :
    List (Option ℕ) × List Gate :=
  if keep then
    (acc.1++[some (m+acc.2.length)],acc.2++[⟨g.op,g.inputs.map fun w => (acc.1.getD w none).getD 0⟩])
  else (acc.1++[none],acc.2)

lemma step_map_length (m : ℕ) (b : Bool) (acc : List (Option ℕ) × List Gate) (g : Gate) :
    (step m b acc g).1.length=acc.1.length+1 := by cases b <;> simp [step]

lemma step_size (m : ℕ) (b : Bool) (acc : List (Option ℕ) × List Gate) (g : Gate) :
    (step m b acc g).2.length=acc.2.length+(if b then 1 else 0) := by cases b <;> simp [step]

lemma step_map_old (m : ℕ) (b : Bool) (acc : List (Option ℕ) × List Gate) (g : Gate)
    (w : ℕ) (hw : w<acc.1.length) :
    (step m b acc g).1.getD w none=acc.1.getD w none := by
  cases b <;> simp only [step,Bool.false_eq_true,ite_false,ite_true]
  all_goals exact List.getD_append _ _ _ _ hw

lemma rename_eval (g : Gate) (map : List (Option ℕ)) (old new : List Bool)
    (defined : ∀ w∈g.inputs, ∃ r, map.getD w none=some r ∧ new.getD r false=old.getD w false) :
    g.op.eval ((g.inputs.map fun w => (map.getD w none).getD 0).map fun r => new.getD r false) =
      g.op.eval (g.inputs.map fun w => old.getD w false) := by
  congr 1
  rw [List.map_map]
  apply List.map_congr_left
  intro w hw
  obtain ⟨r,hr,hv⟩ := defined w hw
  change new.getD ((map.getD w none).getD 0) false = old.getD w false
  rw [hr]
  exact hv

end Extract1720
#print axioms Extract1720.rename_eval

namespace Extract1720
open PEqualNP.CircuitLowerBounds

def Valid (m : ℕ) (acc : List (Option ℕ) × List Gate) : Prop :=
  ∀ w r, acc.1.getD w none=some r → r<m+acc.2.length

def Agrees (acc : List (Option ℕ) × List Gate) (old new : List Bool) : Prop :=
  ∀ w r, acc.1.getD w none=some r → new.getD r false=old.getD w false

lemma valid_step (m : ℕ) (b : Bool) (acc : List (Option ℕ) × List Gate) (g : Gate)
    (h : Valid m acc) : Valid m (step m b acc g) := by
  intro w r hr
  cases b
  · change (acc.1++[none]).getD w none=some r at hr
    change r<m+acc.2.length
    by_cases hw : w<acc.1.length
    · rw [List.getD_append _ _ _ _ hw] at hr
      exact h w r hr
    · have hge : acc.1.length ≤ w := by omega
      rw [List.getD_append_right _ _ _ _ hge] at hr
      have : ([none] : List (Option ℕ)).getD (w-acc.1.length) none=none := by
        cases w-acc.1.length <;> simp
      rw [this] at hr
      contradiction
  · change (acc.1++[some (m+acc.2.length)]).getD w none=some r at hr
    change r<m+(acc.2++[_]).length
    by_cases hw : w<acc.1.length
    · rw [List.getD_append _ _ _ _ hw] at hr
      have hh := h w r hr
      simp;omega
    · have hge : acc.1.length ≤ w := by omega
      rw [List.getD_append_right _ _ _ _ hge] at hr
      by_cases he : w=acc.1.length
      · subst w
        simp at hr
        subst r
        simp
      · have hn : 1 ≤ w-acc.1.length := by omega
        rw [List.getD_eq_default _ _ (by simp;omega)] at hr
        contradiction

end Extract1720
#print axioms Extract1720.valid_step

namespace Extract1720
open PEqualNP.CircuitLowerBounds

lemma getD_append_ne {A : Type*} (l : List A) (a d : A) (w : ℕ) (hw : w≠l.length) :
    (l++[a]).getD w d=l.getD w d := by
  by_cases hlt : w<l.length
  · exact List.getD_append _ _ _ _ hlt
  · rw [List.getD_eq_default _ _ (by simp;omega),List.getD_eq_default _ _ (by omega)]

lemma agrees_step (m : ℕ) (b : Bool) (acc : List (Option ℕ) × List Gate)
    (g : Gate) (old new : List Bool)
    (hlen : acc.1.length=old.length) (hnew : new.length=m+acc.2.length)
    (valid : Valid m acc) (agree : Agrees acc old new)
    (defined : b=true → ∀ w∈g.inputs, ∃ r, acc.1.getD w none=some r) :
    let next := step m b acc g
    let old' := old++[g.op.eval (g.inputs.map fun w => old.getD w false)]
    let extra := next.2.drop acc.2.length
    Agrees next old' (run extra new) := by
  dsimp only
  intro w r hr
  cases b
  · change (acc.1++[none]).getD w none=some r at hr
    change (run (acc.2.drop acc.2.length) new).getD r false = _
    rw [List.drop_length]
    change new.getD r false = _
    have hw : w≠acc.1.length := by intro he; subst w; simp at hr
    rw [getD_append_ne _ _ _ _ hw] at hr
    rw [getD_append_ne _ _ _ _ (by omega)]
    exact agree w r hr
  · let g' : Gate := ⟨g.op,g.inputs.map fun w => (acc.1.getD w none).getD 0⟩
    change (acc.1++[some (m+acc.2.length)]).getD w none=some r at hr
    change (run ((acc.2++[g']).drop acc.2.length) new).getD r false = _
    rw [List.drop_left]
    have hv : g'.op.eval (g'.inputs.map fun r => new.getD r false) =
        g.op.eval (g.inputs.map fun w => old.getD w false) := by
      dsimp only [g']
      apply rename_eval g acc.1 old new
      intro w hw
      obtain ⟨r,hr⟩ := defined rfl w hw
      exact ⟨r,hr,agree w r hr⟩
    change (new++[g'.op.eval (g'.inputs.map fun r => new.getD r false)]).getD r false = _
    by_cases hw : w=acc.1.length
    · subst w
      simp at hr
      subst r
      rw [List.getD_append_right _ _ _ _ (by omega),
        List.getD_append_right _ _ _ _ (by omega)]
      simp only [← hnew,← hlen,Nat.sub_self,List.getD_cons_zero]
      exact hv
    · rw [getD_append_ne _ _ _ _ hw] at hr
      have hrlt := valid w r hr
      rw [List.getD_append _ _ _ _ (by omega),getD_append_ne _ _ _ _ (by omega)]
      exact agree w r hr

end Extract1720
#print axioms Extract1720.agrees_step

namespace Extract1720
open PEqualNP.CircuitLowerBounds

def pass (m : ℕ) : List (Bool × Gate) → List (Option ℕ) × List Gate → List (Option ℕ) × List Gate
  | [],acc => acc
  | (b,g)::gs,acc => pass m gs (step m b acc g)

lemma pass_size (m : ℕ) (gs : List (Bool × Gate)) (acc : List (Option ℕ) × List Gate) :
    (pass m gs acc).2.length=acc.2.length+(gs.filter fun bg => bg.1).length := by
  induction gs generalizing acc with
  | nil => simp [pass]
  | cons bg gs ih =>
    rcases bg with ⟨b,g⟩
    rw [pass,ih,step_size]
    cases b <;> simp <;> omega

lemma pass_map_length (m : ℕ) (gs : List (Bool × Gate)) (acc : List (Option ℕ) × List Gate) :
    (pass m gs acc).1.length=acc.1.length+gs.length := by
  induction gs generalizing acc with
  | nil => simp [pass]
  | cons bg gs ih => rw [pass,ih,step_map_length];simp;omega

lemma pass_valid (m : ℕ) (gs : List (Bool × Gate)) (acc : List (Option ℕ) × List Gate)
    (h : Valid m acc) : Valid m (pass m gs acc) := by
  induction gs generalizing acc with
  | nil => exact h
  | cons bg gs ih => exact ih _ (valid_step m bg.1 acc bg.2 h)

end Extract1720
#print axioms Extract1720.pass_size
#print axioms Extract1720.pass_valid

namespace Extract1720
open PEqualNP.CircuitLowerBounds

lemma step_extends (m : ℕ) (b : Bool) (acc : List (Option ℕ) × List Gate) (g : Gate) :
    ∃ e, (step m b acc g).2=acc.2++e := by
  cases b
  · exact ⟨[],by simp [step]⟩
  · exact ⟨[_],rfl⟩

lemma step_uses (m : ℕ) (b : Bool) (acc : List (Option ℕ) × List Gate) (g : Gate)
    (valid : Valid m acc)
    (defined : b=true → ∀ w∈g.inputs,∃ r,acc.1.getD w none=some r) :
    ∀ h∈(step m b acc g).2.drop acc.2.length,∀ w∈h.inputs,w<m+acc.2.length := by
  cases b
  · simp [step]
  · intro h hh w hw
    simp only [step,ite_true,List.drop_left,List.mem_singleton] at hh
    subst h
    obtain ⟨a,ha,rfl⟩ := List.mem_map.mp hw
    obtain ⟨r,hr⟩ := defined rfl a ha
    change (acc.1.getD a none).getD 0 < m+acc.2.length
    rw [hr]
    exact valid a r hr

lemma step_basis (m : ℕ) (b : Bool) (acc : List (Option ℕ) × List Gate) (g : Gate)
    (hg : (g.op=GateOp.and ∨ g.op=GateOp.or) ∧ g.inputs.length=2)
    (hold : ∀ h∈acc.2,(h.op=GateOp.and ∨ h.op=GateOp.or) ∧ h.inputs.length=2) :
    ∀ h∈(step m b acc g).2,(h.op=GateOp.and ∨ h.op=GateOp.or) ∧ h.inputs.length=2 := by
  cases b
  · exact hold
  · intro h hh
    rcases List.mem_append.mp hh with hh | hh
    · exact hold h hh
    · simp only [List.mem_singleton] at hh
      subst h
      exact ⟨hg.1,by simpa using hg.2⟩

end Extract1720
#print axioms Extract1720.step_uses
#print axioms Extract1720.step_basis

namespace Extract1720
open PEqualNP.CircuitLowerBounds

lemma run_append (gs hs : List Gate) (x : List Bool) : run (gs++hs) x=run hs (run gs x) := by
  simp [run,List.foldl_append]

def Ready (m : ℕ) : List (Bool × Gate) → List (Option ℕ) × List Gate → Prop
  | [],_ => True
  | (b,g)::gs,acc =>
    (b=true → ∀ w∈g.inputs,∃ r,acc.1.getD w none=some r) ∧ Ready m gs (step m b acc g)

lemma pass_agrees (m : ℕ) (gs : List (Bool × Gate)) (acc : List (Option ℕ) × List Gate)
    (old input : List Bool) (hin : input.length=m)
    (hlen : acc.1.length=old.length) (valid : Valid m acc)
    (agree : Agrees acc old (run acc.2 input)) (ready : Ready m gs acc) :
    Agrees (pass m gs acc) (run (gs.map Prod.snd) old) (run (pass m gs acc).2 input) := by
  induction gs generalizing acc old with
  | nil => exact agree
  | cons bg gs ih =>
    obtain ⟨defined,ready'⟩ := ready
    let next := step m bg.1 acc bg.2
    have hnlen : next.1.length=(old++[bg.2.op.eval (bg.2.inputs.map fun w => old.getD w false)]).length := by
      rw [step_map_length];simp [hlen]
    have ha := agrees_step m bg.1 acc bg.2 old (run acc.2 input) hlen
      (by simp [length_run,hin]) valid agree defined
    have hrun : run (next.2.drop acc.2.length) (run acc.2 input)=run next.2 input := by
      obtain ⟨e,he⟩ := step_extends m bg.1 acc bg.2
      change run (next.2.drop acc.2.length) (run acc.2 input)=_
      change next.2=acc.2++e at he
      rw [he,List.drop_left,run_append]
    change Agrees next _ (run (next.2.drop acc.2.length) (run acc.2 input)) at ha
    rw [hrun] at ha
    exact ih next _ hnlen (valid_step m bg.1 acc bg.2 valid) ha ready'

end Extract1720
#print axioms Extract1720.pass_agrees

namespace Degree1720
open PEqualNP.CircuitLowerBounds

lemma max_zero (l : List ℕ) (h : l.foldr max 0=0) : ∀ a∈l,a=0 := by
  induction l with
  | nil => simp
  | cons b bs ih =>
    simp only [List.foldr_cons] at h
    have hb : b=0 := by omega
    have ht : bs.foldr max 0=0 := by omega
    intro a ha
    rcases List.mem_cons.mp ha with rfl | ha
    · exact hb
    · exact ih ht a ha

lemma sum_zero (l : List ℕ) (h : l.sum=0) : ∀ a∈l,a=0 := by
  induction l with
  | nil => simp
  | cons b bs ih =>
    simp only [List.sum_cons] at h
    have hb : b=0 := by omega
    have ht : bs.sum=0 := by omega
    intro a ha
    rcases List.mem_cons.mp ha with rfl | ha
    · exact hb
    · exact ih ht a ha

lemma zero_inputs (g : Gate) (d : List ℕ) (h : g.lineDegree d=0) :
    ∀ w∈g.inputs,d.getD w 0=0 := by
  classical
  unfold Gate.lineDegree at h
  split at h
  · intro w hw
    exact sum_zero _ h _ (List.mem_map.mpr ⟨w,hw,rfl⟩)
  · intro w hw
    exact max_zero _ h _ (List.mem_map.mpr ⟨w,hw,rfl⟩)

end Degree1720
#print axioms Degree1720.zero_inputs

namespace Extract1720
open PEqualNP.CircuitLowerBounds

def Selected (map : List (Option ℕ)) (d : List ℕ) : Prop :=
  ∀ w, w<map.length → ((∃ r,map.getD w none=some r) ↔ d.getD w 0=0)

lemma selected_defined (d : List ℕ) (acc : List (Option ℕ) × List Gate) (g : Gate)
    (hlen : d.length=acc.1.length) (h : Selected acc.1 d)
    (hread : ∀ w∈g.inputs,w<d.length) :
    decide (g.lineDegree d=0)=true → ∀ w∈g.inputs,∃ r,acc.1.getD w none=some r := by
  intro hg w hw
  have hz := Degree1720.zero_inputs g d (of_decide_eq_true hg) w hw
  exact (h w (by rw [←hlen];exact hread w hw)).mpr hz

lemma selected_step (m : ℕ) (d : List ℕ) (acc : List (Option ℕ) × List Gate) (g : Gate)
    (hlen : d.length=acc.1.length) (h : Selected acc.1 d) :
    Selected (step m (decide (g.lineDegree d=0)) acc g).1 (d++[g.lineDegree d]) := by
  intro w hw
  by_cases he : w=acc.1.length
  · subst w
    rw [←hlen]
    simp only [step]
    split
    · rename_i hg
      have hz : g.lineDegree d=0 := of_decide_eq_true hg
      simp [hlen,hz]
    · simp_all
  · have hlt : w<acc.1.length := by rw [step_map_length] at hw;omega
    rw [step_map_old m _ acc g w hlt,List.getD_append _ _ _ _ (by omega)]
    exact h w hlt

end Extract1720
#print axioms Extract1720.selected_step

namespace Extract1720
open PEqualNP.CircuitLowerBounds

def mark : List Gate → List ℕ → List (Bool × Gate)
  | [],_ => []
  | g::gs,d => (decide (g.lineDegree d=0),g)::mark gs (d++[g.lineDegree d])

def Reads (k : ℕ) : List Gate → Prop
  | [] => True
  | g::gs => (∀ w∈g.inputs,w<k) ∧ Reads (k+1) gs

lemma mark_snd (gs : List Gate) (d : List ℕ) : (mark gs d).map Prod.snd=gs := by
  induction gs generalizing d with
  | nil => rfl
  | cons g gs ih => simp [mark,ih]

lemma mark_ready (m : ℕ) (gs : List Gate) (d : List ℕ) (acc : List (Option ℕ) × List Gate)
    (hlen : d.length=acc.1.length) (hsel : Selected acc.1 d) (hread : Reads d.length gs) :
    Ready m (mark gs d) acc := by
  induction gs generalizing d acc with
  | nil => trivial
  | cons g gs ih =>
    refine ⟨selected_defined d acc g hlen hsel hread.1,?_⟩
    apply ih
    · rw [List.length_append,List.length_singleton,step_map_length,hlen]
    · exact selected_step m d acc g hlen hsel
    · simpa using hread.2

lemma mark_selected (m : ℕ) (gs : List Gate) (d : List ℕ) (acc : List (Option ℕ) × List Gate)
    (hlen : d.length=acc.1.length) (hsel : Selected acc.1 d) :
    Selected (pass m (mark gs d) acc).1
      (gs.foldl (fun d g => d++[g.lineDegree d]) d) := by
  induction gs generalizing d acc with
  | nil => exact hsel
  | cons g gs ih =>
    apply ih
    · rw [List.length_append,List.length_singleton,step_map_length,hlen]
    · exact selected_step m d acc g hlen hsel

end Extract1720
#print axioms Extract1720.mark_ready
#print axioms Extract1720.mark_selected

namespace Extract1720
open PEqualNP.CircuitLowerBounds

lemma extract_zero (m : ℕ) (gs : List Gate) (d : List ℕ) (acc : List (Option ℕ) × List Gate)
    (old input : List Bool) (hin : input.length=m)
    (hlen : d.length=acc.1.length) (hold : acc.1.length=old.length)
    (hsel : Selected acc.1 d) (hread : Reads d.length gs)
    (hvalid : Valid m acc) (hagree : Agrees acc old (run acc.2 input)) :
    let final := pass m (mark gs d) acc
    Selected final.1 (gs.foldl (fun d g => d++[g.lineDegree d]) d) ∧
    Agrees final (run gs old) (run final.2 input) ∧ Valid m final ∧
    final.2.length=acc.2.length+((mark gs d).filter fun bg => bg.1).length := by
  refine ⟨mark_selected m gs d acc hlen hsel,?_,pass_valid m _ acc hvalid,pass_size m _ acc⟩
  have h := pass_agrees m (mark gs d) acc old input hin hold hvalid hagree
    (mark_ready m gs d acc hlen hsel hread)
  simpa only [mark_snd] using h

end Extract1720
#print axioms Extract1720.extract_zero

namespace Extract1720
open PEqualNP.CircuitLowerBounds

def initMap (N : ℕ) : List (Option ℕ) :=
  List.replicate N none ++ List.ofFn (fun i : Fin N => some i.val)
def initDegrees (N : ℕ) : List ℕ := List.replicate N 1 ++ List.replicate N 0

lemma initMap_left (N w : ℕ) (hw : w<N) : (initMap N).getD w none=none := by
  rw [initMap,List.getD_append _ _ _ _ (by simp;exact hw)]
  simp [List.getD_replicate,hw]

lemma initMap_right (N w : ℕ) (hN : N≤w) (hw : w<N+N) :
    (initMap N).getD w none=some (w-N) := by
  rw [initMap,List.getD_append_right _ _ _ _ (by simp;omega)]
  have hs : w-N<N := by omega
  rw [List.getD_eq_getElem _ _ (by simp;omega)]
  simp only [List.length_replicate,List.getElem_ofFn]

lemma initMap_out (N w : ℕ) (hw : N+N≤w) : (initMap N).getD w none=none := by
  exact List.getD_eq_default _ _ (by simp [initMap];omega)

lemma initDegree_left (N w : ℕ) (hw : w<N) : (initDegrees N).getD w 0=1 := by
  rw [initDegrees,List.getD_append _ _ _ _ (by simp;exact hw)]
  simp [List.getD_replicate,hw]

lemma initDegree_right (N w : ℕ) (hN : N≤w) : (initDegrees N).getD w 0=0 := by
  rw [initDegrees,List.getD_append_right _ _ _ _ (by simp;omega)]
  simp

lemma init_selected (N : ℕ) : Selected (initMap N) (initDegrees N) := by
  intro w hw
  have hlen : (initMap N).length=N+N := by simp [initMap]
  rw [hlen] at hw
  by_cases hlt : w<N
  · rw [initMap_left N w hlt,initDegree_left N w hlt]
    simp
  · rw [initMap_right N w (by omega) hw,initDegree_right N w (by omega)]
    simp

lemma init_valid (N : ℕ) : Valid N (initMap N,[]) := by
  intro w r hr
  change (initMap N).getD w none=some r at hr
  change r<N
  by_cases hlt : w<N
  · rw [initMap_left N w hlt] at hr;contradiction
  · by_cases hw : w<N+N
    · rw [initMap_right N w (by omega) hw] at hr
      have he := Option.some.inj hr
      omega
    · rw [initMap_out N w (by omega)] at hr;contradiction

end Extract1720
#print axioms Extract1720.init_selected
#print axioms Extract1720.init_valid

namespace Extract1720
open PEqualNP.CircuitLowerBounds

lemma init_agrees (N : ℕ) (x y : Fin N → Bool) :
    Agrees (initMap N,[]) (List.ofFn (Fin.append x y)) (run [] (List.ofFn y)) := by
  intro w r hr
  change (initMap N).getD w none=some r at hr
  change (List.ofFn y).getD r false=(List.ofFn (Fin.append x y)).getD w false
  have hw : w<N+N := by
    by_contra hn
    rw [initMap_out N w (by omega)] at hr
    contradiction
  have hge : N≤w := by
    by_contra hn
    rw [initMap_left N w (by omega)] at hr
    contradiction
  rw [initMap_right N w hge hw] at hr
  have he := Option.some.inj hr
  have hrN : r<N := by omega
  have hwr : w=N+r := by omega
  subst w
  rw [List.getD_eq_getElem _ _ (by simp;exact hrN),
    List.getD_eq_getElem _ _ (by simp;omega)]
  simp only [List.getElem_ofFn]
  exact (Fin.append_right x y ⟨r,hrN⟩).symm

end Extract1720
#print axioms Extract1720.init_agrees
