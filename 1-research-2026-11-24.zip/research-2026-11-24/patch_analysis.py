import json,itertools
N=1480246061810718672621733722450585557241470820309892749861807518239958412378186263487927796164043095741019831558144750660106198005976822192129296186629569935243155508098582165941591407534954087431827117882956910202019909074975
rows=[(N>>(17*i))&131071 for i in range(44)]
pick=list(range(5))+list(range(13,22))+list(range(23,26))
lines=[x-13 for x in pick[5:]]
positives=[(p,l) for p in range(5) for l in lines if (p-l)%13 in [0,1,3,9]]
rect=[]
for A in range(1,32):
 B=(1<<12)-1
 for row in rows:
  if row&A:B&=~(row>>5)
 if not B:continue
 cover=sum(1<<i for i,(p,l) in enumerate(positives) if A>>p&1 and B>>lines.index(l)&1)
 if cover:
  cost=A.bit_count()+B.bit_count()-1
  rect.append((A,B,cover,cost))
print('lines',lines,'positivepairs',len(positives),'rectangles',len(rect))
print([(a,b,c.bit_count(),d) for a,b,c,d in rect])
# Cover via rectangles: cost of each product is|A|+|B|-1; union costs(#rect-1).
full=(1<<len(positives))-1;dp={0:(0,[])}
for A,B,c,cost in rect:
 for old,(v,path) in list(dp.items()):
  new=old|c;nv=v+cost+1
  if new not in dp or nv<dp[new][0]:dp[new]=(nv,path+[(A,B)])
print('best twolevel',dp.get(full),'gates',dp[full][0]-1)
json.dump({'rows':rows,'pick':pick,'lines':lines,'positives':positives,'rectangles':rect,'best':dp[full]},open('./patch-analysis.json','w'),indent=2)
