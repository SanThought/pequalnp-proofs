import PEqualNP.Defs.MetaComplexityLgpMono
import PEqualNP.Defs.NestedCoverCircuit
import Mathlib.Data.List.FinRange
import Mathlib.Tactic.ByContra
import Lean.Elab.Tactic.Omega

namespace Emit1720
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

def run (gs : List Gate) (x : List Bool) : List Bool :=
  gs.foldl (fun w g => w ++ [g.op.eval (g.inputs.map fun i => w.getD i false)]) x

lemma run_cons (g : Gate) (gs : List Gate) (x : List Bool) :
    run (g::gs) x = run gs (x ++ [g.op.eval (g.inputs.map fun i => x.getD i false)]) := rfl

lemma run_append (gs hs : List Gate) (x : List Bool) : run (gs++hs) x = run hs (run gs x) := by
  simp [run,List.foldl_append]

lemma length_run (gs : List Gate) (x : List Bool) : (run gs x).length = x.length+gs.length := by
  induction gs generalizing x with
  | nil => simp [run]
  | cons g gs ih => rw [run_cons,ih]; simp; omega

lemma run_old (gs : List Gate) (x : List Bool) (w : ℕ) (hw : w < x.length) :
    (run gs x).getD w false = x.getD w false := by
  induction gs generalizing x with
  | nil => rfl
  | cons g gs ih =>
    rw [run_cons,ih _ (by simp;omega),List.getD_append _ _ _ _ hw]

lemma add_or {n : ℕ} (gs : List Gate) (a b : ℕ) (ha : a<n+gs.length) (hb : b<n+gs.length)
    (x : Fin n → Bool) :
    (run (gs++[({op := GateOp.or,inputs := [a,b]} : Gate)]) (List.ofFn x)).getD (n+gs.length) false =
      ((run gs (List.ofFn x)).getD a false || (run gs (List.ofFn x)).getD b false) := by
  rw [run_append]
  rw [run_cons]
  change ((run gs (List.ofFn x)) ++ [GateOp.or.eval ([a,b].map fun i =>
    (run gs (List.ofFn x)).getD i false)]).getD (n+gs.length) false = _
  simp only [GateOp.eval,List.map_cons,List.map_nil,List.any_cons,List.any_nil,Bool.or_false]
  have hl : (run gs (List.ofFn x)).length = n+gs.length := by simp [length_run]
  rw [List.getD_append_right _ _ _ _ (by omega)]
  simp [hl]

-- Nonempty aggregations use the first source for free, then one binary OR per later source.
def aggregate (n : ℕ) : List Gate → ℕ → List ℕ → List Gate × ℕ
  | gs,a,[] => (gs,a)
  | gs,a,b::bs => aggregate n (gs++[({op := GateOp.or,inputs := [a,b]} : Gate)]) (n+gs.length) bs

lemma aggregate_size (n : ℕ) (gs : List Gate) (a : ℕ) (bs : List ℕ) :
    (aggregate n gs a bs).1.length = gs.length+bs.length := by
  induction bs generalizing gs a with
  | nil => rfl
  | cons b bs ih => simp only [aggregate,ih,List.length_append,List.length_singleton,List.length_cons,List.length_nil];omega

lemma aggregate_extends (n : ℕ) (gs : List Gate) (a : ℕ) (bs : List ℕ) :
    ∃ extra, (aggregate n gs a bs).1 = gs++extra := by
  induction bs generalizing gs a with
  | nil => exact ⟨[],by simp [aggregate]⟩
  | cons b bs ih =>
    obtain ⟨extra,h⟩ := ih (gs++[({op := GateOp.or,inputs := [a,b]} : Gate)]) (n+gs.length)
    exact ⟨[({op := GateOp.or,inputs := [a,b]} : Gate)]++extra,by simpa [aggregate,List.append_assoc] using h⟩

end Emit1720
#print axioms Emit1720.add_or

namespace Emit1720
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

lemma aggregate_value (n : ℕ) (gs : List Gate) (a : ℕ) (bs : List ℕ)
    (ha : a<n+gs.length) (hbs : ∀ b ∈ bs, b<n+gs.length) (x : Fin n → Bool) :
    (run (aggregate n gs a bs).1 (List.ofFn x)).getD (aggregate n gs a bs).2 false =
      ((run gs (List.ofFn x)).getD a false ||
       bs.any (fun b => (run gs (List.ofFn x)).getD b false)) := by
  induction bs generalizing gs a with
  | nil => simp [aggregate]
  | cons b bs ih =>
    have hb := hbs b List.mem_cons_self
    have hn : n+gs.length < n+(gs++[({op := GateOp.or,inputs := [a,b]} : Gate)]).length := by simp
    have ht : ∀ c ∈ bs, c < n+(gs++[({op := GateOp.or,inputs := [a,b]} : Gate)]).length := by
      intro c hc
      have := hbs c (List.mem_cons_of_mem b hc)
      simp;omega
    rw [aggregate,ih _ _ hn ht]
    rw [add_or gs a b ha hb x]
    have old (c : ℕ) (hc : c∈bs) :
        (run (gs++[({op := GateOp.or,inputs := [a,b]} : Gate)]) (List.ofFn x)).getD c false =
          (run gs (List.ofFn x)).getD c false := by
      rw [run_append]
      apply run_old
      simpa [length_run] using hbs c (List.mem_cons_of_mem b hc)
    have hlist : bs.any (fun c => (run (gs++[({op := GateOp.or,inputs := [a,b]} : Gate)]) (List.ofFn x)).getD c false) =
        bs.any (fun c => (run gs (List.ofFn x)).getD c false) := by
      apply Bool.eq_iff_iff.mpr
      simp only [List.any_eq_true]
      constructor
      · rintro ⟨c,hc,hv⟩
        exact ⟨c,hc,(old c hc) ▸ hv⟩
      · rintro ⟨c,hc,hv⟩
        exact ⟨c,hc,(old c hc).symm ▸ hv⟩
    rw [hlist]
    simp [Bool.or_assoc]

end Emit1720
#print axioms Emit1720.aggregate_value

namespace Emit1720
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

lemma aggregate_valid (n : ℕ) (gs : List Gate) (a : ℕ) (bs : List ℕ)
    (ha : a<n+gs.length) (hbs : ∀ b∈bs, b<n+gs.length) :
    (aggregate n gs a bs).2 < n+(aggregate n gs a bs).1.length := by
  induction bs generalizing gs a with
  | nil => exact ha
  | cons b bs ih =>
    apply ih
    · simp
    · intro c hc
      have := hbs c (List.mem_cons_of_mem b hc)
      simp;omega

lemma aggregate_basis (n : ℕ) (gs : List Gate) (a : ℕ) (bs : List ℕ)
    (hok : ∀ g∈gs, (g.op = GateOp.and ∨ g.op = GateOp.or) ∧ g.inputs.length = 2) :
    ∀ g∈(aggregate n gs a bs).1,
      (g.op = GateOp.and ∨ g.op = GateOp.or) ∧ g.inputs.length = 2 := by
  induction bs generalizing gs a with
  | nil => exact hok
  | cons b bs ih =>
    apply ih
    intro g hg
    rcases List.mem_append.mp hg with h | h
    · exact hok g h
    · simp at h
      subst g
      simp

end Emit1720
#print axioms Emit1720.aggregate_valid
#print axioms Emit1720.aggregate_basis

namespace Emit1720
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

-- An equivalent list-prefix form of backward-only wiring.
def Back (n : ℕ) (gs : List Gate) : Prop :=
  ∀ j, ∀ g, gs[j]? = some g → ∀ w∈g.inputs, w<n+j

lemma back_append_or (n : ℕ) (gs : List Gate) (a b : ℕ)
    (hg : Back n gs) (ha : a<n+gs.length) (hb : b<n+gs.length) :
    Back n (gs++[⟨.or,[a,b]⟩]) := by
  intro j g hj w hw
  by_cases hlt : j<gs.length
  · rw [List.getElem?_append_left hlt] at hj
    exact hg j g hj w hw
  · have hge : gs.length ≤ j := by omega
    rw [List.getElem?_append_right hge] at hj
    by_cases heq : j = gs.length
    · subst j
      simp at hj
      subst g
      simp only [List.mem_cons,List.not_mem_nil,or_false] at hw
      rcases hw with rfl | rfl
      · exact ha
      · exact hb
    · have hdiff : 1 ≤ j-gs.length := by omega
      rw [List.getElem?_eq_none (by simp;omega)] at hj
      contradiction

lemma aggregate_back (n : ℕ) (gs : List Gate) (a : ℕ) (bs : List ℕ)
    (hg : Back n gs) (ha : a<n+gs.length) (hbs : ∀ b∈bs,b<n+gs.length) :
    Back n (aggregate n gs a bs).1 := by
  induction bs generalizing gs a with
  | nil => exact hg
  | cons b bs ih =>
    apply ih
    · exact back_append_or n gs a b hg ha (hbs b List.mem_cons_self)
    · simp
    · intro c hc
      have := hbs c (List.mem_cons_of_mem b hc)
      simp;omega

end Emit1720
#print axioms Emit1720.aggregate_back

namespace Emit1720
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

lemma back_iff (n : ℕ) (gs : List Gate) (o : ℕ) :
    Back n gs ↔ PEqualNP.MetaComplexity.NestedCover.ReadsBack n ⟨gs,o⟩ := by
  constructor
  · intro h j hj w hw
    have he : gs[j]? = some (gs.getD j ⟨.or,[]⟩) := by
      rw [List.getElem?_eq_getElem hj,List.getD_eq_getElem _ _ hj]
    exact h j _ he w hw
  · intro h j g hj w hw
    have hlt : j<gs.length := List.getElem?_eq_some_iff.mp hj |>.1
    have he : gs.getD j ⟨.or,[]⟩ = g := by
      rw [List.getD_eq_getElem _ _ hlt]
      exact (List.getElem?_eq_some_iff.mp hj).2
    apply h j hlt w
    simpa [PEqualNP.MetaComplexity.NestedCover.gateAt,List.getD,hj] using hw

end Emit1720
#print axioms Emit1720.back_iff

namespace Emit1720
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

-- Empty group outputs are deferred until the final list length is known.
def groups (n : ℕ) : List Gate → List (List ℕ) → List Gate × List (Option ℕ)
  | gs,[] => (gs,[])
  | gs,[]::ss => let r := groups n gs ss; (r.1,none::r.2)
  | gs,(a::bs)::ss =>
    let r := aggregate n gs a bs
    let s := groups n r.1 ss
    (s.1,some r.2::s.2)

lemma groups_count (n : ℕ) (gs : List Gate) (ss : List (List ℕ)) :
    (groups n gs ss).2.length = ss.length := by
  induction ss generalizing gs with
  | nil => rfl
  | cons s ss ih => cases s <;> simp [groups,ih]

lemma groups_size (n : ℕ) (gs : List Gate) (ss : List (List ℕ)) :
    (groups n gs ss).1.length = gs.length+(ss.map fun s => s.length-1).sum := by
  induction ss generalizing gs with
  | nil => simp [groups]
  | cons s ss ih =>
    cases s with
    | nil => simp [groups,ih]
    | cons a bs => simp [groups,ih,aggregate_size];omega

lemma groups_extends (n : ℕ) (gs : List Gate) (ss : List (List ℕ)) :
    ∃ extra, (groups n gs ss).1 = gs++extra := by
  induction ss generalizing gs with
  | nil => exact ⟨[],by simp [groups]⟩
  | cons s ss ih =>
    cases s with
    | nil => simpa [groups] using ih gs
    | cons a bs =>
      obtain ⟨e,he⟩ := aggregate_extends n gs a bs
      obtain ⟨f,hf⟩ := ih (aggregate n gs a bs).1
      exact ⟨e++f,by simpa [groups,he,List.append_assoc] using hf⟩

lemma groups_basis (n : ℕ) (gs : List Gate) (ss : List (List ℕ))
    (hok : ∀ g∈gs, (g.op = GateOp.and ∨ g.op = GateOp.or) ∧ g.inputs.length = 2) :
    ∀ g∈(groups n gs ss).1, (g.op = GateOp.and ∨ g.op = GateOp.or) ∧ g.inputs.length = 2 := by
  induction ss generalizing gs with
  | nil => exact hok
  | cons s ss ih =>
    cases s with
    | nil => exact ih gs hok
    | cons a bs => exact ih _ (aggregate_basis n gs a bs hok)

end Emit1720
#print axioms Emit1720.groups_size

namespace Emit1720
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

lemma prefix_value (n : ℕ) (gs hs : List Gate) (w : ℕ) (hw : w<n+gs.length)
    (hp : ∃ e, hs=gs++e) (x : Fin n → Bool) :
    (run hs (List.ofFn x)).getD w false = (run gs (List.ofFn x)).getD w false := by
  obtain ⟨e,rfl⟩ := hp
  rw [run_append]
  apply run_old
  simpa [length_run] using hw

lemma groups_valid (n : ℕ) (gs : List Gate) (ss : List (List ℕ))
    (hin : ∀ s∈ss,∀ w∈s,w<n+gs.length) :
    ∀ o∈(groups n gs ss).2, ∀ w, o=some w → w<n+(groups n gs ss).1.length := by
  induction ss generalizing gs with
  | nil => simp [groups]
  | cons s ss ih =>
    cases s with
    | nil =>
      intro o ho w hw
      simp only [groups,List.mem_cons] at ho
      rcases ho with rfl | ho
      · contradiction
      · exact ih gs (fun s hs => hin s (List.mem_cons_of_mem [] hs)) o ho w hw
    | cons a bs =>
      let r := aggregate n gs a bs
      have ha := hin (a::bs) List.mem_cons_self a List.mem_cons_self
      have hb : ∀ b∈bs,b<n+gs.length := fun b hb => hin (a::bs) List.mem_cons_self b (List.mem_cons_of_mem a hb)
      have hlen : gs.length ≤ r.1.length := by simp [r,aggregate_size]
      intro o ho w hw
      simp only [groups,List.mem_cons] at ho
      rcases ho with ho | ho
      · have he : w=r.2 := Option.some.inj (ho.symm.trans hw).symm
        rw [he]
        have h := aggregate_valid n gs a bs ha hb
        obtain ⟨e,he⟩ := groups_extends n r.1 ss
        change r.2<n+(groups n r.1 ss).1.length
        rw [he,List.length_append]
        change r.2 < n+r.1.length at h
        omega
      · apply ih r.1 _ o ho w hw
        intro s hs w hw
        have h := hin s (List.mem_cons_of_mem (a::bs) hs) w hw
        omega

end Emit1720
#print axioms Emit1720.groups_valid

namespace Emit1720
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

lemma groups_back (n : ℕ) (gs : List Gate) (ss : List (List ℕ))
    (hg : Back n gs) (hin : ∀ s∈ss,∀ w∈s,w<n+gs.length) :
    Back n (groups n gs ss).1 := by
  induction ss generalizing gs with
  | nil => exact hg
  | cons s ss ih =>
    cases s with
    | nil => exact ih gs hg (fun s hs => hin s (List.mem_cons_of_mem [] hs))
    | cons a bs =>
      apply ih
      · apply aggregate_back n gs a bs hg
        · exact hin (a::bs) List.mem_cons_self a List.mem_cons_self
        · intro b hb
          exact hin (a::bs) List.mem_cons_self b (List.mem_cons_of_mem a hb)
      · intro s hs w hw
        have h := hin s (List.mem_cons_of_mem (a::bs) hs) w hw
        rw [aggregate_size]
        omega

end Emit1720
#print axioms Emit1720.groups_back

namespace Emit1720
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

def oval (n : ℕ) (gs : List Gate) (x : Fin n → Bool) : Option ℕ → Bool
  | none => false
  | some w => (run gs (List.ofFn x)).getD w false

lemma groups_value (n : ℕ) (gs : List Gate) (ss : List (List ℕ))
    (hin : ∀ s∈ss,∀ w∈s,w<n+gs.length) (x : Fin n → Bool) :
    (groups n gs ss).2.map (oval n (groups n gs ss).1 x) =
      ss.map (fun s => s.any fun w => (run gs (List.ofFn x)).getD w false) := by
  induction ss generalizing gs with
  | nil => rfl
  | cons s ss ih =>
    cases s with
    | nil =>
      simpa [groups,oval] using congrArg (List.cons false)
        (ih gs (fun s hs => hin s (List.mem_cons_of_mem [] hs)))
    | cons a bs =>
      let r := aggregate n gs a bs
      have ha := hin (a::bs) List.mem_cons_self a List.mem_cons_self
      have hb : ∀ b∈bs,b<n+gs.length := fun b hb => hin (a::bs) List.mem_cons_self b (List.mem_cons_of_mem a hb)
      have hlen : gs.length ≤ r.1.length := by simp [r,aggregate_size]
      have ht : ∀ s∈ss,∀ w∈s,w<n+r.1.length := by
        intro s hs w hw
        have := hin s (List.mem_cons_of_mem (a::bs) hs) w hw
        omega
      have hv := ih r.1 ht
      have hhead : oval n (groups n r.1 ss).1 x (some r.2) =
          (a::bs).any (fun w => (run gs (List.ofFn x)).getD w false) := by
        simp only [oval]
        rw [prefix_value n r.1 _ r.2 (aggregate_valid n gs a bs ha hb)
          (groups_extends n r.1 ss) x]
        exact aggregate_value n gs a bs ha hb x
      have htail : ss.map (fun s => s.any fun w => (run r.1 (List.ofFn x)).getD w false) =
          ss.map (fun s => s.any fun w => (run gs (List.ofFn x)).getD w false) := by
        apply List.map_congr_left
        intro s hs
        apply Bool.eq_iff_iff.mpr
        simp only [List.any_eq_true]
        constructor
        · rintro ⟨w,hw,hv⟩
          exact ⟨w,hw,(prefix_value n gs r.1 w (hin s (List.mem_cons_of_mem (a::bs) hs) w hw)
            (aggregate_extends n gs a bs) x) ▸ hv⟩
        · rintro ⟨w,hw,hv⟩
          exact ⟨w,hw,(prefix_value n gs r.1 w (hin s (List.mem_cons_of_mem (a::bs) hs) w hw)
            (aggregate_extends n gs a bs) x).symm ▸ hv⟩
      change oval n (groups n r.1 ss).1 x (some r.2) ::
        (groups n r.1 ss).2.map (oval n (groups n r.1 ss).1 x) = _
      rw [hhead,hv,htail]
      rfl

end Emit1720
#print axioms Emit1720.groups_value
