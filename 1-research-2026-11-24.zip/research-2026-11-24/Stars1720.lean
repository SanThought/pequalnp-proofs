import Mathlib.Data.Finset.Card
import Mathlib.Data.Fintype.Card
import Lean.Elab.Tactic.Omega

namespace Stars1720
variable {P L : Type*} [DecidableEq P] [DecidableEq L]

lemma rectangle_star (I : P → L → Prop)
    (join : ∀ p q, p ≠ q → ∃! l, I p l ∧ I q l)
    (A : Finset P) (B : Finset L)
    (rect : ∀ p ∈ A, ∀ l ∈ B, I p l) : A.card ≤ 1 ∨ B.card ≤ 1 := by
  by_cases ha : A.card ≤ 1
  · exact Or.inl ha
  · right
    have h2 : 1 < A.card := by omega
    obtain ⟨p,hp,q,hq,hpq⟩ := Finset.one_lt_card.mp h2
    obtain ⟨l,hl,huniq⟩ := join p q hpq
    have hsub : B ⊆ {l} := by
      intro b hb
      exact Finset.mem_singleton.mpr (huniq b ⟨rect p hp b hb,rect q hq b hb⟩)
    have hc := Finset.card_le_card hsub
    simpa using hc

lemma large_side_singleton (I : P → L → Prop)
    (join : ∀ p q, p ≠ q → ∃! l, I p l ∧ I q l)
    (A : Finset P) (B : Finset L)
    (rect : ∀ p ∈ A, ∀ l ∈ B, I p l)
    (ha : 2 ≤ A.card) : B.card ≤ 1 := by
  rcases rectangle_star I join A B rect with h | h
  · omega
  · exact h

end Stars1720
#print axioms Stars1720.rectangle_star

namespace Stars1720
variable {P L H : Type*} [DecidableEq P] [DecidableEq L]

lemma star_cover (I : P → L → Prop)
    (join : ∀ p q, p ≠ q → ∃! l, I p l ∧ I q l)
    (A : H → Finset P) (B : H → Finset L)
    (sound : ∀ h p, p ∈ A h → ∀ l ∈ B h, I p l)
    (cover : ∀ p l, I p l → ∃ h, p ∈ A h ∧ l ∈ B h) :
    ∀ p l, I p l →
      (∃ h, p ∈ A h ∧ l ∈ B h ∧ (B h).card ≤ 1) ∨
      (∃ h, p ∈ A h ∧ l ∈ B h ∧ (A h).card ≤ 1) := by
  intro p l hi
  obtain ⟨h,hp,hl⟩ := cover p l hi
  rcases rectangle_star I join (A h) (B h) (sound h) with ha | hb
  · exact Or.inr ⟨h,hp,hl,ha⟩
  · exact Or.inl ⟨h,hp,hl,hb⟩

end Stars1720
#print axioms Stars1720.star_cover
