import json
p=json.load(open('./patch-analysis.json'));lines=p['lines'];gs=[]
def gate(op,a,b):
 gs.append((op,[a,b]));return 17+len(gs)-1
outs=[]
for point in range(5):
 ns=[5+lines.index(l) for l in lines if (point-l)%13 in [0,1,3,9]]
 a=ns[0]
 for b in ns[1:]:a=gate('or',a,b)
 outs.append(gate('and',point,a))
a=outs[0]
for b in outs[1:]:a=gate('or',a,b)
assert len(gs)==24
for bits in p['rows']:
 w=[bool(bits>>i&1) for i in range(17)]
 for op,ins in gs:w.append((w[ins[0]] and w[ins[1]]) if op=='and' else (w[ins[0]] or w[ins[1]]))
 assert not w[a]
for point,l in p['positives']:
 bits=(1<<point)|(1<<(5+lines.index(l)));w=[bool(bits>>i&1) for i in range(17)]
 for op,ins in gs:w.append((w[ins[0]] and w[ins[1]]) if op=='and' else (w[ins[0]] or w[ins[1]]))
 assert w[a]
json.dump({'n':17,'gates':gs,'output':a},open('./baseline24.json','w'),indent=2)
print('baseline24 pass all64rows')
