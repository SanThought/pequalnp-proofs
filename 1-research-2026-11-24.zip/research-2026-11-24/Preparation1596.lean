import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Data.Finset.Card
import Mathlib.Data.Fintype.Card
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Lean.Elab.Tactic.Omega

namespace Preparation1596

open Finset

lemma supports_disjoint {P I : Type*} [DecidableEq P] [DecidableEq I]
    (S : I → Finset P) (U : I → Finset P)
    (hS : ∀ i j, i ≠ j → (S i ∩ S j).card ≤ 1)
    (hsub : ∀ i, U i ⊆ S i) (hcard : ∀ i, 2 ≤ (U i).card)
    {i j : I} (hij : i ≠ j) (heq : U i = U j) : False := by
  have hle : (U i).card ≤ (S i ∩ S j).card := by
    apply card_le_card
    intro p hp
    exact mem_inter.mpr ⟨hsub i hp, hsub j (heq ▸ hp)⟩
  have := hS i j hij
  have := hcard i
  omega

lemma two_window_count {I G : Type*} [Fintype I] [Fintype G]
    [DecidableEq I] [DecidableEq G]
    (A B : I → Finset G)
    (hA : (Set.univ : Set I).PairwiseDisjoint A)
    (hB : (Set.univ : Set I).PairwiseDisjoint B) :
    (∑ i, (A i).card) + (∑ i, (B i).card) ≤
      Fintype.card G + ((univ.biUnion A) ∩ (univ.biUnion B)).card := by
  have ha : (univ.biUnion A).card = ∑ i, (A i).card := card_biUnion (by simpa using hA)
  have hb : (univ.biUnion B).card = ∑ i, (B i).card := card_biUnion (by simpa using hB)
  have hu : ((univ.biUnion A) ∪ (univ.biUnion B)).card ≤ Fintype.card G :=
    card_le_univ _
  have hi := card_union_add_card_inter (univ.biUnion A) (univ.biUnion B)
  omega

lemma two_window_refund {I G : Type*} [Fintype I] [Fintype G]
    [DecidableEq I] [DecidableEq G]
    (A B : I → Finset G) (R : Finset G) (cost : I → ℕ)
    (hA : (Set.univ : Set I).PairwiseDisjoint A)
    (hB : (Set.univ : Set I).PairwiseDisjoint B)
    (hrefund : (univ.biUnion A) ∩ (univ.biUnion B) ⊆ R)
    (hcost : ∀ i, cost i ≤ (A i).card + (B i).card + 1) :
    (∑ i, cost i) ≤ Fintype.card G + R.card + Fintype.card I := by
  have hc := sum_le_sum (s := (univ : Finset I)) (fun i _ => hcost i)
  have ht := two_window_count A B hA hB
  have hr := card_le_card hrefund
  simp only [sum_add_distrib, sum_const, card_univ] at hc
  have hs : Fintype.card I • (1 : ℕ) = Fintype.card I := by simp
  rw [hs] at hc
  omega

lemma charge_disjoint {P I G : Type*} [Fintype G] [DecidableEq P] [DecidableEq I]
    (S : I → Finset P) (support : G → Finset P)
    (hS : ∀ i j, i ≠ j → (S i ∩ S j).card ≤ 1) :
    (Set.univ : Set I).PairwiseDisjoint
      (fun i => Finset.univ.filter fun g => support g ⊆ S i ∧ 2 ≤ (support g).card) := by
  intro i hi j hj hij
  apply Finset.disjoint_left.mpr
  intro g hg hjg
  have ha := (Finset.mem_filter.mp hg).2
  have hb := (Finset.mem_filter.mp hjg).2
  have hc : (support g).card ≤ (S i ∩ S j).card := by
    apply Finset.card_le_card
    intro p hp
    exact Finset.mem_inter.mpr ⟨ha.1 hp, hb.1 hp⟩
  have := hS i j hij
  omega

lemma relaxed_two_window {I G : Type*} [Fintype I] [Fintype G]
    [DecidableEq I] [DecidableEq G]
    (A B : I → Finset G) (cost : I → ℕ)
    (hA : (Set.univ : Set I).PairwiseDisjoint A)
    (hB : (Set.univ : Set I).PairwiseDisjoint B)
    (hcost : ∀ i, cost i ≤ (A i).card + (B i).card + 1) :
    (∑ i, cost i) ≤ 2 * Fintype.card G + Fintype.card I := by
  have h := two_window_refund A B univ cost hA hB
    (by intro x hx; exact mem_univ x) hcost
  simp only [card_univ] at h
  omega

end Preparation1596

#print axioms Preparation1596.two_window_refund
#print axioms Preparation1596.charge_disjoint
#print axioms Preparation1596.relaxed_two_window
