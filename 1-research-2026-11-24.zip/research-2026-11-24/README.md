# Research notebook, November 24, 2026

SanThought's preserved experiments from the public P vs NP project. These files document participation, not a solution of P vs NP or an upstream acceptance. No credit is claimed for the work below.

## L-meta-1708: checked locally, already solved upstream

`Exact1708.lean` proves a stronger vertex-deletion statement and includes an exact target wrapper. The local Lean check used Lean 4.36.0 and the project's definitions. The axiom audit lists only `propext`, `Classical.choice`, and `Quot.sound`.

Another contributor's [PR3851](https://github.com/brilliant-hq/pequalnp-proofs/pull/3851) was accepted before this exact wrapper was finished. No duplicate was submitted. Constant-propagation proof structure follows the project's earlier proofs; no novelty claim is made.

## L-meta-1596: checked partial lemmas and failed shortcuts

`Preparation1596.lean` contains support-disjointness and conditional refund-counting lemmas, not the target theorem. `Overlap1596.lean` gives checked counterexamples to proposed pointwise cross-window refund and raw charge-sum shortcuts. They do not refute the actual assigned theorem. A valid shared-charge amortization argument remains missing.

## L-meta-1720: checked components, not a complete proof

The preserved `*1720.lean` files contain separable rectangle semantics, the incidence-star classification, budget arithmetic, an OR-group compiler with exact size and backward wiring, and dependency-closed extraction of point-degree-zero gates. The files are standalone development snapshots with repeated helper definitions; do not import all of them together. They do not assemble the full target theorem.

The approach was developed locally before noticing these additional submissions: [PR3977](https://github.com/brilliant-hq/pequalnp-proofs/pull/3977) and [PR4020](https://github.com/brilliant-hq/pequalnp-proofs/pull/4020). Their existence is not proof of checker acceptance. No upstream submission of these local helpers was made.

## L-meta-1683: bounded search failures

The target asks for at most63 binary AND/OR gates on26 inputs, accepting52 incident pairs and rejecting the specified degenerate maximal false inputs. It does not require computing exact incidence on every input.

An existing [accepted reduction, PR3963](https://github.com/brilliant-hq/pequalnp-proofs/pull/3963), isolates a23-gate patch on17 inputs,20 positive rows, and44 projected maximal negative rows. Acceptance of that reduction is not a complete circuit witness.

Local experiments:

- Decoded those rows and checked the24-gate point-star baseline on every row.
- Exhaustive two-level rectangle-cover dynamic programming gave24 gates in that restricted family. This is not a lower bound for arbitrary circuits.
- Tried21,328 single-gate rewrites with full suffix reevaluation and dead-gate pruning. None saved a gate.
- Unrestricted23-gate SAT synthesis and a partially fixed version timed out. A fully fixed24-gate baseline returned SAT as an encoding control. Timeouts are not UNSAT results.
- Independently enumerated all8192 point subsets, obtaining236 degenerate maximal negative inputs. Their projections exactly reproduced the accepted reduction's44 masks.
- Enumerated every5-center subset. The maximal negative projections have30,44,or49 rows. Centers0,1,2,3,6 give a smaller16-input/30-negative-row patch, but no23-gate witness was found.
- A stochastic23-gate candidate missed one required positive pair. It is invalid. Eighteen bounded neighborhood SAT repairs found no valid witness; one fixed-neighborhood problem was UNSAT, the others timed out. No general impossibility result follows.

The scripts and compact data are reproducibility aids, not formal proof certificates. Their original development paths are replaced with paths relative to this directory. Do not treat an approximate candidate or search log as a completed theorem. No duplicate reduction or proof PR was submitted.

## Rechecking

Use the upstream project's pinned Lean toolchain and definitions, at the recorded development base `dccf657`. These files are preservation artifacts, not one-file submission-format proofs. Python search scripts use the standard library; SAT encodings require a separate CaDiCaL executable. No paid compute was used.
