import Mathlib.Data.Fintype.Basic

namespace Views1720

variable {P L : Type*} [DecidableEq P] [DecidableEq L]

def unit {T : Type*} [DecidableEq T] (t : T) : T → Bool := fun i => decide (i = t)

lemma semantic_views (I : P → L → Prop) (F : (P → Bool) → (L → Bool) → Prop)
    (small : (L → Bool) → Prop)
    (units : ∀ l, small (unit l))
    (sound : ∀ x y, small y → F x y → ∃ p l, I p l ∧ x p = true ∧ y l = true)
    (positive : ∀ p l, I p l → F (unit p) (unit l)) :
    (∀ p l, F (unit p) (unit l) → I p l) ∧
    (∀ l x, (∀ p, I p l → x p = false) → ¬ F x (unit l)) ∧
    (∀ p y, small y → (∀ l, I p l → y l = false) → ¬ F (unit p) y) ∧
    (∀ p l, I p l → F (unit p) (unit l)) := by
  refine ⟨?_,?_,?_,positive⟩
  · intro p l hf
    obtain ⟨p',l',hi,hp,hl⟩ := sound _ _ (units l) hf
    simp only [unit, decide_eq_true_eq] at hp hl
    simpa [hp,hl] using hi
  · intro l x hx hf
    obtain ⟨p',l',hi,hp,hl⟩ := sound _ _ (units l) hf
    have he : l' = l := of_decide_eq_true hl
    subst l'
    rw [hx p' hi] at hp
    contradiction
  · intro p y hy hny hf
    obtain ⟨p',l',hi,hp,hl⟩ := sound _ _ hy hf
    have he : p' = p := of_decide_eq_true hp
    subst p'
    rw [hny l' hi] at hl
    contradiction

end Views1720
#print axioms Views1720.semantic_views
