import itertools,json,time
n=13;allp=(1<<n)-1
line=[sum(1<<((l+d)%13) for d in [0,1,3,9]) for l in range(13)]
neg=[]
for P in range(1<<13):
 miss=sum(1<<l for l in range(13) if not P&line[l])
 closure=allp
 for l in range(13):
  if miss>>l&1:closure &= allp^line[l]
 if closure!=P:continue
 collinear=any(P&~s==0 for s in line)
 concurrent=any(all(not(miss>>l&1) or line[l]>>v&1 for l in range(13)) for v in range(13))
 if collinear or concurrent:neg.append(P|(miss<<13))
print('degenerate maximal negatives',len(neg))
best=[]; candidates=[]
# Candidate patches consisting of pointcenters. Optimize DNF rectangle covers first.
for k in range(2,7):
 found=None;hist={}
 for centers in itertools.combinations(range(13),k):
  live=sorted({l for p in centers for l,s in enumerate(line) if s>>p&1})
  pick=list(centers)+[13+l for l in live]
  rows={sum(1<<i for i,w in enumerate(pick) if r>>w&1) for r in neg}
  rows=[r for r in rows if not any(r!=s and r&~s==0 for s in rows)]
  pairs=[(p,l) for p in centers for l in live if line[l]>>p&1]
  # Maximal allowed B forA; no dontcare advantages assumed.
  rect=[]
  for A in range(1,1<<k):
   B=(1<<len(live))-1
   for row in rows:
    if row&A:B&=~(row>>k)
   cover=sum(1<<i for i,(p,l) in enumerate(pairs) if A>>centers.index(p)&1 and B>>live.index(l)&1)
   if cover:rect.append((cover,A.bit_count()+B.bit_count()))
  # Only detect an easy strict improvement vs allpointstars using up to3rectangles.
  full=(1<<len(pairs))-1;target=5*k
  improves=False
  for a in range(len(rect)):
   ca,va=rect[a]
   if ca==full and va<target:improves=True;break
   for b in range(a):
    cb,vb=rect[b]
    if ca|cb==full and va+vb<target:improves=True;break
   if improves:break
  hist[len(rows)]=hist.get(len(rows),0)+1
  if k==5 and len(rows)==30 and not candidates:candidates.append({'centers':centers,'live':live,'rows':rows})
  if improves:found={'centers':centers,'live':live,'rows':rows,'rect':rect};break
 print('k',k,'projectionhist',hist,'easyimprovement',bool(found),flush=True)
 if found:best.append(found)
json.dump({'neg':neg,'line':line,'easy':best,'candidates':candidates},open('./all-projections.json','w'))
