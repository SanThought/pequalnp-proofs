import json,random,subprocess,time
p='./';m=json.load(open(p+'patch-alt23-map.json'));best=json.load(open(p+'stochastic-best.json'));gs=best['gates'];n=best['n'];base=open(p+'patch-alt23.cnf').read().splitlines();head=base.pop(0).split();start=time.time()
# Baseline satisfiability and independent truth-table checks remain necessary for any witness.
for trial in range(18):
 free=set(random.sample(range(23),min(7+trial//6,12)));extra=[]
 for i,(sa,sb,op) in enumerate(m['gates']):
  if i in free:continue
  typ,a,b=gs[i];a,b=sorted([a,b]);extra.extend([[sa[a]],[sb[b]],[op if not typ else -op]])
 path=p+'repair.cnf'
 with open(path,'w') as f:
  f.write('p cnf '+head[2]+' '+str(int(head[3])+len(extra))+'\n');f.write('\n'.join(base)+'\n');f.writelines(' '.join(map(str,c))+' 0\n' for c in extra)
 out=subprocess.run(['cadical','-t','5',path],capture_output=True,text=True).stdout
 print('trial',trial,'free',sorted(free),'result',[x for x in out.splitlines() if x.startswith('s ')],flush=True)
 if 's SATISFIABLE' in out:
  open(p+'repair-sat.log','w').write(out);break
 if time.time()-start>105:break
