import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Data.Finset.Card
import Mathlib.Data.Fintype.Card
import Lean.Elab.Tactic.Omega

namespace Boundary1720

lemma bound {G W : Type*} [DecidableEq G] [DecidableEq W]
    (mixed : Finset G) (inputs : G → List W)
    (hfan : ∀ g ∈ mixed, (inputs g).length ≤ 2) :
    (mixed.biUnion fun g => (inputs g).toFinset).card ≤ 2*mixed.card := by
  have h1 := Finset.card_biUnion_le (s := mixed) (t := fun g => (inputs g).toFinset)
  have h2 : (∑ g ∈ mixed, (inputs g).toFinset.card) ≤ ∑ g ∈ mixed, 2 := by
    apply Finset.sum_le_sum
    intro g hg
    exact (List.toFinset_card_le _).trans (hfan g hg)
  have h3 : (∑ g ∈ mixed, (2 : ℕ)) = 2*mixed.card := by simp; omega
  omega

lemma assigned_groups {I H : Type*} [DecidableEq I] [DecidableEq H]
    (all : Finset H) (dest : H → I) (s : Finset I) :
    (s : Set I).PairwiseDisjoint (fun i => all.filter fun h => dest h = i) := by
  intro i hi j hj hij
  apply Finset.disjoint_left.mpr
  intro h hhi hhj
  exact hij ((Finset.mem_filter.mp hhi).2.symm.trans (Finset.mem_filter.mp hhj).2)

end Boundary1720
#print axioms Boundary1720.bound
