import Mathlib.Data.Finset.Card
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import PEqualNP.Defs

namespace UsedInputs1710
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

def used (C : Circuit) : Finset ℕ := (C.gates.flatMap fun g => g.inputs).toFinset

lemma flat_inputs_length (gs : List Gate) (hm : ∀ g ∈ gs, g.inputs.length ≤ 2) :
    (gs.flatMap fun g => g.inputs).length ≤ 2*gs.length := by
  induction gs with
  | nil => simp
  | cons g gs ih =>
    have h1 := hm g (by simp)
    have h2 := ih (fun a ha => hm a (by simp [ha]))
    simp only [List.flatMap_cons,List.length_append,List.length_cons]
    omega

lemma used_card (C : Circuit) (hm : Monotone2 C) : (used C).card ≤ 2*C.size := by
  have h1 : ∀ g ∈ C.gates, g.inputs.length ≤ 2 := fun g hg => (hm g hg).2
  have h2 := flat_inputs_length C.gates h1
  have h3 := List.toFinset_card_le (C.gates.flatMap fun g => g.inputs)
  change (C.gates.flatMap fun g => g.inputs).toFinset.card ≤ 2*C.gates.length
  omega

lemma mem_used (C : Circuit) (g : Gate) (hg : g ∈ C.gates) (w : ℕ) (hw : w ∈ g.inputs) : w ∈ used C := by
  simp only [used,List.mem_toFinset,List.mem_flatMap]
  exact ⟨g,hg,hw⟩


def activeInputs (n : ℕ) (C : Circuit) : Finset (Fin n) :=
  Finset.univ.filter fun v => v.val ∈ used C

lemma activeInputs_card (n : ℕ) (C : Circuit) (hm : Monotone2 C) :
    (activeInputs n C).card ≤ 2*C.size := by
  classical
  have hle : (activeInputs n C).card ≤ (used C).card := by
    apply Finset.card_le_card_of_injOn (fun v : Fin n => v.val)
    · intro v hv
      exact (Finset.mem_filter.mp hv).2
    · intro a ha b hb hab
      exact Fin.ext hab
  exact le_trans hle (used_card C hm)

end UsedInputs1710
#print axioms UsedInputs1710.used_card

#print axioms UsedInputs1710.activeInputs_card
