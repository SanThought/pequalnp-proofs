import Mathlib.Data.Finset.Prod
import Mathlib.Data.Finset.Card
import Mathlib.Data.Fintype.Card
import Lean.Elab.Tactic.Omega
import Mathlib.Tactic.Tauto

namespace ThreeClauses1710

variable {V : Type*} [DecidableEq V]

def accepts (A B C : Finset V) (u v : V) : Prop :=
  (u ∈ A ∨ v ∈ A) ∧ (u ∈ B ∨ v ∈ B) ∧ (u ∈ C ∨ v ∈ C)

lemma pair_decomposition (A B C : Finset V)
    (noSingleton : ∀ u, ¬ (u ∈ A ∧ u ∈ B ∧ u ∈ C)) (u v : V) :
    accepts A B C u v ↔
      (u ∈ A ∩ B ∧ v ∈ C) ∨ (v ∈ A ∩ B ∧ u ∈ C) ∨
      (u ∈ A ∩ C ∧ v ∈ B) ∨ (v ∈ A ∩ C ∧ u ∈ B) ∨
      (u ∈ B ∩ C ∧ v ∈ A) ∨ (v ∈ B ∩ C ∧ u ∈ A) := by
  have hu := noSingleton u
  have hv := noSingleton v
  simp only [accepts, Finset.mem_inter]
  tauto

lemma three_rectangles_sound (I : V → V → Prop) (A B C : Finset V)
    (sound : ∀ u v, accepts A B C u v → I u v) :
    (∀ u ∈ A ∩ B, ∀ v ∈ C, I u v) ∧
    (∀ u ∈ A ∩ C, ∀ v ∈ B, I u v) ∧
    (∀ u ∈ B ∩ C, ∀ v ∈ A, I u v) := by
  simp only [Finset.mem_inter]
  refine ⟨?_,?_,?_⟩
  · intro u hu v hv
    apply sound
    exact ⟨Or.inl hu.1, Or.inl hu.2, Or.inr hv⟩
  · intro u hu v hv
    apply sound
    exact ⟨Or.inl hu.1, Or.inr hv, Or.inl hu.2⟩
  · intro u hu v hv
    apply sound
    exact ⟨Or.inr hv, Or.inl hu.1, Or.inl hu.2⟩


lemma rectangle_thin (I : V → V → Prop)
    (noFour : ∀ a c b d, a ≠ c → b ≠ d → ¬(I a b ∧ I a d ∧ I c b ∧ I c d))
    (A B : Finset V) (sound : ∀ a ∈ A, ∀ b ∈ B, I a b) :
    A.card ≤ 1 ∨ B.card ≤ 1 := by
  by_cases ha : A.card ≤ 1
  · exact Or.inl ha
  · right
    apply Finset.card_le_one.mpr
    intro b hb d hd
    by_contra hbd
    obtain ⟨a,ha,c,hc,hac⟩ := Finset.one_lt_card.mp (by omega : 1 < A.card)
    exact noFour a c b d hac hbd ⟨sound a ha b hb,sound a ha d hd,sound c hc b hb,sound c hc d hd⟩

lemma rectangle_budget [Fintype V] (I : V → V → Prop)
    (noFour : ∀ a c b d, a ≠ c → b ≠ d → ¬(I a b ∧ I a d ∧ I c b ∧ I c d))
    (A B : Finset V) (sound : ∀ a ∈ A, ∀ b ∈ B, I a b) :
    (A ×ˢ B).card ≤ Fintype.card V := by
  rw [Finset.card_product]
  rcases rectangle_thin I noFour A B sound with ha | hb
  · calc
      A.card * B.card ≤ 1 * B.card := Nat.mul_le_mul_right _ ha
      _ = B.card := Nat.one_mul _
      _ ≤ Fintype.card V := Finset.card_le_univ _
  · calc
      A.card * B.card ≤ A.card * 1 := Nat.mul_le_mul_left _ hb
      _ = A.card := Nat.mul_one _
      _ ≤ Fintype.card V := Finset.card_le_univ _


lemma accepted_pairs_budget [Fintype V] (I : V → V → Prop)
    (noFour : ∀ a c b d, a ≠ c → b ≠ d → ¬(I a b ∧ I a d ∧ I c b ∧ I c d))
    (A B C : Finset V)
    (noSingleton : ∀ u, ¬ (u ∈ A ∧ u ∈ B ∧ u ∈ C))
    (sound : ∀ u v, accepts A B C u v → I u v)
    (E : Finset (V × V)) (covered : ∀ p ∈ E, accepts A B C p.1 p.2) :
    E.card ≤ 6 * Fintype.card V := by
  classical
  have hs := three_rectangles_sound I A B C sound
  let F1 := (A ∩ B) ×ˢ C
  let F2 := C ×ˢ (A ∩ B)
  let F3 := (A ∩ C) ×ˢ B
  let F4 := B ×ˢ (A ∩ C)
  let F5 := (B ∩ C) ×ˢ A
  let F6 := A ×ˢ (B ∩ C)
  have h1 : F1.card ≤ Fintype.card V := rectangle_budget I noFour _ _ hs.1
  have h3 : F3.card ≤ Fintype.card V := rectangle_budget I noFour _ _ hs.2.1
  have h5 : F5.card ≤ Fintype.card V := rectangle_budget I noFour _ _ hs.2.2
  have h2 : F2.card = F1.card := by simp [F1,F2,Finset.card_product,Nat.mul_comm]
  have h4 : F4.card = F3.card := by simp [F3,F4,Finset.card_product,Nat.mul_comm]
  have h6 : F6.card = F5.card := by simp [F5,F6,Finset.card_product,Nat.mul_comm]
  have hsub : E ⊆ F1 ∪ F2 ∪ F3 ∪ F4 ∪ F5 ∪ F6 := by
    intro p hp
    have h := (pair_decomposition A B C noSingleton p.1 p.2).mp (covered p hp)
    simp only [F1,F2,F3,F4,F5,F6,Finset.mem_union,Finset.mem_product]
    tauto
  have hle := Finset.card_le_card hsub
  have hu1 := Finset.card_union_le F1 F2
  have hu2 := Finset.card_union_le (F1 ∪ F2) F3
  have hu3 := Finset.card_union_le (F1 ∪ F2 ∪ F3) F4
  have hu4 := Finset.card_union_le (F1 ∪ F2 ∪ F3 ∪ F4) F5
  have hu5 := Finset.card_union_le (F1 ∪ F2 ∪ F3 ∪ F4 ∪ F5) F6
  omega

lemma triple_intersection_empty (A B C : Finset V)
    (noSingleton : ∀ u, ¬ accepts A B C u u) : A ∩ B ∩ C = ∅ := by
  apply Finset.eq_empty_iff_forall_notMem.mpr
  intro u hu
  have h := Finset.mem_inter.mp hu
  have hab := Finset.mem_inter.mp h.1
  exact noSingleton u ⟨Or.inl hab.1, Or.inl hab.2, Or.inl h.2⟩

lemma one_inner_and_truth (a b c d : Bool) :
    (((a && b) || c) && d) = ((a && b && d) || (c && d)) := by
  cases a <;> cases b <;> cases c <;> cases d <;> rfl

lemma two_inner_reads_truth (a b c d : Bool) :
    (((a && b) || c) && ((a && b) || d)) =
      ((a && b) || (c && d)) := by
  cases a <;> cases b <;> cases c <;> cases d <;> rfl

end ThreeClauses1710
#print axioms ThreeClauses1710.pair_decomposition
#print axioms ThreeClauses1710.three_rectangles_sound

#print axioms ThreeClauses1710.accepted_pairs_budget

#print axioms ThreeClauses1710.two_inner_reads_truth
