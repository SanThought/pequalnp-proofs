import Mathlib.Data.Fintype.Prod
import Mathlib.Data.Fintype.Sets
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Lean.Elab.Tactic.Omega
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Fintype.Powerset
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Card
import Mathlib.Tactic.Tauto
import Mathlib.Combinatorics.SimpleGraph.Acyclic
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Data.List.FinRange
import Mathlib.Tactic.Push
import Mathlib.Tactic.ByContra
import Lean.Elab.Tactic.Omega
import PEqualNP.Defs

namespace CNF1710
variable {V K : Type*} [DecidableEq V] [DecidableEq K] [Fintype K]

def accepts (clause : K → Finset V) (u v : V) : Prop :=
  ∀ k, u ∈ clause k ∨ v ∈ clause k

def leftSet [Fintype V] (clause : K → Finset V) (T : Finset K) : Finset V :=
  Finset.univ.filter fun v => ∀ k ∈ T, v ∈ clause k

def rightSet [Fintype V] (clause : K → Finset V) (T : Finset K) : Finset V :=
  Finset.univ.filter fun v => ∀ k, k ∉ T → v ∈ clause k

lemma decomposition [Fintype V] (clause : K → Finset V) (u v : V) :
    accepts clause u v ↔ ∃ T : Finset K, u ∈ leftSet clause T ∧ v ∈ rightSet clause T := by
  classical
  constructor
  · intro h
    let T := Finset.univ.filter fun k => u ∈ clause k
    refine ⟨T,?_,?_⟩
    · simp only [leftSet,Finset.mem_filter,Finset.mem_univ,true_and]
      intro k hk
      exact (Finset.mem_filter.mp hk).2
    · simp only [rightSet,Finset.mem_filter,Finset.mem_univ,true_and]
      intro k hk
      have hku : u ∉ clause k := by simpa [T] using hk
      exact (h k).resolve_left hku
  · rintro ⟨T,hu,hv⟩ k
    have hu' := (Finset.mem_filter.mp hu).2
    have hv' := (Finset.mem_filter.mp hv).2
    by_cases hk : k ∈ T
    · exact Or.inl (hu' k hk)
    · exact Or.inr (hv' k hk)

lemma rectangle_sound [Fintype V] (clause : K → Finset V) (I : V → V → Prop)
    (sound : ∀ u v, accepts clause u v → I u v) (T : Finset K) :
    ∀ u ∈ leftSet clause T, ∀ v ∈ rightSet clause T, I u v := by
  intro u hu v hv
  exact sound u v ((decomposition clause u v).mpr ⟨T,hu,hv⟩)

lemma expanded_two_clause (a b c : Prop) : (a ∧ b) ∨ c ↔ (a ∨ c) ∧ (b ∨ c) := by tauto

lemma expanded_outer_four (a b c d : Prop) :
    ((a ∧ b) ∨ c) ∧ ((a ∧ b) ∨ d) ↔
      (a ∨ c) ∧ (b ∨ c) ∧ (a ∨ d) ∧ (b ∨ d) := by tauto

lemma rectangle_thin [Fintype V] (I : V → V → Prop)
    (noFour : ∀ a c b d, a ≠ c → b ≠ d → ¬(I a b ∧ I a d ∧ I c b ∧ I c d))
    (A B : Finset V) (sound : ∀ a ∈ A, ∀ b ∈ B, I a b) :
    (A ×ˢ B).card ≤ Fintype.card V := by
  rw [Finset.card_product]
  by_cases ha : A.card ≤ 1
  · calc
      A.card * B.card ≤ 1 * B.card := Nat.mul_le_mul_right _ ha
      _ = B.card := Nat.one_mul _
      _ ≤ Fintype.card V := Finset.card_le_univ _
  · have hb : B.card ≤ 1 := by
      apply Finset.card_le_one.mpr
      intro b hb d hd
      by_contra hbd
      obtain ⟨a,ha,c,hc,hac⟩ := Finset.one_lt_card.mp (by omega : 1 < A.card)
      exact noFour a c b d hac hbd ⟨sound a ha b hb,sound a ha d hd,sound c hc b hb,sound c hc d hd⟩
    calc
      A.card * B.card ≤ A.card * 1 := Nat.mul_le_mul_left _ hb
      _ = A.card := Nat.mul_one _
      _ ≤ Fintype.card V := Finset.card_le_univ _

lemma count [Fintype V] (clause : K → Finset V) (I : V → V → Prop)
    (noFour : ∀ a c b d, a ≠ c → b ≠ d → ¬(I a b ∧ I a d ∧ I c b ∧ I c d))
    (sound : ∀ u v, accepts clause u v → I u v)
    (E : Finset (V × V)) (cover : ∀ p ∈ E, accepts clause p.1 p.2) :
    E.card ≤ 2 ^ Fintype.card K * Fintype.card V := by
  classical
  let R := fun T : Finset K => leftSet clause T ×ˢ rightSet clause T
  have hsub : E ⊆ Finset.univ.biUnion R := by
    intro p hp
    obtain ⟨T,hu,hv⟩ := (decomposition clause p.1 p.2).mp (cover p hp)
    exact Finset.mem_biUnion.mpr ⟨T,Finset.mem_univ _,Finset.mem_product.mpr ⟨hu,hv⟩⟩
  have hR : ∀ T, (R T).card ≤ Fintype.card V := fun T =>
    rectangle_thin I noFour _ _ (rectangle_sound clause I sound T)
  calc
    E.card ≤ (Finset.univ.biUnion R).card := Finset.card_le_card hsub
    _ ≤ ∑ T : Finset K, (R T).card := Finset.card_biUnion_le
    _ ≤ ∑ T : Finset K, Fintype.card V := Finset.sum_le_sum (fun T _ => hR T)
    _ = 2 ^ Fintype.card K * Fintype.card V := by simp

lemma count_on_support [Fintype V] (clause : K → Finset V) (I : V → V → Prop)
    (noFour : ∀ a c b d, a ≠ c → b ≠ d → ¬(I a b ∧ I a d ∧ I c b ∧ I c d))
    (sound : ∀ u v, accepts clause u v → I u v)
    (U : Finset V) (E : Finset (V × V))
    (inU : ∀ p ∈ E, p.1 ∈ U ∧ p.2 ∈ U)
    (cover : ∀ p ∈ E, accepts clause p.1 p.2) :
    E.card ≤ 2 ^ Fintype.card K * U.card := by
  classical
  let lift : U → V := fun v => v.val
  let clause' : K → Finset U := fun k => Finset.univ.filter fun v => v.val ∈ clause k
  let E' : Finset (U × U) := Finset.univ.filter fun p => (p.1.val,p.2.val) ∈ E
  have inj : Function.Injective (fun p : U × U => (p.1.val,p.2.val)) := by
    intro a b h
    exact Prod.ext (Subtype.ext (Prod.mk.inj h).1) (Subtype.ext (Prod.mk.inj h).2)
  have im : E'.image (fun p => (p.1.val,p.2.val)) = E := by
    ext p
    constructor
    · rintro hp
      obtain ⟨q,hq,rfl⟩ := Finset.mem_image.mp hp
      exact (Finset.mem_filter.mp hq).2
    · intro hp
      exact Finset.mem_image.mpr ⟨(⟨p.1,(inU p hp).1⟩,⟨p.2,(inU p hp).2⟩),by simp [E',hp],rfl⟩
  have he : E'.card = E.card := by
    rw [←im,Finset.card_image_iff.mpr (fun a _ b _ h => inj h)]
  have hn : ∀ a c b d : U, a ≠ c → b ≠ d →
      ¬(I a.val b.val ∧ I a.val d.val ∧ I c.val b.val ∧ I c.val d.val) := by
    intro a c b d hac hbd
    exact noFour a.val c.val b.val d.val
      (fun h => hac (Subtype.ext h)) (fun h => hbd (Subtype.ext h))
  have hs : ∀ u v : U, accepts clause' u v → I u.val v.val := by
    intro u v h
    apply sound
    intro k
    have h' := h k
    simpa only [clause',Finset.mem_filter,Finset.mem_univ,true_and] using h'
  have hc : ∀ p ∈ E', accepts clause' p.1 p.2 := by
    intro p hp k
    have h := cover (p.1.val,p.2.val) ((Finset.mem_filter.mp hp).2) k
    simpa only [clause',Finset.mem_filter,Finset.mem_univ,true_and] using h
  have bound := count clause' (fun u v => I u.val v.val) hn hs E' hc
  rw [he] at bound
  simpa using bound

end CNF1710

namespace Zero1764

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.MetaComplexity.NestedCover

attribute [local instance] gateOpDecEq

def stepWire (w : List Bool) (g : Gate) : List Bool :=
  w ++ [g.op.eval (g.inputs.map fun i => w.getD i false)]

lemma wires_eq_foldl (C : Circuit) (x : List Bool) :
    C.wires x = C.gates.foldl stepWire x := rfl

lemma foldl_stepWire_length (gs : List Gate) (w : List Bool) :
    (gs.foldl stepWire w).length = w.length + gs.length := by
  induction gs generalizing w with
  | nil => simp
  | cons g gs ih =>
    rw [List.foldl_cons, ih]
    simp [stepWire]
    omega

lemma foldl_stepWire_getD_lt (gs : List Gate) (w : List Bool) (i : ℕ) (hi : i < w.length) :
    (gs.foldl stepWire w).getD i false = w.getD i false := by
  induction gs generalizing w with
  | nil => rfl
  | cons g gs ih =>
    simp only [List.foldl_cons]
    have hlt : i < (stepWire w g).length := by simp [stepWire]; omega
    rw [ih (stepWire w g) hlt]
    simp [stepWire, List.getD_eq_getElem?_getD, List.getElem?_append_left hi]

lemma getD_ge_length (w : List Bool) (i : ℕ) (hi : w.length ≤ i) :
    w.getD i false = false := by
  simp [List.getD_eq_getElem?_getD, List.getElem?_eq_none hi]

lemma wires_length (n : ℕ) (C : Circuit) (x : Fin n → Bool) :
    (C.wires (List.ofFn x)).length = n + C.gates.length := by
  rw [wires_eq_foldl, foldl_stepWire_length, List.length_ofFn]

lemma split_gates (gs : List Gate) (j : ℕ) (hj : j < gs.length) :
    ∃ (pre post : List Gate) (gj : Gate),
      gs = pre ++ gj :: post ∧ pre.length = j ∧ gs[j]'hj = gj := by
  refine ⟨gs.take j, gs.drop (j + 1), gs[j]'hj, ?_, by simp; omega, rfl⟩
  rw [List.cons_getElem_drop_succ, List.take_append_drop]

def W (n : ℕ) (C : Circuit) (x : Fin n → Bool) (u : ℕ) : Bool :=
  (C.wires (List.ofFn x)).getD u false

lemma gateAt_eq (C : Circuit) (k : ℕ) (hk : k < C.gates.length) : gateAt C k = C.gates[k] := by
  simp [gateAt, List.getD_eq_getElem?_getD, hk]

lemma W_gate (n : ℕ) (C : Circuit) (x : Fin n → Bool) (k : ℕ) (hk : k < C.gates.length) :
    W n C x (n + k) = (gateAt C k).op.eval ((gateAt C k).inputs.map fun i =>
      if i < n + k then W n C x i else false) := by
  obtain ⟨pre, post, gj, hgs, hpre_len, hgj⟩ := split_gates C.gates k hk
  have hga : gateAt C k = gj := by rw [gateAt_eq C k hk]; exact hgj
  rw [hga]
  let w0 := pre.foldl stepWire (List.ofFn x)
  have hw0_len : w0.length = n + k := by
    simp [w0, foldl_stepWire_length, hpre_len]
  have hCj : W n C x (n + k) = gj.op.eval (gj.inputs.map fun i => w0.getD i false) := by
    simp only [W]
    rw [wires_eq_foldl, hgs, List.foldl_append, List.foldl_cons]
    rw [foldl_stepWire_getD_lt post (stepWire w0 gj) (n + k) (by simp [stepWire]; omega)]
    simp [stepWire, List.getD_eq_getElem?_getD, hw0_len]
  rw [hCj]
  congr 1
  refine List.map_congr_left fun i _ => ?_
  by_cases hi : i < n + k
  · simp only [hi, ↓reduceIte]
    simp only [W]
    rw [wires_eq_foldl, hgs, List.foldl_append]
    exact (foldl_stepWire_getD_lt (gj :: post) w0 i (by omega)).symm
  · simp only [hi, ↓reduceIte]
    exact getD_ge_length w0 i (by omega)

lemma W_input (n : ℕ) (C : Circuit) (x : Fin n → Bool) (u : ℕ) (hu : u < n) :
    W n C x u = x ⟨u, hu⟩ := by
  simp only [W]
  rw [wires_eq_foldl, foldl_stepWire_getD_lt C.gates (List.ofFn x) u (by simpa using hu)]
  simp [List.getD_eq_getElem?_getD, hu]

lemma W_or (n : ℕ) (C : Circuit) (x : Fin n → Bool) (k : ℕ) (hk : k < C.gates.length)
    (hop : (gateAt C k).op = GateOp.or) (a b : ℕ) (hin : (gateAt C k).inputs = [a, b])
    (ha : a < n + k) (hb : b < n + k) :
    W n C x (n + k) = (W n C x a || W n C x b) := by
  rw [W_gate n C x k hk, hop, hin]
  simp [GateOp.eval, ha, hb]

lemma W_and (n : ℕ) (C : Circuit) (x : Fin n → Bool) (k : ℕ) (hk : k < C.gates.length)
    (hop : (gateAt C k).op = GateOp.and) (a b : ℕ) (hin : (gateAt C k).inputs = [a, b])
    (ha : a < n + k) (hb : b < n + k) :
    W n C x (n + k) = (W n C x a && W n C x b) := by
  rw [W_gate n C x k hk, hop, hin]
  simp [GateOp.eval, ha, hb]

open PEqualNP.EdgeOwnership in
lemma coneFold_length (n : ℕ) (gs : List Gate) (cs : List (List ℕ)) :
    (gs.foldl (coneStep n) cs).length = cs.length + gs.length := by
  induction gs generalizing cs with
  | nil => simp
  | cons g gs ih =>
    rw [List.foldl_cons, ih]
    simp [coneStep]
    omega

open PEqualNP.EdgeOwnership in
lemma coneStep_getD_last (n : ℕ) (cs : List (List ℕ)) (g : Gate) :
    (coneStep n cs g).getD cs.length [] =
      (g.inputs.filter (fun w => decide (n ≤ w ∧ w < n + cs.length))).flatMap
        (fun w => (w - n) :: cs.getD (w - n) []) := by
  simp [coneStep, List.getD_eq_getElem?_getD]

open PEqualNP.EdgeOwnership in
lemma coneStep_getD_lt (n : ℕ) (cs : List (List ℕ)) (g : Gate) (m : ℕ) (hm : m < cs.length) :
    (coneStep n cs g).getD m [] = cs.getD m [] := by
  simp [coneStep, List.getD_eq_getElem?_getD, List.getElem?_append_left hm]

open PEqualNP.EdgeOwnership in
lemma coneFold_getD_lt (n : ℕ) (gs : List Gate) (cs : List (List ℕ)) (k : ℕ)
    (hk : k < cs.length) :
    (gs.foldl (coneStep n) cs).getD k [] = cs.getD k [] := by
  induction gs generalizing cs with
  | nil => rfl
  | cons g gs ih =>
    simp only [List.foldl_cons]
    rw [ih (coneStep n cs g) (by simp [coneStep]; omega)]
    exact coneStep_getD_lt n cs g k hk

open PEqualNP.EdgeOwnership in
lemma inCone_iff (n : ℕ) (C : Circuit) (i k : ℕ) (hk : k < C.gates.length) :
    InCone n C i k ↔ ∃ w ∈ (gateAt C k).inputs, n ≤ w ∧ w < n + k ∧
      (i = w - n ∨ InCone n C i (w - n)) := by
  obtain ⟨pre, post, gk, hgs, hpre_len, hgk⟩ := split_gates C.gates k hk
  have hga : gateAt C k = gk := by rw [gateAt_eq C k hk]; exact hgk
  rw [hga]
  have hc : cones n C = post.foldl (coneStep n) (coneStep n (pre.foldl (coneStep n) []) gk) := by
    simp only [cones]
    rw [hgs, List.foldl_append, List.foldl_cons]
  have hl0 : (pre.foldl (coneStep n) []).length = k := by
    rw [coneFold_length]; simp [hpre_len]
  have hl1 : (coneStep n (pre.foldl (coneStep n) []) gk).length = k + 1 := by
    simp [coneStep, hl0]
  have h1 : (cones n C).getD k [] =
      (gk.inputs.filter (fun w => decide (n ≤ w ∧ w < n + k))).flatMap
        (fun w => (w - n) :: (pre.foldl (coneStep n) []).getD (w - n) []) := by
    rw [hc, coneFold_getD_lt n post _ k (by omega)]
    have h := coneStep_getD_last n (pre.foldl (coneStep n) []) gk
    rw [hl0] at h
    exact h
  have h2 : ∀ m, m < k → (cones n C).getD m [] = (pre.foldl (coneStep n) []).getD m [] := by
    intro m hm
    rw [hc, coneFold_getD_lt n post _ m (by omega)]
    exact coneStep_getD_lt n _ gk m (by omega)
  unfold InCone
  rw [h1]
  simp only [List.mem_flatMap, List.mem_filter, decide_eq_true_eq, List.mem_cons]
  constructor
  · rintro ⟨w, ⟨hw, hn, hlt⟩, h⟩
    refine ⟨w, hw, hn, hlt, ?_⟩
    rcases h with h | h
    · exact Or.inl h
    · right
      rw [h2 (w - n) (by omega)]
      exact h
  · rintro ⟨w, hw, hn, hlt, h⟩
    refine ⟨w, ⟨hw, hn, hlt⟩, ?_⟩
    rcases h with h | h
    · exact Or.inl h
    · right
      rw [← h2 (w - n) (by omega)]
      exact h


lemma ite_true_iff (c : Prop) [Decidable c] (b : Bool) :
    (if c then b else false) = true ↔ c ∧ b = true := by
  by_cases h : c <;> simp [h]

lemma W_and_iff (n : ℕ) (C : Circuit) (x : Fin n → Bool) (k : ℕ) (hk : k < C.gates.length)
    (hop : (gateAt C k).op = GateOp.and) :
    W n C x (n + k) = true ↔ ∀ w ∈ (gateAt C k).inputs, w < n + k ∧ W n C x w = true := by
  rw [W_gate n C x k hk, hop]
  simp only [GateOp.eval, List.all_eq_true, List.mem_map, id_eq]
  constructor
  · intro h w hw
    exact (ite_true_iff _ _).mp (h _ ⟨w, hw, rfl⟩)
  · rintro h b ⟨w, hw, rfl⟩
    exact (ite_true_iff _ _).mpr (h w hw)

lemma W_or_iff (n : ℕ) (C : Circuit) (x : Fin n → Bool) (k : ℕ) (hk : k < C.gates.length)
    (hop : (gateAt C k).op = GateOp.or) :
    W n C x (n + k) = true ↔ ∃ w ∈ (gateAt C k).inputs, w < n + k ∧ W n C x w = true := by
  rw [W_gate n C x k hk, hop]
  simp only [GateOp.eval, List.any_eq_true, List.mem_map, id_eq]
  constructor
  · rintro ⟨b, ⟨w, hw, rfl⟩, h⟩
    exact ⟨w, hw, (ite_true_iff _ _).mp h⟩
  · rintro ⟨w, hw, h⟩
    exact ⟨_, ⟨w, hw, rfl⟩, (ite_true_iff _ _).mpr h⟩

open PEqualNP.EdgeOwnership in
lemma inCone_lt (n : ℕ) (C : Circuit) :
    ∀ k, k < C.gates.length → ∀ i, InCone n C i k → i < k := by
  intro k
  induction k using Nat.strong_induction_on with
  | _ k ih =>
    intro hk i hi
    obtain ⟨w, _, hn, hlt, h⟩ := (inCone_iff n C i k hk).mp hi
    rcases h with h | h
    · omega
    · have := ih (w - n) (by omega) (by omega) i h
      omega

lemma gate_mono2 (C : Circuit) (hM : Monotone2 C) (k : ℕ) (hk : k < C.gates.length) :
    ((gateAt C k).op = GateOp.and ∨ (gateAt C k).op = GateOp.or) ∧
      (gateAt C k).inputs.length ≤ 2 := by
  have hg := hM (C.gates[k]) (List.getElem_mem hk)
  rw [← gateAt_eq C k hk] at hg
  have h1 := hg.1
  rw [Set.mem_insert_iff, Set.mem_singleton_iff] at h1
  exact ⟨h1, hg.2⟩

def Dom (n : ℕ) (C : Circuit) (t : Fin n) (w : ℕ) : Prop :=
  ∀ y : Fin n → Bool, y t = true → W n C y w = true



open PEqualNP.EdgeOwnership in
lemma no_nested (n : ℕ) (C : Circuit) (h : PEqualNP.TopForm.andPairs n C = 0)
    (i j : ℕ) (hi : i < C.gates.length) (hj : j < C.gates.length)
    (hai : (gateAt C i).op = GateOp.and) (haj : (gateAt C j).op = GateOp.and) :
    ¬ InCone n C i j := by
  intro hc
  have hp : 0 < PEqualNP.TopForm.andPairs n C := by
    unfold PEqualNP.TopForm.andPairs
    exact Finset.card_pos.mpr ⟨(i,j), by simp [hi,hj,hai,haj,hc]⟩
  omega

lemma last_and_or_single (n : ℕ) (C : Circuit) (hM : Monotone2 C) (x : Fin n → Bool) :
    ∀ w, W n C x w = true →
      (∃ t : Fin n, x t = true ∧ Dom n C t w) ∨
      ∃ j, j < C.gates.length ∧ (gateAt C j).op = GateOp.and ∧
        W n C x (n+j) = true ∧
        ∀ y : Fin n → Bool, W n C y (n+j) = true → W n C y w = true := by
  intro w
  induction w using Nat.strong_induction_on with
  | ind w ih =>
    intro hx
    by_cases hwn : w < n
    · left
      refine ⟨⟨w,hwn⟩, ?_, ?_⟩
      · simpa [W_input n C x w hwn] using hx
      · intro y hy
        simpa [W_input n C y w hwn] using hy
    · by_cases hbig : n+C.gates.length ≤ w
      · have hf : W n C x w = false := by
          unfold W
          exact getD_ge_length _ _ (by rw [wires_length]; exact hbig)
        rw [hf] at hx
        cases hx
      · have hk : w-n < C.gates.length := by omega
        have hw : w = n+(w-n) := by omega
        rcases (gate_mono2 C hM (w-n) hk).1 with hop | hop
        · right
          exact ⟨w-n,hk,hop,by simpa [←hw] using hx,fun y hy => by simpa [←hw] using hy⟩
        · have hx' : W n C x (n+(w-n)) = true := by simpa [←hw] using hx
          obtain ⟨a,ha,halt,hax⟩ := (W_or_iff n C x (w-n) hk hop).mp hx'
          rcases ih a (by omega) hax with ⟨t,ht,hd⟩ | ⟨j,hj,hja,hjx,hdom⟩
          · left
            exact ⟨t,ht,fun y hy => by
              rw [hw]
              exact (W_or_iff n C y (w-n) hk hop).mpr ⟨a,ha,halt,hd y hy⟩⟩
          · right
            exact ⟨j,hj,hja,hjx,fun y hy => by
              rw [hw]
              exact (W_or_iff n C y (w-n) hk hop).mpr ⟨a,ha,halt,hdom y hy⟩⟩


open PEqualNP.EdgeOwnership in
lemma owns_of_zero (n : ℕ) (C : Circuit) (hz : PEqualNP.TopForm.andPairs n C = 0)
    (j : ℕ) (hj : j < C.gates.length) (ha : (gateAt C j).op = GateOp.and)
    (u v : Fin n) (hv : W n C (pairInput u v) (n+j) = true) : Owns n C j u v := by
  refine ⟨hj,ha,hv,?_⟩
  intro i hi hc hai
  exact False.elim (no_nested n C hz i j (by omega) hj hai ha hc)

lemma graph_pair (n : ℕ) (G : SimpleGraph (Fin n)) [DecidableRel G.Adj] (u v : Fin n)
    (h : graphFun G ∅ (PEqualNP.EdgeOwnership.pairInput u v) = true) : G.Adj u v := by
  have h' : ∃ a b, G.Adj a b ∧ PEqualNP.EdgeOwnership.pairInput u v a = true ∧
      PEqualNP.EdgeOwnership.pairInput u v b = true := by
    simpa [graphFun] using h
  obtain ⟨a,b,hab,ha,hb⟩ := h'
  have ha' : a = u ∨ a = v := by simpa [PEqualNP.EdgeOwnership.pairInput] using ha
  have hb' : b = u ∨ b = v := by simpa [PEqualNP.EdgeOwnership.pairInput] using hb
  rcases ha' with rfl | rfl <;> rcases hb' with rfl | rfl
  · exact False.elim (G.loopless.irrefl _ hab)
  · exact hab
  · exact G.symm.symm _ _ hab
  · exact False.elim (G.loopless.irrefl _ hab)


lemma output_eq (n : ℕ) (C : Circuit) (x : Fin n → Bool) :
    circuitFun n C x = W n C x C.output := rfl

open PEqualNP.EdgeOwnership in
lemma every_edge_last_and (n : ℕ) (G : SimpleGraph (Fin n)) [DecidableRel G.Adj]
    (C : Circuit) (hM : Monotone2 C) (hF : circuitFun n C = graphFun G ∅)
    (u v : Fin n) (huv : G.Adj u v) :
    ∃ j : Fin C.gates.length, (gateAt C j).op = GateOp.and ∧ gateVal n C j (pairInput u v) = true ∧
      ∀ p q : Fin n, gateVal n C j (pairInput p q) = true → G.Adj p q := by
  have hout : W n C (pairInput u v) C.output = true := by
    rw [← output_eq, hF]
    have hx : ∃ a b, G.Adj a b ∧ pairInput u v a = true ∧ pairInput u v b = true :=
      ⟨u,v,huv,by simp [pairInput],by simp [pairInput]⟩
    simpa [graphFun] using hx
  rcases last_and_or_single n C hM (pairInput u v) C.output hout with ⟨t,ht,hd⟩ | ⟨j,hj,ha,hval,hdom⟩
  · have hg : graphFun G ∅ (pairInput t t) = true := by
      rw [←hF,output_eq]
      exact hd _ (by simp [pairInput])
    have := graph_pair n G t t hg
    exact False.elim (G.loopless.irrefl _ this)
  · refine ⟨⟨j,hj⟩,ha,hval,?_⟩
    intro p q hpq
    apply graph_pair n G p q
    rw [←hF,output_eq]
    exact hdom _ hpq

open PEqualNP.EdgeOwnership in
lemma every_edge_clean_owner (n : ℕ) (G : SimpleGraph (Fin n)) [DecidableRel G.Adj]
    (C : Circuit) (hM : Monotone2 C) (hF : circuitFun n C = graphFun G ∅)
    (hz : PEqualNP.TopForm.andPairs n C = 0) (u v : Fin n) (huv : G.Adj u v) :
    ∃ j : Fin C.gates.length, Owns n C j u v ∧
      ∀ p q : Fin n, gateVal n C j (pairInput p q) = true → G.Adj p q := by
  have hout : W n C (pairInput u v) C.output = true := by
    rw [← output_eq, hF]
    have hx : ∃ a b, G.Adj a b ∧ pairInput u v a = true ∧ pairInput u v b = true :=
      ⟨u,v,huv,by simp [pairInput],by simp [pairInput]⟩
    simpa [graphFun] using hx
  rcases last_and_or_single n C hM (pairInput u v) C.output hout with ⟨t,ht,hd⟩ | ⟨j,hj,ha,hval,hdom⟩
  · have hg : graphFun G ∅ (pairInput t t) = true := by
      rw [←hF,output_eq]
      exact hd _ (by simp [pairInput])
    have := graph_pair n G t t hg
    exact False.elim (G.loopless.irrefl _ this)
  · refine ⟨⟨j,hj⟩,owns_of_zero n C hz j hj ha u v hval,?_⟩
    intro p q hpq
    apply graph_pair n G p q
    rw [←hF,output_eq]
    exact hdom _ hpq


open PEqualNP.EdgeOwnership in
lemma unclean_count_zero (n : ℕ) (G : SimpleGraph (Fin n)) [DecidableRel G.Adj]
    (C : Circuit) (hM : Monotone2 C) (hF : circuitFun n C = graphFun G ∅)
    (hz : PEqualNP.TopForm.andPairs n C = 0) :
    {e ∈ G.edgeFinset | ¬∃ u v, e = s(u,v) ∧ ∃ j : Fin C.gates.length,
      Owns n C j u v ∧ ∀ p q, gateVal n C j (pairInput p q) = true → G.Adj p q}.card = 0 := by
  classical
  apply Finset.card_eq_zero.mpr
  apply Finset.eq_empty_iff_forall_notMem.mpr
  intro e he
  obtain ⟨he,hno⟩ := Finset.mem_filter.mp he
  induction e using Sym2.inductionOn with
  | _ u v =>
    have huv : G.Adj u v := by simpa using he
    obtain ⟨j,hj,hclean⟩ := every_edge_clean_owner n G C hM hF hz u v huv
    exact hno ⟨u,v,rfl,j,hj,hclean⟩

open PEqualNP.EdgeOwnership in
lemma unclean_edge_active_nested (n : ℕ) (G : SimpleGraph (Fin n)) [DecidableRel G.Adj]
    (C : Circuit) (hM : Monotone2 C) (hF : circuitFun n C = graphFun G ∅)
    (u v : Fin n) (huv : G.Adj u v)
    (hn : ¬∃ j : Fin C.gates.length, Owns n C j u v ∧
      ∀ p q, gateVal n C j (pairInput p q) = true → G.Adj p q) :
    ∃ i j : Fin C.gates.length, i.val < j.val ∧ InCone n C i j ∧
      (gateAt C i).op = GateOp.and ∧ (gateAt C j).op = GateOp.and ∧
      gateVal n C i (pairInput u v) = true ∧ gateVal n C j (pairInput u v) = true ∧
      (∀ p q, gateVal n C j (pairInput p q) = true → G.Adj p q) := by
  classical
  obtain ⟨j,hja,hjval,hclean⟩ := every_edge_last_and n G C hM hF u v huv
  have hno : ¬Owns n C j u v := fun h => hn ⟨j,h,hclean⟩
  have hex : ∃ i, i < j.val ∧ InCone n C i j ∧ (gateAt C i).op = GateOp.and ∧
      gateVal n C i (pairInput u v) = true := by
    by_contra h
    apply hno
    refine ⟨j.isLt,hja,hjval,?_⟩
    intro i hi hc ha
    cases hv : gateVal n C i (pairInput u v)
    · rfl
    · exact False.elim (h ⟨i,hi,hc,ha,hv⟩)
  obtain ⟨i,hi,hc,ha,hval⟩ := hex
  exact ⟨⟨i,by omega⟩,j,hi,hc,ha,hja,hval,hjval,hclean⟩

open PEqualNP.EdgeOwnership in
lemma one_nested_unique (n : ℕ) (C : Circuit) (h : PEqualNP.TopForm.andPairs n C = 1)
    (i j a b : ℕ) (hi : i < C.gates.length) (hj : j < C.gates.length)
    (ha : a < C.gates.length) (hb : b < C.gates.length)
    (hai : (gateAt C i).op = GateOp.and) (haj : (gateAt C j).op = GateOp.and)
    (haa : (gateAt C a).op = GateOp.and) (hab : (gateAt C b).op = GateOp.and)
    (hc : InCone n C i j) (hd : InCone n C a b) : i = a ∧ j = b := by
  let S := ((Finset.range C.gates.length ×ˢ Finset.range C.gates.length).filter fun (p : ℕ × ℕ) =>
    (gateAt C p.1).op = GateOp.and ∧ (gateAt C p.2).op = GateOp.and ∧ InCone n C p.1 p.2)
  have hcard : S.card ≤ 1 := by
    change PEqualNP.TopForm.andPairs n C ≤ 1
    omega
  have hm : (i,j) ∈ S := by simp [S,hi,hj,hai,haj,hc]
  have hn : (a,b) ∈ S := by simp [S,ha,hb,haa,hab,hd]
  have he := Finset.card_le_one.mp hcard _ hm _ hn
  exact Prod.mk.inj he

open PEqualNP.EdgeOwnership in
lemma inCone_trans (n : ℕ) (C : Circuit) :
    ∀ k, k < C.gates.length → ∀ i j, InCone n C i j → InCone n C j k → InCone n C i k := by
  intro k
  induction k using Nat.strong_induction_on with
  | ind k ih =>
    intro hk i j hij hjk
    obtain ⟨w,hw,hn,hlt,hj⟩ := (inCone_iff n C j k hk).mp hjk
    apply (inCone_iff n C i k hk).mpr
    refine ⟨w,hw,hn,hlt,Or.inr ?_⟩
    rcases hj with hj | hj
    · simpa [←hj] using hij
    · exact ih (w-n) (by omega) (by omega) i j hij hj

lemma or_atomic_form (n : ℕ) (C : Circuit) (hm : Monotone2 C)
    (P : ℕ → Prop) (i : ℕ)
    (ands : ∀ j, j < C.gates.length → P (n+j) →
      (gateAt C j).op = GateOp.and → j = i)
    (closed : ∀ j, j < C.gates.length → P (n+j) →
      ∀ a ∈ (gateAt C j).inputs, a < n+j → P a) :
    ∀ w, P w → ∃ S : Finset ℕ,
      (∀ a ∈ S, (a < n ∨ a = n+i) ∧ P a) ∧
      ∀ x : Fin n → Bool, W n C x w = true ↔ ∃ a ∈ S, W n C x a = true := by
  classical
  intro w
  induction w using Nat.strong_induction_on with
  | ind w ih =>
    intro hp
    by_cases hn : w < n
    · exact ⟨{w},by simp [hn,hp],by simp⟩
    by_cases hbig : n+C.gates.length ≤ w
    · refine ⟨∅,by simp,?_⟩
      intro x
      have hf : W n C x w = false := by
        unfold W
        exact getD_ge_length _ _ (by rw [wires_length]; exact hbig)
      simp [hf]
    have hk : w-n < C.gates.length := by omega
    have hw : w = n+(w-n) := by omega
    have hp' : P (n+(w-n)) := by simpa [←hw] using hp
    rcases (gate_mono2 C hm (w-n) hk).1 with ha | ho
    · have he := ands (w-n) hk hp' ha
      have hwi : w = n+i := by omega
      exact ⟨{w},by simpa only [Finset.mem_singleton,forall_eq] using And.intro (Or.inr hwi) hp,by simp⟩
    · have hform : ∀ a : ℕ, a ∈ (gateAt C (w-n)).inputs → a < n+(w-n) →
          ∃ S : Finset ℕ, (∀ b ∈ S, (b < n ∨ b = n+i) ∧ P b) ∧
            ∀ x : Fin n → Bool, W n C x a = true ↔ ∃ b ∈ S, W n C x b = true := by
        intro a ha hlt
        exact ih a (by omega) (closed (w-n) hk hp' a ha hlt)
      let F : ℕ → Finset ℕ := fun a =>
        if h : a ∈ (gateAt C (w-n)).inputs ∧ a < n+(w-n)
        then Classical.choose (hform a h.1 h.2) else ∅
      have hF (a : ℕ) (ha : a ∈ (gateAt C (w-n)).inputs) (hlt : a < n+(w-n)) :
          (∀ b ∈ F a, (b < n ∨ b = n+i) ∧ P b) ∧
          ∀ x : Fin n → Bool, W n C x a = true ↔ ∃ b ∈ F a, W n C x b = true := by
        simp only [F, dite_eq_left (show a ∈ (gateAt C (w-n)).inputs ∧ a < n+(w-n) from ⟨ha,hlt⟩)]
        exact Classical.choose_spec (hform a ha hlt)
      let S := ((gateAt C (w-n)).inputs.toFinset.filter fun a => a < n+(w-n)).biUnion F
      refine ⟨S,?_,?_⟩
      · intro b hb
        obtain ⟨a,ha,hb⟩ := Finset.mem_biUnion.mp hb
        obtain ⟨ha,hlt⟩ := Finset.mem_filter.mp ha
        exact (hF a (List.mem_toFinset.mp ha) hlt).1 b hb
      · intro x
        rw [hw,W_or_iff n C x (w-n) hk ho]
        constructor
        · rintro ⟨a,ha,hlt,hax⟩
          obtain ⟨b,hb,hbx⟩ := (hF a ha hlt).2 x |>.mp hax
          exact ⟨b,Finset.mem_biUnion.mpr ⟨a,by simp [ha,hlt],hb⟩,hbx⟩
        · rintro ⟨b,hb,hbx⟩
          obtain ⟨a,ha,hb⟩ := Finset.mem_biUnion.mp hb
          obtain ⟨ha,hlt⟩ := Finset.mem_filter.mp ha
          have ham := List.mem_toFinset.mp ha
          exact ⟨a,ham,hlt,(hF a ham hlt).2 x |>.mpr ⟨b,hb,hbx⟩⟩

open PEqualNP.EdgeOwnership in
lemma strict_cone_atomic (n : ℕ) (C : Circuit) (hm : Monotone2 C)
    (hz : PEqualNP.TopForm.andPairs n C = 1)
    (i j : ℕ) (hi : i < C.gates.length) (hj : j < C.gates.length)
    (hai : (gateAt C i).op = GateOp.and) (haj : (gateAt C j).op = GateOp.and)
    (hij : InCone n C i j) :
    ∀ w ∈ (gateAt C j).inputs, w < n+j →
      ∃ S : Finset ℕ, (∀ a ∈ S, a < n ∨ a = n+i) ∧
        ∀ x : Fin n → Bool, W n C x w = true ↔ ∃ a ∈ S, W n C x a = true := by
  let P := fun w => w < n ∨ ∃ k, w = n+k ∧ InCone n C k j
  have hclosed : ∀ k, k < C.gates.length → P (n+k) →
      ∀ a ∈ (gateAt C k).inputs, a < n+k → P a := by
    intro k hk hp a ha hlt
    have hkj : InCone n C k j := by
      rcases hp with hp | ⟨b,hb,hbj⟩
      · omega
      · have he : b = k := by omega
        simpa [he] using hbj
    by_cases han : a < n
    · exact Or.inl han
    · refine Or.inr ⟨a-n,by omega,?_⟩
      have hak : InCone n C (a-n) k :=
        (inCone_iff n C (a-n) k hk).mpr ⟨a,ha,by omega,hlt,Or.inl rfl⟩
      exact inCone_trans n C j hj (a-n) k hak hkj
  have hand : ∀ k, k < C.gates.length → P (n+k) →
      (gateAt C k).op = GateOp.and → k = i := by
    intro k hk hp hka
    have hkj : InCone n C k j := by
      rcases hp with hp | ⟨b,hb,hbj⟩
      · omega
      · have he : b = k := by omega
        simpa [he] using hbj
    exact (one_nested_unique n C hz k j i j hk hj hi hj hka haj hai haj hkj hij).1
  intro w hw hlt
  obtain ⟨S,hS,hv⟩ := or_atomic_form n C hm P i hand hclosed w (by
    by_cases hwn : w < n
    · exact Or.inl hwn
    · exact Or.inr ⟨w-n,by omega,
        (inCone_iff n C (w-n) j hj).mpr ⟨w,hw,by omega,hlt,Or.inl rfl⟩⟩)
  exact ⟨S,fun a ha => (hS a ha).1,hv⟩

open PEqualNP.EdgeOwnership in
lemma inner_cone_no_and (n : ℕ) (C : Circuit)
    (hz : PEqualNP.TopForm.andPairs n C = 1)
    (i j : ℕ) (hi : i < C.gates.length) (hj : j < C.gates.length)
    (hai : (gateAt C i).op = GateOp.and) (haj : (gateAt C j).op = GateOp.and)
    (hij : InCone n C i j) (k : ℕ) (hk : k < C.gates.length)
    (hki : InCone n C k i) : (gateAt C k).op ≠ GateOp.and := by
  intro hka
  have he := one_nested_unique n C hz k i i j hk hi hi hj hka hai hai haj hki hij
  have hlt := inCone_lt n C j hj i hij
  omega

lemma no_and_atomic_is_raw (n : ℕ) (C : Circuit) (hm : Monotone2 C)
    (P : ℕ → Prop)
    (ands : ∀ j, j < C.gates.length → P (n+j) → (gateAt C j).op ≠ GateOp.and)
    (closed : ∀ j, j < C.gates.length → P (n+j) →
      ∀ a ∈ (gateAt C j).inputs, a < n+j → P a)
    (w : ℕ) (hp : P w) :
    ∃ S : Finset (Fin n), ∀ x : Fin n → Bool,
      W n C x w = true ↔ ∃ a ∈ S, x a = true := by
  classical
  obtain ⟨S,hS,hv⟩ := or_atomic_form n C hm P C.gates.length
    (fun j hj hp ha => False.elim (ands j hj hp ha)) closed w hp
  let T := (Finset.univ : Finset (Fin n)).filter fun a => a.val ∈ S
  refine ⟨T,?_⟩
  intro x
  rw [hv]
  constructor
  · rintro ⟨a,ha,hax⟩
    rcases (hS a ha).1 with han | har
    · refine ⟨⟨a,han⟩,by simp [T,ha],?_⟩
      simpa [W_input n C x a han] using hax
    · have hf : W n C x a = false := by
        unfold W
        exact getD_ge_length _ _ (by rw [wires_length]; omega)
      rw [hf] at hax
      cases hax
  · rintro ⟨a,ha,hax⟩
    have has : a.val ∈ S := (Finset.mem_filter.mp ha).2
    exact ⟨a.val,has,by simpa [W_input n C x a.val a.isLt] using hax⟩

open PEqualNP.EdgeOwnership in
lemma inner_inputs_raw (n : ℕ) (C : Circuit) (hm : Monotone2 C)
    (hz : PEqualNP.TopForm.andPairs n C = 1)
    (i j : ℕ) (hi : i < C.gates.length) (hj : j < C.gates.length)
    (hai : (gateAt C i).op = GateOp.and) (haj : (gateAt C j).op = GateOp.and)
    (hij : InCone n C i j) :
    ∀ w ∈ (gateAt C i).inputs, w < n+i →
      ∃ S : Finset (Fin n), ∀ x : Fin n → Bool,
        W n C x w = true ↔ ∃ a ∈ S, x a = true := by
  let P := fun w => w < n ∨ ∃ k, w = n+k ∧ InCone n C k i
  have hclosed : ∀ k, k < C.gates.length → P (n+k) →
      ∀ a ∈ (gateAt C k).inputs, a < n+k → P a := by
    intro k hk hp a ha hlt
    have hki : InCone n C k i := by
      rcases hp with hp | ⟨b,hb,hbi⟩
      · omega
      · have he : b = k := by omega
        simpa [he] using hbi
    by_cases han : a < n
    · exact Or.inl han
    · refine Or.inr ⟨a-n,by omega,?_⟩
      have hak : InCone n C (a-n) k :=
        (inCone_iff n C (a-n) k hk).mpr ⟨a,ha,by omega,hlt,Or.inl rfl⟩
      exact inCone_trans n C i hi (a-n) k hak hki
  have hand : ∀ k, k < C.gates.length → P (n+k) →
      (gateAt C k).op ≠ GateOp.and := by
    intro k hk hp
    apply inner_cone_no_and n C hz i j hi hj hai haj hij k hk
    rcases hp with hp | ⟨b,hb,hbi⟩
    · omega
    · have he : b = k := by omega
      simpa [he] using hbi
  intro w hw hlt
  apply no_and_atomic_is_raw n C hm P hand hclosed w
  by_cases hwn : w < n
  · exact Or.inl hwn
  · exact Or.inr ⟨w-n,by omega,
      (inCone_iff n C (w-n) i hi).mpr ⟨w,hw,by omega,hlt,Or.inl rfl⟩⟩

def rawOr (n : ℕ) (C : Circuit) (S : Finset ℕ) (x : Fin n → Bool) : Prop :=
  ∃ a ∈ S, ∃ h : a < n, x ⟨a,h⟩ = true

lemma atomic_split (n : ℕ) (C : Circuit) (i : ℕ) (S : Finset ℕ)
    (hs : ∀ a ∈ S, a < n ∨ a = n+i) (x : Fin n → Bool) :
    (∃ a ∈ S, W n C x a = true) ↔
      rawOr n C S x ∨ (n+i ∈ S ∧ W n C x (n+i) = true) := by
  constructor
  · rintro ⟨a,ha,hax⟩
    rcases hs a ha with han | har
    · exact Or.inl ⟨a,ha,han,by simpa [W_input n C x a han] using hax⟩
    · exact Or.inr ⟨har ▸ ha,har ▸ hax⟩
  · rintro (⟨a,ha,han,hax⟩ | ⟨ha,hax⟩)
    · exact ⟨a,ha,by simpa [W_input n C x a han] using hax⟩
    · exact ⟨n+i,ha,hax⟩

lemma rawOr_pair (n : ℕ) (C : Circuit) (S : Finset ℕ) (u v : Fin n) :
    rawOr n C S (PEqualNP.EdgeOwnership.pairInput u v) ↔ u.val ∈ S ∨ v.val ∈ S := by
  constructor
  · rintro ⟨a,ha,han,hax⟩
    have he : (⟨a,han⟩ : Fin n) = u ∨ (⟨a,han⟩ : Fin n) = v := of_decide_eq_true hax
    rcases he with he | he
    · exact Or.inl (congrArg Fin.val he ▸ ha)
    · exact Or.inr (congrArg Fin.val he ▸ ha)
  · rintro (hu | hv)
    · exact ⟨u.val,hu,u.isLt,by simp [PEqualNP.EdgeOwnership.pairInput]⟩
    · exact ⟨v.val,hv,v.isLt,by simp [PEqualNP.EdgeOwnership.pairInput]⟩

def hitSet {n : ℕ} (S : Finset (Fin n)) (x : Fin n → Bool) : Prop := ∃ v ∈ S, x v = true

def runClauses {n : ℕ} (cs : List (Finset (Fin n))) (x : Fin n → Bool) : Prop :=
  ∀ S ∈ cs, hitSet S x

open PEqualNP.EdgeOwnership in
lemma inner_CNF (n : ℕ) (C : Circuit) (hm : Monotone2 C)
    (hz : PEqualNP.TopForm.andPairs n C = 1)
    (i j : ℕ) (hi : i < C.gates.length) (hj : j < C.gates.length)
    (hai : (gateAt C i).op = GateOp.and) (haj : (gateAt C j).op = GateOp.and)
    (hij : InCone n C i j) (x0 : Fin n → Bool) (hx : gateVal n C i x0 = true) :
    ∃ cs : List (Finset (Fin n)), cs.length ≤ 2 ∧
      ∀ x : Fin n → Bool, gateVal n C i x = true ↔ runClauses cs x := by
  classical
  have hb (w : ℕ) (hw : w ∈ (gateAt C i).inputs) : w < n+i :=
    ((W_and_iff n C x0 i hi hai).mp hx w hw).1
  have hex (w : ℕ) (hw : w ∈ (gateAt C i).inputs) :=
    inner_inputs_raw n C hm hz i j hi hj hai haj hij w hw (hb w hw)
  let F : ℕ → Finset (Fin n) := fun w =>
    if h : w ∈ (gateAt C i).inputs then Classical.choose (hex w h) else ∅
  have hF (w : ℕ) (hw : w ∈ (gateAt C i).inputs) (x : Fin n → Bool) :
      W n C x w = true ↔ hitSet (F w) x := by
    simp only [F,dite_eq_left hw,hitSet]
    exact Classical.choose_spec (hex w hw) x
  refine ⟨(gateAt C i).inputs.map F,?_,?_⟩
  · simpa using (gate_mono2 C hm i hi).2
  · intro x
    change W n C x (n+i) = true ↔ _
    rw [W_and_iff n C x i hi hai]
    constructor
    · intro h S hS
      obtain ⟨w,hw,rfl⟩ := List.mem_map.mp hS
      exact (hF w hw x).mp (h w hw).2
    · intro h w hw
      exact ⟨hb w hw,(hF w hw x).mpr (h (F w) (List.mem_map.mpr ⟨w,hw,rfl⟩))⟩

lemma hitSet_union {n : ℕ} (A B : Finset (Fin n)) (x : Fin n → Bool) :
    hitSet (A ∪ B) x ↔ hitSet A x ∨ hitSet B x := by
  simp only [hitSet,Finset.mem_union]
  constructor
  · rintro ⟨v,hv,hx⟩
    rcases hv with hv | hv
    · exact Or.inl ⟨v,hv,hx⟩
    · exact Or.inr ⟨v,hv,hx⟩
  · rintro (⟨v,hv,hx⟩ | ⟨v,hv,hx⟩)
    · exact ⟨v,Or.inl hv,hx⟩
    · exact ⟨v,Or.inr hv,hx⟩

lemma operand_CNF (n : ℕ) (C : Circuit) (i : ℕ) (S : Finset ℕ)
    (hs : ∀ a ∈ S, a < n ∨ a = n+i)
    (cs : List (Finset (Fin n))) (hcs : cs.length ≤ 2)
    (hi : ∀ x : Fin n → Bool, W n C x (n+i) = true ↔ runClauses cs x) :
    ∃ ds : List (Finset (Fin n)), ds.length ≤ 2 ∧
      ∀ x : Fin n → Bool, (∃ a ∈ S, W n C x a = true) ↔ runClauses ds x := by
  classical
  let A := (Finset.univ : Finset (Fin n)).filter fun a => a.val ∈ S
  have hr (x : Fin n → Bool) : rawOr n C S x ↔ hitSet A x := by
    constructor
    · rintro ⟨a,ha,han,hax⟩
      exact ⟨⟨a,han⟩,by simp [A,ha],hax⟩
    · rintro ⟨a,ha,hax⟩
      exact ⟨a.val,(Finset.mem_filter.mp ha).2,a.isLt,hax⟩
  by_cases hat : n+i ∈ S
  · refine ⟨cs.map fun B => A ∪ B,by simpa using hcs,?_⟩
    intro x
    rw [atomic_split n C i S hs x,hr,hi]
    simp only [hat,true_and]
    constructor
    · rintro (hA | hcs)
      · intro B hB
        obtain ⟨B,hmem,rfl⟩ := List.mem_map.mp hB
        exact (hitSet_union A B x).mpr (Or.inl hA)
      · intro B hB
        obtain ⟨B,hmem,rfl⟩ := List.mem_map.mp hB
        exact (hitSet_union A B x).mpr (Or.inr (hcs B hmem))
    · intro h
      by_cases hA : hitSet A x
      · exact Or.inl hA
      · right
        intro B hB
        exact ((hitSet_union A B x).mp (h (A ∪ B) (List.mem_map.mpr ⟨B,hB,rfl⟩))).resolve_left hA
  · refine ⟨[A],by simp,?_⟩
    intro x
    rw [atomic_split n C i S hs x,hr]
    simp [hat,runClauses]

open PEqualNP.EdgeOwnership in
lemma outer_CNF (n : ℕ) (C : Circuit) (hm : Monotone2 C)
    (hz : PEqualNP.TopForm.andPairs n C = 1)
    (i j : ℕ) (hi : i < C.gates.length) (hj : j < C.gates.length)
    (hai : (gateAt C i).op = GateOp.and) (haj : (gateAt C j).op = GateOp.and)
    (hij : InCone n C i j) (x0 : Fin n → Bool)
    (hxi : gateVal n C i x0 = true) (hxj : gateVal n C j x0 = true) :
    ∃ cs : List (Finset (Fin n)), cs.length ≤ 4 ∧
      ∀ x : Fin n → Bool, gateVal n C j x = true ↔ runClauses cs x := by
  classical
  obtain ⟨ics,hilen,hiv⟩ := inner_CNF n C hm hz i j hi hj hai haj hij x0 hxi
  have hb (w : ℕ) (hw : w ∈ (gateAt C j).inputs) : w < n+j :=
    ((W_and_iff n C x0 j hj haj).mp hxj w hw).1
  have hex (w : ℕ) (hw : w ∈ (gateAt C j).inputs) :
      ∃ ds : List (Finset (Fin n)), ds.length ≤ 2 ∧
        ∀ x : Fin n → Bool, W n C x w = true ↔ runClauses ds x := by
    obtain ⟨S,hS,hv⟩ := strict_cone_atomic n C hm hz i j hi hj hai haj hij w hw (hb w hw)
    obtain ⟨ds,hlen,hds⟩ := operand_CNF n C i S hS ics hilen hiv
    exact ⟨ds,hlen,fun x => (hv x).trans (hds x)⟩
  let F : ℕ → List (Finset (Fin n)) := fun w =>
    if h : w ∈ (gateAt C j).inputs then Classical.choose (hex w h) else []
  have hF (w : ℕ) (hw : w ∈ (gateAt C j).inputs) :
      (F w).length ≤ 2 ∧ ∀ x : Fin n → Bool, W n C x w = true ↔ runClauses (F w) x := by
    simp only [F,dite_eq_left hw]
    exact Classical.choose_spec (hex w hw)
  refine ⟨(gateAt C j).inputs.flatMap F,?_,?_⟩
  · have hlist : ∀ ls : List ℕ, (∀ w ∈ ls, (F w).length ≤ 2) →
        (ls.flatMap F).length ≤ 2*ls.length := by
      intro ls
      induction ls with
      | nil => simp
      | cons a ls ih =>
        intro h
        have h1 := h a (by simp)
        have h2 := ih (fun w hw => h w (by simp [hw]))
        simp only [List.flatMap_cons,List.length_append,List.length_cons]
        omega
    have h1 := hlist (gateAt C j).inputs (fun w hw => (hF w hw).1)
    have h2 := (gate_mono2 C hm j hj).2
    omega
  · intro x
    change W n C x (n+j) = true ↔ _
    rw [W_and_iff n C x j hj haj]
    constructor
    · intro h S hS
      obtain ⟨w,hw,hS⟩ := List.mem_flatMap.mp hS
      exact ((hF w hw).2 x).mp (h w hw).2 S hS
    · intro h w hw
      refine ⟨hb w hw,?_⟩
      apply ((hF w hw).2 x).mpr
      intro S hS
      exact h S (List.mem_flatMap.mpr ⟨w,hw,hS⟩)

def usedWires (C : Circuit) : Finset ℕ := (C.gates.flatMap fun g => g.inputs).toFinset

lemma usedWires_card (C : Circuit) (hm : Monotone2 C) : (usedWires C).card ≤ 2*C.size := by
  have hlist : ∀ gs : List Gate, (∀ g ∈ gs, g.inputs.length ≤ 2) →
      (gs.flatMap fun g => g.inputs).length ≤ 2*gs.length := by
    intro gs
    induction gs with
    | nil => simp
    | cons g gs ih =>
      intro h
      have h1 := h g (by simp)
      have h2 := ih (fun a ha => h a (by simp [ha]))
      simp only [List.flatMap_cons,List.length_append,List.length_cons]
      omega
  have h1 := hlist C.gates (fun g hg => (hm g hg).2)
  have h2 := List.toFinset_card_le (C.gates.flatMap fun g => g.inputs)
  change (C.gates.flatMap fun g => g.inputs).toFinset.card ≤ 2*C.gates.length
  omega

lemma gate_agree_used (n : ℕ) (C : Circuit) (x y : Fin n → Bool)
    (hxy : ∀ a : Fin n, a.val ∈ usedWires C → x a = y a) :
    ∀ k, k < C.gates.length → W n C x (n+k) = W n C y (n+k) := by
  intro k
  induction k using Nat.strong_induction_on with
  | ind k ih =>
    intro hk
    rw [W_gate n C x k hk,W_gate n C y k hk]
    congr 1
    apply List.map_congr_left
    intro w hw
    by_cases hlt : w < n+k
    · simp only [hlt,ite_true]
      by_cases hwn : w < n
      · rw [W_input n C x w hwn,W_input n C y w hwn]
        apply hxy
        simp only [usedWires,List.mem_toFinset,List.mem_flatMap]
        exact ⟨gateAt C k,by rw [gateAt_eq C k hk]; exact List.getElem_mem hk,hw⟩
      · have he : w = n+(w-n) := by omega
        rw [he]
        exact ih (w-n) (by omega) (by omega)
    · simp [hlt]

open PEqualNP.EdgeOwnership in
lemma clean_gate_pair_used (n : ℕ) (G : SimpleGraph (Fin n)) (C : Circuit)
    (j : ℕ) (hj : j < C.gates.length)
    (clean : ∀ p q : Fin n, gateVal n C j (pairInput p q) = true → G.Adj p q)
    (u v : Fin n) (hv : gateVal n C j (pairInput u v) = true) :
    u.val ∈ usedWires C ∧ v.val ∈ usedWires C := by
  classical
  have leftUsed (a b : Fin n) (hab : gateVal n C j (pairInput a b) = true) :
      a.val ∈ usedWires C := by
    by_contra hnot
    have heq : ∀ t : Fin n, t.val ∈ usedWires C → pairInput a b t = pairInput b b t := by
      intro t ht
      have hta : t ≠ a := fun h => hnot (h ▸ ht)
      simp [pairInput,hta]
    have he := gate_agree_used n C (pairInput a b) (pairInput b b) heq j hj
    have hb : gateVal n C j (pairInput b b) = true := by
      change W n C (pairInput b b) (n+j) = true
      rw [←he]
      exact hab
    exact G.loopless.irrefl _ (clean b b hb)
  refine ⟨leftUsed u v hv,?_⟩
  apply leftUsed v u
  have he : pairInput v u = pairInput u v := by
    funext t
    simp only [pairInput,or_comm]
  simpa only [he] using hv

open PEqualNP.EdgeOwnership in
lemma outer_pair_count (n : ℕ) (G : SimpleGraph (Fin n)) (C : Circuit) (hm : Monotone2 C)
    (hz : PEqualNP.TopForm.andPairs n C = 1)
    (i j : ℕ) (hi : i < C.gates.length) (hj : j < C.gates.length)
    (hai : (gateAt C i).op = GateOp.and) (haj : (gateAt C j).op = GateOp.and)
    (hij : InCone n C i j) (x0 : Fin n → Bool)
    (hxi : gateVal n C i x0 = true) (hxj : gateVal n C j x0 = true)
    (clean : ∀ p q : Fin n, gateVal n C j (pairInput p q) = true → G.Adj p q)
    (h4 : ∀ a c b d : Fin n, a ≠ c → b ≠ d → ¬(G.Adj a b ∧ G.Adj a d ∧ G.Adj c b ∧ G.Adj c d)) :
    ((Finset.univ : Finset (Fin n × Fin n)).filter fun p =>
      gateVal n C j (pairInput p.1 p.2) = true).card ≤ 32*C.size := by
  classical
  obtain ⟨cs,hlen,hcs⟩ := outer_CNF n C hm hz i j hi hj hai haj hij x0 hxi hxj
  let clause : Fin cs.length → Finset (Fin n) := fun k => cs[k]
  have heval (u v : Fin n) : CNF1710.accepts clause u v ↔ gateVal n C j (pairInput u v) = true := by
    rw [hcs]
    constructor
    · intro h S hS
      obtain ⟨k,hk,he⟩ := List.getElem_of_mem hS
      have hh := h ⟨k,hk⟩
      change u ∈ cs[k] ∨ v ∈ cs[k] at hh
      rw [he] at hh
      rcases hh with hu | hv
      · exact ⟨u,hu,by simp [pairInput]⟩
      · exact ⟨v,hv,by simp [pairInput]⟩
    · intro h k
      obtain ⟨a,ha,hax⟩ := h cs[k] (List.getElem_mem k.isLt)
      have he : a = u ∨ a = v := of_decide_eq_true hax
      rcases he with rfl | rfl
      · exact Or.inl ha
      · exact Or.inr ha
  let U := (Finset.univ : Finset (Fin n)).filter fun v => v.val ∈ usedWires C
  let E := ((Finset.univ : Finset (Fin n × Fin n)).filter fun p => gateVal n C j (pairInput p.1 p.2) = true)
  have hu : U.card ≤ 2*C.size := by
    have hle : U.card ≤ (usedWires C).card := by
      apply Finset.card_le_card_of_injOn (fun v : Fin n => v.val)
      · intro v hv
        exact (Finset.mem_filter.mp hv).2
      · intro a ha b hb hab
        exact Fin.ext hab
    exact le_trans hle (usedWires_card C hm)
  have hb := CNF1710.count_on_support clause G.Adj h4
    (fun u v h => clean u v ((heval u v).mp h)) U E
    (fun p hp => by
      have h := clean_gate_pair_used n G C j hj clean p.1 p.2 (Finset.mem_filter.mp hp).2
      exact ⟨by simp [U,h.1],by simp [U,h.2]⟩)
    (fun p hp => (heval p.1 p.2).mpr (Finset.mem_filter.mp hp).2)
  have hp : 2 ^ Fintype.card (Fin cs.length) ≤ 16 := by
    simp only [Fintype.card_fin]
    exact le_trans (Nat.pow_le_pow_right (by decide : 0 < 2) hlen) (by decide)
  calc
    E.card ≤ 2 ^ Fintype.card (Fin cs.length) * U.card := hb
    _ ≤ 16 * (2*C.size) := Nat.mul_le_mul hp hu
    _ = 32*C.size := by omega

open PEqualNP.EdgeOwnership in
lemma unclean_count_one (n : ℕ) (G : SimpleGraph (Fin n)) [DecidableRel G.Adj]
    (C : Circuit) (hm : Monotone2 C) (hF : circuitFun n C = graphFun G ∅)
    (hz : PEqualNP.TopForm.andPairs n C = 1)
    (h4 : ∀ a c b d : Fin n, a ≠ c → b ≠ d → ¬(G.Adj a b ∧ G.Adj a d ∧ G.Adj c b ∧ G.Adj c d)) :
    {e ∈ G.edgeFinset | ¬∃ u v, e = s(u,v) ∧ ∃ j : Fin C.gates.length,
      Owns n C j u v ∧ ∀ p q, gateVal n C j (pairInput p q) = true → G.Adj p q}.card ≤ 32*C.size := by
  classical
  let B := {e ∈ G.edgeFinset | ¬∃ u v, e = s(u,v) ∧ ∃ j : Fin C.gates.length,
      Owns n C j u v ∧ ∀ p q, gateVal n C j (pairInput p q) = true → G.Adj p q}
  change B.card ≤ _
  by_cases he : B.Nonempty
  · obtain ⟨e,he⟩ := he
    obtain ⟨he,hno⟩ := Finset.mem_filter.mp he
    induction e using Sym2.inductionOn with
    | _ u v =>
      have huv : G.Adj u v := by simpa using he
      have hn : ¬∃ j : Fin C.gates.length, Owns n C j u v ∧
          ∀ p q, gateVal n C j (pairInput p q) = true → G.Adj p q := by
        intro h
        exact hno ⟨u,v,rfl,h⟩
      obtain ⟨i,j,hijlt,hij,hai,haj,hiv,hjv,hclean⟩ := unclean_edge_active_nested n G C hm hF u v huv hn
      let E := ((Finset.univ : Finset (Fin n × Fin n)).filter fun p => gateVal n C j (pairInput p.1 p.2) = true)
      have hsub : B ⊆ E.image (fun p => s(p.1,p.2)) := by
        intro e he
        obtain ⟨he,hno⟩ := Finset.mem_filter.mp he
        induction e using Sym2.inductionOn with
        | _ a b =>
          have hab : G.Adj a b := by simpa using he
          have hn : ¬∃ k : Fin C.gates.length, Owns n C k a b ∧
              ∀ p q, gateVal n C k (pairInput p q) = true → G.Adj p q := by
            intro h
            exact hno ⟨a,b,rfl,h⟩
          obtain ⟨k,l,hkl,hc,hka,hla,hkv,hlv,hlclean⟩ := unclean_edge_active_nested n G C hm hF a b hab hn
          have hid := one_nested_unique n C hz k l i j k.isLt l.isLt i.isLt j.isLt hka hla hai haj hc hij
          have hv : gateVal n C j (pairInput a b) = true := by simpa only [hid.2] using hlv
          exact Finset.mem_image.mpr ⟨(a,b),by simp [E,hv],rfl⟩
      calc
        B.card ≤ (E.image (fun p => s(p.1,p.2))).card := Finset.card_le_card hsub
        _ ≤ E.card := Finset.card_image_le
        _ ≤ 32*C.size := outer_pair_count n G C hm hz i j i.isLt j.isLt hai haj hij (pairInput u v) hiv hjv hclean h4
  · have hb : B = ∅ := Finset.not_nonempty_iff_eq_empty.mp he
    simp [hb]

open PEqualNP.EdgeOwnership in
lemma unclean_count_one_girth (n : ℕ) (G : SimpleGraph (Fin n)) [DecidableRel G.Adj]
    (hg : ∀ (v : Fin n) (p : G.Walk v v), p.IsCycle → 5 ≤ p.length)
    (C : Circuit) (hm : Monotone2 C) (hF : circuitFun n C = graphFun G ∅)
    (hz : PEqualNP.TopForm.andPairs n C = 1) :
    {e ∈ G.edgeFinset | ¬∃ u v, e = s(u,v) ∧ ∃ j : Fin C.gates.length,
      Owns n C j u v ∧ ∀ p q, gateVal n C j (pairInput p q) = true → G.Adj p q}.card ≤ 32*(C.size+1) := by
  have h4 : ∀ a c b d : Fin n, a ≠ c → b ≠ d →
      ¬(G.Adj a b ∧ G.Adj a d ∧ G.Adj c b ∧ G.Adj c d) := by
    intro a c b d hac hbd ⟨hab,had,hcb,hcd⟩
    let W : G.Walk a a := .cons hab (.cons hcb.symm (.cons hcd (.cons had.symm .nil)))
    have hW : W.IsCycle := by
      refine SimpleGraph.Walk.isCycle_iff_isPath_tail_and_le_length.mpr ⟨?_,by simp [W]⟩
      simp only [W,SimpleGraph.Walk.tail_cons]
      simp [hab.ne.symm,hcb.ne.symm,hcd.ne,had.ne.symm,hac.symm,hbd]
    have h5 := hg a W hW
    have hlen : W.length = 4 := rfl
    omega
  have h := unclean_count_one n G C hm hF hz h4
  omega

end Zero1764
#print axioms Zero1764.unclean_count_one_girth
