import Mathlib.Data.Fintype.Prod
import Mathlib.Data.Fintype.Sets
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Lean.Elab.Tactic.Omega
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Fintype.Powerset
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Fintype.Card
import Mathlib.Tactic.Tauto

namespace CNF1710
variable {V K : Type*} [DecidableEq V] [DecidableEq K] [Fintype K]

def accepts (clause : K → Finset V) (u v : V) : Prop :=
  ∀ k, u ∈ clause k ∨ v ∈ clause k

def leftSet [Fintype V] (clause : K → Finset V) (T : Finset K) : Finset V :=
  Finset.univ.filter fun v => ∀ k ∈ T, v ∈ clause k

def rightSet [Fintype V] (clause : K → Finset V) (T : Finset K) : Finset V :=
  Finset.univ.filter fun v => ∀ k, k ∉ T → v ∈ clause k

lemma decomposition [Fintype V] (clause : K → Finset V) (u v : V) :
    accepts clause u v ↔ ∃ T : Finset K, u ∈ leftSet clause T ∧ v ∈ rightSet clause T := by
  classical
  constructor
  · intro h
    let T := Finset.univ.filter fun k => u ∈ clause k
    refine ⟨T,?_,?_⟩
    · simp only [leftSet,Finset.mem_filter,Finset.mem_univ,true_and]
      intro k hk
      exact (Finset.mem_filter.mp hk).2
    · simp only [rightSet,Finset.mem_filter,Finset.mem_univ,true_and]
      intro k hk
      have hku : u ∉ clause k := by simpa [T] using hk
      exact (h k).resolve_left hku
  · rintro ⟨T,hu,hv⟩ k
    have hu' := (Finset.mem_filter.mp hu).2
    have hv' := (Finset.mem_filter.mp hv).2
    by_cases hk : k ∈ T
    · exact Or.inl (hu' k hk)
    · exact Or.inr (hv' k hk)

lemma rectangle_sound [Fintype V] (clause : K → Finset V) (I : V → V → Prop)
    (sound : ∀ u v, accepts clause u v → I u v) (T : Finset K) :
    ∀ u ∈ leftSet clause T, ∀ v ∈ rightSet clause T, I u v := by
  intro u hu v hv
  exact sound u v ((decomposition clause u v).mpr ⟨T,hu,hv⟩)

lemma expanded_two_clause (a b c : Prop) : (a ∧ b) ∨ c ↔ (a ∨ c) ∧ (b ∨ c) := by tauto

lemma expanded_outer_four (a b c d : Prop) :
    ((a ∧ b) ∨ c) ∧ ((a ∧ b) ∨ d) ↔
      (a ∨ c) ∧ (b ∨ c) ∧ (a ∨ d) ∧ (b ∨ d) := by tauto

lemma rectangle_thin [Fintype V] (I : V → V → Prop)
    (noFour : ∀ a c b d, a ≠ c → b ≠ d → ¬(I a b ∧ I a d ∧ I c b ∧ I c d))
    (A B : Finset V) (sound : ∀ a ∈ A, ∀ b ∈ B, I a b) :
    (A ×ˢ B).card ≤ Fintype.card V := by
  rw [Finset.card_product]
  by_cases ha : A.card ≤ 1
  · calc
      A.card * B.card ≤ 1 * B.card := Nat.mul_le_mul_right _ ha
      _ = B.card := Nat.one_mul _
      _ ≤ Fintype.card V := Finset.card_le_univ _
  · have hb : B.card ≤ 1 := by
      apply Finset.card_le_one.mpr
      intro b hb d hd
      by_contra hbd
      obtain ⟨a,ha,c,hc,hac⟩ := Finset.one_lt_card.mp (by omega : 1 < A.card)
      exact noFour a c b d hac hbd ⟨sound a ha b hb,sound a ha d hd,sound c hc b hb,sound c hc d hd⟩
    calc
      A.card * B.card ≤ A.card * 1 := Nat.mul_le_mul_left _ hb
      _ = A.card := Nat.mul_one _
      _ ≤ Fintype.card V := Finset.card_le_univ _

lemma count [Fintype V] (clause : K → Finset V) (I : V → V → Prop)
    (noFour : ∀ a c b d, a ≠ c → b ≠ d → ¬(I a b ∧ I a d ∧ I c b ∧ I c d))
    (sound : ∀ u v, accepts clause u v → I u v)
    (E : Finset (V × V)) (cover : ∀ p ∈ E, accepts clause p.1 p.2) :
    E.card ≤ 2 ^ Fintype.card K * Fintype.card V := by
  classical
  let R := fun T : Finset K => leftSet clause T ×ˢ rightSet clause T
  have hsub : E ⊆ Finset.univ.biUnion R := by
    intro p hp
    obtain ⟨T,hu,hv⟩ := (decomposition clause p.1 p.2).mp (cover p hp)
    exact Finset.mem_biUnion.mpr ⟨T,Finset.mem_univ _,Finset.mem_product.mpr ⟨hu,hv⟩⟩
  have hR : ∀ T, (R T).card ≤ Fintype.card V := fun T =>
    rectangle_thin I noFour _ _ (rectangle_sound clause I sound T)
  calc
    E.card ≤ (Finset.univ.biUnion R).card := Finset.card_le_card hsub
    _ ≤ ∑ T : Finset K, (R T).card := Finset.card_biUnion_le
    _ ≤ ∑ T : Finset K, Fintype.card V := Finset.sum_le_sum (fun T _ => hR T)
    _ = 2 ^ Fintype.card K * Fintype.card V := by simp

lemma count_on_support [Fintype V] (clause : K → Finset V) (I : V → V → Prop)
    (noFour : ∀ a c b d, a ≠ c → b ≠ d → ¬(I a b ∧ I a d ∧ I c b ∧ I c d))
    (sound : ∀ u v, accepts clause u v → I u v)
    (U : Finset V) (E : Finset (V × V))
    (inU : ∀ p ∈ E, p.1 ∈ U ∧ p.2 ∈ U)
    (cover : ∀ p ∈ E, accepts clause p.1 p.2) :
    E.card ≤ 2 ^ Fintype.card K * U.card := by
  classical
  let lift : U → V := fun v => v.val
  let clause' : K → Finset U := fun k => Finset.univ.filter fun v => v.val ∈ clause k
  let E' : Finset (U × U) := Finset.univ.filter fun p => (p.1.val,p.2.val) ∈ E
  have inj : Function.Injective (fun p : U × U => (p.1.val,p.2.val)) := by
    intro a b h
    exact Prod.ext (Subtype.ext (Prod.mk.inj h).1) (Subtype.ext (Prod.mk.inj h).2)
  have im : E'.image (fun p => (p.1.val,p.2.val)) = E := by
    ext p
    constructor
    · rintro hp
      obtain ⟨q,hq,rfl⟩ := Finset.mem_image.mp hp
      exact (Finset.mem_filter.mp hq).2
    · intro hp
      exact Finset.mem_image.mpr ⟨(⟨p.1,(inU p hp).1⟩,⟨p.2,(inU p hp).2⟩),by simp [E',hp],rfl⟩
  have he : E'.card = E.card := by
    rw [←im,Finset.card_image_iff.mpr (fun a _ b _ h => inj h)]
  have hn : ∀ a c b d : U, a ≠ c → b ≠ d →
      ¬(I a.val b.val ∧ I a.val d.val ∧ I c.val b.val ∧ I c.val d.val) := by
    intro a c b d hac hbd
    exact noFour a.val c.val b.val d.val
      (fun h => hac (Subtype.ext h)) (fun h => hbd (Subtype.ext h))
  have hs : ∀ u v : U, accepts clause' u v → I u.val v.val := by
    intro u v h
    apply sound
    intro k
    have h' := h k
    simpa only [clause',Finset.mem_filter,Finset.mem_univ,true_and] using h'
  have hc : ∀ p ∈ E', accepts clause' p.1 p.2 := by
    intro p hp k
    have h := cover (p.1.val,p.2.val) ((Finset.mem_filter.mp hp).2) k
    simpa only [clause',Finset.mem_filter,Finset.mem_univ,true_and] using h
  have bound := count clause' (fun u v => I u.val v.val) hn hs E' hc
  rw [he] at bound
  simpa using bound

end CNF1710
#print axioms CNF1710.count_on_support
