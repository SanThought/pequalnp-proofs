import PEqualNP.Defs.EdgeOwnership
import Mathlib.Data.Fintype.Pi
namespace Obstruction1764
open PEqualNP.CircuitLowerBounds PEqualNP.EdgeOwnership
def C : Circuit := ⟨[
  ⟨.or, [1, 3]⟩,
  ⟨.or, [5, 4]⟩,
  ⟨.or, [1, 2]⟩,
  ⟨.or, [7, 4]⟩,
  ⟨.or, [0, 2]⟩,
  ⟨.or, [9, 4]⟩,
  ⟨.or, [0, 2]⟩,
  ⟨.or, [11, 3]⟩,
  ⟨.or, [0, 1]⟩,
  ⟨.or, [13, 3]⟩,
  ⟨.and, [6, 8]⟩,
  ⟨.and, [15, 10]⟩,
  ⟨.and, [16, 12]⟩,
  ⟨.and, [17, 14]⟩], 18⟩
def G := edgeGraph 5 [(0, 1), (0, 4), (1, 2), (2, 3), (3, 4)]
instance : DecidableRel G.Adj := inferInstanceAs (DecidableRel (edgeGraph 5 _).Adj)
set_option maxRecDepth 2000 in
set_option maxHeartbeats 2000000 in
theorem owns_edge : Owns 5 C 10 0 1 := by decide
set_option maxRecDepth 2000 in
set_option maxHeartbeats 2000000 in
theorem first_unsafe : gateVal 5 C 10 (pairInput 1 3) = true ∧ ¬G.Adj 1 3 := by decide
set_option maxRecDepth 2000 in
set_option maxHeartbeats 2000000 in
theorem computes : ∀ x : Fin 5 → Bool,
 C.eval (List.ofFn x) = decide (∃ u v : Fin 5, G.Adj u v ∧ x u = true ∧ x v = true) := by decide
set_option maxRecDepth 2000 in
set_option maxHeartbeats 2000000 in
theorem all_owners_unsafe : ∀ j : Fin 14, Owns 5 C j 0 1 →
 ∃ u v : Fin 5, gateVal 5 C j (pairInput u v) = true ∧ ¬G.Adj u v := by decide
end Obstruction1764
#print axioms Obstruction1764.owns_edge
#print axioms Obstruction1764.first_unsafe
#print axioms Obstruction1764.computes

#print axioms Obstruction1764.all_owners_unsafe
