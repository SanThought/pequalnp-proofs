import Mathlib.Data.List.Chain
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Data.Fintype.Card
import Mathlib.Data.List.GetD

namespace Guard1764

/-- Along a live path, a value that starts true and ends false has a first killing edge. -/
lemma boundary {α : Type*} (bad : α → Bool) (R : α → α → Prop) :
    ∀ (a : α) (xs : List α), List.IsChain R (a :: xs) → bad a = true →
      bad (xs.getLastD a) = false →
      ∃ u v, R u v ∧ bad u = true ∧ bad v = false := by
  intro a xs
  induction xs generalizing a with
  | nil =>
    intro _ ha hb
    simp only [List.getLastD_nil] at hb
    rw [ha] at hb
    cases hb
  | cons b xs ih =>
    intro h ha hend
    obtain ⟨hab,hchain⟩ := List.isChain_cons_cons.mp h
    cases hb : bad b with
    | false => exact ⟨a,b,hab,ha,hb⟩
    | true =>
      apply ih b hchain hb
      simpa only [List.getLastD_cons] using hend

/-- A binary AND kills a live path only through its other operand. -/
lemma and_guard (aEdge bEdge aBad bBad : Bool)
    (edge : (aEdge && bEdge) = true)
    (bad : (aBad && bBad) = false) (live : aBad = true) :
    aEdge = true ∧ bEdge = true ∧ bBad = false := by
  cases aEdge <;> cases bEdge <;> cases aBad <;> cases bBad <;> simp_all

/-- A binary OR cannot kill a path through a true operand. -/
lemma or_cannot_kill (a b : Bool) (ha : a = true) : (a || b) ≠ false := by
  simp [ha]


end Guard1764
#print axioms Guard1764.boundary
#print axioms Guard1764.and_guard
