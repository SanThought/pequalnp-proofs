import Mathlib.Combinatorics.SimpleGraph.Acyclic
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Data.List.FinRange
import Mathlib.Tactic.Push
import Mathlib.Tactic.ByContra
import Lean.Elab.Tactic.Omega
import PEqualNP.Defs

namespace Zero1764

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.MetaComplexity.NestedCover

def stepWire (w : List Bool) (g : Gate) : List Bool :=
  w ++ [g.op.eval (g.inputs.map fun i => w.getD i false)]

lemma wires_eq_foldl (C : Circuit) (x : List Bool) :
    C.wires x = C.gates.foldl stepWire x := rfl

lemma foldl_stepWire_length (gs : List Gate) (w : List Bool) :
    (gs.foldl stepWire w).length = w.length + gs.length := by
  induction gs generalizing w with
  | nil => simp
  | cons g gs ih =>
    rw [List.foldl_cons, ih]
    simp [stepWire]
    omega

lemma foldl_stepWire_getD_lt (gs : List Gate) (w : List Bool) (i : ℕ) (hi : i < w.length) :
    (gs.foldl stepWire w).getD i false = w.getD i false := by
  induction gs generalizing w with
  | nil => rfl
  | cons g gs ih =>
    simp only [List.foldl_cons]
    have hlt : i < (stepWire w g).length := by simp [stepWire]; omega
    rw [ih (stepWire w g) hlt]
    simp [stepWire, List.getD_eq_getElem?_getD, List.getElem?_append_left hi]

lemma getD_ge_length (w : List Bool) (i : ℕ) (hi : w.length ≤ i) :
    w.getD i false = false := by
  simp [List.getD_eq_getElem?_getD, List.getElem?_eq_none hi]

lemma wires_length (n : ℕ) (C : Circuit) (x : Fin n → Bool) :
    (C.wires (List.ofFn x)).length = n + C.gates.length := by
  rw [wires_eq_foldl, foldl_stepWire_length, List.length_ofFn]

lemma split_gates (gs : List Gate) (j : ℕ) (hj : j < gs.length) :
    ∃ (pre post : List Gate) (gj : Gate),
      gs = pre ++ gj :: post ∧ pre.length = j ∧ gs[j]'hj = gj := by
  refine ⟨gs.take j, gs.drop (j + 1), gs[j]'hj, ?_, by simp; omega, rfl⟩
  rw [List.cons_getElem_drop_succ, List.take_append_drop]

def W (n : ℕ) (C : Circuit) (x : Fin n → Bool) (u : ℕ) : Bool :=
  (C.wires (List.ofFn x)).getD u false

lemma gateAt_eq (C : Circuit) (k : ℕ) (hk : k < C.gates.length) : gateAt C k = C.gates[k] := by
  simp [gateAt, List.getD_eq_getElem?_getD, hk]

lemma W_gate (n : ℕ) (C : Circuit) (x : Fin n → Bool) (k : ℕ) (hk : k < C.gates.length) :
    W n C x (n + k) = (gateAt C k).op.eval ((gateAt C k).inputs.map fun i =>
      if i < n + k then W n C x i else false) := by
  obtain ⟨pre, post, gj, hgs, hpre_len, hgj⟩ := split_gates C.gates k hk
  have hga : gateAt C k = gj := by rw [gateAt_eq C k hk]; exact hgj
  rw [hga]
  let w0 := pre.foldl stepWire (List.ofFn x)
  have hw0_len : w0.length = n + k := by
    simp [w0, foldl_stepWire_length, hpre_len]
  have hCj : W n C x (n + k) = gj.op.eval (gj.inputs.map fun i => w0.getD i false) := by
    simp only [W]
    rw [wires_eq_foldl, hgs, List.foldl_append, List.foldl_cons]
    rw [foldl_stepWire_getD_lt post (stepWire w0 gj) (n + k) (by simp [stepWire]; omega)]
    simp [stepWire, List.getD_eq_getElem?_getD, hw0_len]
  rw [hCj]
  congr 1
  refine List.map_congr_left fun i _ => ?_
  by_cases hi : i < n + k
  · simp only [hi, ↓reduceIte]
    simp only [W]
    rw [wires_eq_foldl, hgs, List.foldl_append]
    exact (foldl_stepWire_getD_lt (gj :: post) w0 i (by omega)).symm
  · simp only [hi, ↓reduceIte]
    exact getD_ge_length w0 i (by omega)

lemma W_input (n : ℕ) (C : Circuit) (x : Fin n → Bool) (u : ℕ) (hu : u < n) :
    W n C x u = x ⟨u, hu⟩ := by
  simp only [W]
  rw [wires_eq_foldl, foldl_stepWire_getD_lt C.gates (List.ofFn x) u (by simpa using hu)]
  simp [List.getD_eq_getElem?_getD, hu]

lemma W_or (n : ℕ) (C : Circuit) (x : Fin n → Bool) (k : ℕ) (hk : k < C.gates.length)
    (hop : (gateAt C k).op = GateOp.or) (a b : ℕ) (hin : (gateAt C k).inputs = [a, b])
    (ha : a < n + k) (hb : b < n + k) :
    W n C x (n + k) = (W n C x a || W n C x b) := by
  rw [W_gate n C x k hk, hop, hin]
  simp [GateOp.eval, ha, hb]

lemma W_and (n : ℕ) (C : Circuit) (x : Fin n → Bool) (k : ℕ) (hk : k < C.gates.length)
    (hop : (gateAt C k).op = GateOp.and) (a b : ℕ) (hin : (gateAt C k).inputs = [a, b])
    (ha : a < n + k) (hb : b < n + k) :
    W n C x (n + k) = (W n C x a && W n C x b) := by
  rw [W_gate n C x k hk, hop, hin]
  simp [GateOp.eval, ha, hb]

open PEqualNP.EdgeOwnership in
lemma coneFold_length (n : ℕ) (gs : List Gate) (cs : List (List ℕ)) :
    (gs.foldl (coneStep n) cs).length = cs.length + gs.length := by
  induction gs generalizing cs with
  | nil => simp
  | cons g gs ih =>
    rw [List.foldl_cons, ih]
    simp [coneStep]
    omega

open PEqualNP.EdgeOwnership in
lemma coneStep_getD_last (n : ℕ) (cs : List (List ℕ)) (g : Gate) :
    (coneStep n cs g).getD cs.length [] =
      (g.inputs.filter (fun w => decide (n ≤ w ∧ w < n + cs.length))).flatMap
        (fun w => (w - n) :: cs.getD (w - n) []) := by
  simp [coneStep, List.getD_eq_getElem?_getD]

open PEqualNP.EdgeOwnership in
lemma coneStep_getD_lt (n : ℕ) (cs : List (List ℕ)) (g : Gate) (m : ℕ) (hm : m < cs.length) :
    (coneStep n cs g).getD m [] = cs.getD m [] := by
  simp [coneStep, List.getD_eq_getElem?_getD, List.getElem?_append_left hm]

open PEqualNP.EdgeOwnership in
lemma coneFold_getD_lt (n : ℕ) (gs : List Gate) (cs : List (List ℕ)) (k : ℕ)
    (hk : k < cs.length) :
    (gs.foldl (coneStep n) cs).getD k [] = cs.getD k [] := by
  induction gs generalizing cs with
  | nil => rfl
  | cons g gs ih =>
    simp only [List.foldl_cons]
    rw [ih (coneStep n cs g) (by simp [coneStep]; omega)]
    exact coneStep_getD_lt n cs g k hk

open PEqualNP.EdgeOwnership in
lemma inCone_iff (n : ℕ) (C : Circuit) (i k : ℕ) (hk : k < C.gates.length) :
    InCone n C i k ↔ ∃ w ∈ (gateAt C k).inputs, n ≤ w ∧ w < n + k ∧
      (i = w - n ∨ InCone n C i (w - n)) := by
  obtain ⟨pre, post, gk, hgs, hpre_len, hgk⟩ := split_gates C.gates k hk
  have hga : gateAt C k = gk := by rw [gateAt_eq C k hk]; exact hgk
  rw [hga]
  have hc : cones n C = post.foldl (coneStep n) (coneStep n (pre.foldl (coneStep n) []) gk) := by
    simp only [cones]
    rw [hgs, List.foldl_append, List.foldl_cons]
  have hl0 : (pre.foldl (coneStep n) []).length = k := by
    rw [coneFold_length]; simp [hpre_len]
  have hl1 : (coneStep n (pre.foldl (coneStep n) []) gk).length = k + 1 := by
    simp [coneStep, hl0]
  have h1 : (cones n C).getD k [] =
      (gk.inputs.filter (fun w => decide (n ≤ w ∧ w < n + k))).flatMap
        (fun w => (w - n) :: (pre.foldl (coneStep n) []).getD (w - n) []) := by
    rw [hc, coneFold_getD_lt n post _ k (by omega)]
    have h := coneStep_getD_last n (pre.foldl (coneStep n) []) gk
    rw [hl0] at h
    exact h
  have h2 : ∀ m, m < k → (cones n C).getD m [] = (pre.foldl (coneStep n) []).getD m [] := by
    intro m hm
    rw [hc, coneFold_getD_lt n post _ m (by omega)]
    exact coneStep_getD_lt n _ gk m (by omega)
  unfold InCone
  rw [h1]
  simp only [List.mem_flatMap, List.mem_filter, decide_eq_true_eq, List.mem_cons]
  constructor
  · rintro ⟨w, ⟨hw, hn, hlt⟩, h⟩
    refine ⟨w, hw, hn, hlt, ?_⟩
    rcases h with h | h
    · exact Or.inl h
    · right
      rw [h2 (w - n) (by omega)]
      exact h
  · rintro ⟨w, hw, hn, hlt, h⟩
    refine ⟨w, ⟨hw, hn, hlt⟩, ?_⟩
    rcases h with h | h
    · exact Or.inl h
    · right
      rw [← h2 (w - n) (by omega)]
      exact h


lemma ite_true_iff (c : Prop) [Decidable c] (b : Bool) :
    (if c then b else false) = true ↔ c ∧ b = true := by
  by_cases h : c <;> simp [h]

lemma W_and_iff (n : ℕ) (C : Circuit) (x : Fin n → Bool) (k : ℕ) (hk : k < C.gates.length)
    (hop : (gateAt C k).op = GateOp.and) :
    W n C x (n + k) = true ↔ ∀ w ∈ (gateAt C k).inputs, w < n + k ∧ W n C x w = true := by
  rw [W_gate n C x k hk, hop]
  simp only [GateOp.eval, List.all_eq_true, List.mem_map, id_eq]
  constructor
  · intro h w hw
    exact (ite_true_iff _ _).mp (h _ ⟨w, hw, rfl⟩)
  · rintro h b ⟨w, hw, rfl⟩
    exact (ite_true_iff _ _).mpr (h w hw)

lemma W_or_iff (n : ℕ) (C : Circuit) (x : Fin n → Bool) (k : ℕ) (hk : k < C.gates.length)
    (hop : (gateAt C k).op = GateOp.or) :
    W n C x (n + k) = true ↔ ∃ w ∈ (gateAt C k).inputs, w < n + k ∧ W n C x w = true := by
  rw [W_gate n C x k hk, hop]
  simp only [GateOp.eval, List.any_eq_true, List.mem_map, id_eq]
  constructor
  · rintro ⟨b, ⟨w, hw, rfl⟩, h⟩
    exact ⟨w, hw, (ite_true_iff _ _).mp h⟩
  · rintro ⟨w, hw, h⟩
    exact ⟨_, ⟨w, hw, rfl⟩, (ite_true_iff _ _).mpr h⟩

open PEqualNP.EdgeOwnership in
lemma inCone_lt (n : ℕ) (C : Circuit) :
    ∀ k, k < C.gates.length → ∀ i, InCone n C i k → i < k := by
  intro k
  induction k using Nat.strong_induction_on with
  | _ k ih =>
    intro hk i hi
    obtain ⟨w, _, hn, hlt, h⟩ := (inCone_iff n C i k hk).mp hi
    rcases h with h | h
    · omega
    · have := ih (w - n) (by omega) (by omega) i h
      omega

lemma gate_mono2 (C : Circuit) (hM : Monotone2 C) (k : ℕ) (hk : k < C.gates.length) :
    ((gateAt C k).op = GateOp.and ∨ (gateAt C k).op = GateOp.or) ∧
      (gateAt C k).inputs.length ≤ 2 := by
  have hg := hM (C.gates[k]) (List.getElem_mem hk)
  rw [← gateAt_eq C k hk] at hg
  have h1 := hg.1
  rw [Set.mem_insert_iff, Set.mem_singleton_iff] at h1
  exact ⟨h1, hg.2⟩

def Dom (n : ℕ) (C : Circuit) (t : Fin n) (w : ℕ) : Prop :=
  ∀ y : Fin n → Bool, y t = true → W n C y w = true



open PEqualNP.EdgeOwnership in
lemma no_nested (n : ℕ) (C : Circuit) (h : PEqualNP.TopForm.andPairs n C = 0)
    (i j : ℕ) (hi : i < C.gates.length) (hj : j < C.gates.length)
    (hai : (gateAt C i).op = GateOp.and) (haj : (gateAt C j).op = GateOp.and) :
    ¬ InCone n C i j := by
  intro hc
  have hp : 0 < PEqualNP.TopForm.andPairs n C := by
    unfold PEqualNP.TopForm.andPairs
    exact Finset.card_pos.mpr ⟨(i,j), by simp [hi,hj,hai,haj,hc]⟩
  omega

lemma last_and_or_single (n : ℕ) (C : Circuit) (hM : Monotone2 C) (x : Fin n → Bool) :
    ∀ w, W n C x w = true →
      (∃ t : Fin n, x t = true ∧ Dom n C t w) ∨
      ∃ j, j < C.gates.length ∧ (gateAt C j).op = GateOp.and ∧
        W n C x (n+j) = true ∧
        ∀ y : Fin n → Bool, W n C y (n+j) = true → W n C y w = true := by
  intro w
  induction w using Nat.strong_induction_on with
  | ind w ih =>
    intro hx
    by_cases hwn : w < n
    · left
      refine ⟨⟨w,hwn⟩, ?_, ?_⟩
      · simpa [W_input n C x w hwn] using hx
      · intro y hy
        simpa [W_input n C y w hwn] using hy
    · by_cases hbig : n+C.gates.length ≤ w
      · have hf : W n C x w = false := by
          unfold W
          exact getD_ge_length _ _ (by rw [wires_length]; exact hbig)
        rw [hf] at hx
        cases hx
      · have hk : w-n < C.gates.length := by omega
        have hw : w = n+(w-n) := by omega
        rcases (gate_mono2 C hM (w-n) hk).1 with hop | hop
        · right
          exact ⟨w-n,hk,hop,by simpa [←hw] using hx,fun y hy => by simpa [←hw] using hy⟩
        · have hx' : W n C x (n+(w-n)) = true := by simpa [←hw] using hx
          obtain ⟨a,ha,halt,hax⟩ := (W_or_iff n C x (w-n) hk hop).mp hx'
          rcases ih a (by omega) hax with ⟨t,ht,hd⟩ | ⟨j,hj,hja,hjx,hdom⟩
          · left
            exact ⟨t,ht,fun y hy => by
              rw [hw]
              exact (W_or_iff n C y (w-n) hk hop).mpr ⟨a,ha,halt,hd y hy⟩⟩
          · right
            exact ⟨j,hj,hja,hjx,fun y hy => by
              rw [hw]
              exact (W_or_iff n C y (w-n) hk hop).mpr ⟨a,ha,halt,hdom y hy⟩⟩


open PEqualNP.EdgeOwnership in
lemma owns_of_zero (n : ℕ) (C : Circuit) (hz : PEqualNP.TopForm.andPairs n C = 0)
    (j : ℕ) (hj : j < C.gates.length) (ha : (gateAt C j).op = GateOp.and)
    (u v : Fin n) (hv : W n C (pairInput u v) (n+j) = true) : Owns n C j u v := by
  refine ⟨hj,ha,hv,?_⟩
  intro i hi hc hai
  exact False.elim (no_nested n C hz i j (by omega) hj hai ha hc)

lemma graph_pair (n : ℕ) (G : SimpleGraph (Fin n)) [DecidableRel G.Adj] (u v : Fin n)
    (h : graphFun G ∅ (PEqualNP.EdgeOwnership.pairInput u v) = true) : G.Adj u v := by
  have h' : ∃ a b, G.Adj a b ∧ PEqualNP.EdgeOwnership.pairInput u v a = true ∧
      PEqualNP.EdgeOwnership.pairInput u v b = true := by
    simpa [graphFun] using h
  obtain ⟨a,b,hab,ha,hb⟩ := h'
  have ha' : a = u ∨ a = v := by simpa [PEqualNP.EdgeOwnership.pairInput] using ha
  have hb' : b = u ∨ b = v := by simpa [PEqualNP.EdgeOwnership.pairInput] using hb
  rcases ha' with rfl | rfl <;> rcases hb' with rfl | rfl
  · exact False.elim (G.loopless.irrefl _ hab)
  · exact hab
  · exact G.symm.symm _ _ hab
  · exact False.elim (G.loopless.irrefl _ hab)


lemma output_eq (n : ℕ) (C : Circuit) (x : Fin n → Bool) :
    circuitFun n C x = W n C x C.output := rfl

open PEqualNP.EdgeOwnership in
lemma every_edge_last_and (n : ℕ) (G : SimpleGraph (Fin n)) [DecidableRel G.Adj]
    (C : Circuit) (hM : Monotone2 C) (hF : circuitFun n C = graphFun G ∅)
    (u v : Fin n) (huv : G.Adj u v) :
    ∃ j : Fin C.gates.length, (gateAt C j).op = GateOp.and ∧ gateVal n C j (pairInput u v) = true ∧
      ∀ p q : Fin n, gateVal n C j (pairInput p q) = true → G.Adj p q := by
  have hout : W n C (pairInput u v) C.output = true := by
    rw [← output_eq, hF]
    have hx : ∃ a b, G.Adj a b ∧ pairInput u v a = true ∧ pairInput u v b = true :=
      ⟨u,v,huv,by simp [pairInput],by simp [pairInput]⟩
    simpa [graphFun] using hx
  rcases last_and_or_single n C hM (pairInput u v) C.output hout with ⟨t,ht,hd⟩ | ⟨j,hj,ha,hval,hdom⟩
  · have hg : graphFun G ∅ (pairInput t t) = true := by
      rw [←hF,output_eq]
      exact hd _ (by simp [pairInput])
    have := graph_pair n G t t hg
    exact False.elim (G.loopless.irrefl _ this)
  · refine ⟨⟨j,hj⟩,ha,hval,?_⟩
    intro p q hpq
    apply graph_pair n G p q
    rw [←hF,output_eq]
    exact hdom _ hpq

open PEqualNP.EdgeOwnership in
lemma every_edge_clean_owner (n : ℕ) (G : SimpleGraph (Fin n)) [DecidableRel G.Adj]
    (C : Circuit) (hM : Monotone2 C) (hF : circuitFun n C = graphFun G ∅)
    (hz : PEqualNP.TopForm.andPairs n C = 0) (u v : Fin n) (huv : G.Adj u v) :
    ∃ j : Fin C.gates.length, Owns n C j u v ∧
      ∀ p q : Fin n, gateVal n C j (pairInput p q) = true → G.Adj p q := by
  have hout : W n C (pairInput u v) C.output = true := by
    rw [← output_eq, hF]
    have hx : ∃ a b, G.Adj a b ∧ pairInput u v a = true ∧ pairInput u v b = true :=
      ⟨u,v,huv,by simp [pairInput],by simp [pairInput]⟩
    simpa [graphFun] using hx
  rcases last_and_or_single n C hM (pairInput u v) C.output hout with ⟨t,ht,hd⟩ | ⟨j,hj,ha,hval,hdom⟩
  · have hg : graphFun G ∅ (pairInput t t) = true := by
      rw [←hF,output_eq]
      exact hd _ (by simp [pairInput])
    have := graph_pair n G t t hg
    exact False.elim (G.loopless.irrefl _ this)
  · refine ⟨⟨j,hj⟩,owns_of_zero n C hz j hj ha u v hval,?_⟩
    intro p q hpq
    apply graph_pair n G p q
    rw [←hF,output_eq]
    exact hdom _ hpq


open PEqualNP.EdgeOwnership in
lemma unclean_count_zero (n : ℕ) (G : SimpleGraph (Fin n)) [DecidableRel G.Adj]
    (C : Circuit) (hM : Monotone2 C) (hF : circuitFun n C = graphFun G ∅)
    (hz : PEqualNP.TopForm.andPairs n C = 0) :
    {e ∈ G.edgeFinset | ¬∃ u v, e = s(u,v) ∧ ∃ j : Fin C.gates.length,
      Owns n C j u v ∧ ∀ p q, gateVal n C j (pairInput p q) = true → G.Adj p q}.card = 0 := by
  classical
  apply Finset.card_eq_zero.mpr
  apply Finset.eq_empty_iff_forall_notMem.mpr
  intro e he
  obtain ⟨he,hno⟩ := Finset.mem_filter.mp he
  induction e using Sym2.inductionOn with
  | _ u v =>
    have huv : G.Adj u v := by simpa using he
    obtain ⟨j,hj,hclean⟩ := every_edge_clean_owner n G C hM hF hz u v huv
    exact hno ⟨u,v,rfl,j,hj,hclean⟩

open PEqualNP.EdgeOwnership in
lemma unclean_edge_active_nested (n : ℕ) (G : SimpleGraph (Fin n)) [DecidableRel G.Adj]
    (C : Circuit) (hM : Monotone2 C) (hF : circuitFun n C = graphFun G ∅)
    (u v : Fin n) (huv : G.Adj u v)
    (hn : ¬∃ j : Fin C.gates.length, Owns n C j u v ∧
      ∀ p q, gateVal n C j (pairInput p q) = true → G.Adj p q) :
    ∃ i j : Fin C.gates.length, i.val < j.val ∧ InCone n C i j ∧
      (gateAt C i).op = GateOp.and ∧ (gateAt C j).op = GateOp.and ∧
      gateVal n C i (pairInput u v) = true ∧ gateVal n C j (pairInput u v) = true ∧
      (∀ p q, gateVal n C j (pairInput p q) = true → G.Adj p q) := by
  classical
  obtain ⟨j,hja,hjval,hclean⟩ := every_edge_last_and n G C hM hF u v huv
  have hno : ¬Owns n C j u v := fun h => hn ⟨j,h,hclean⟩
  have hex : ∃ i, i < j.val ∧ InCone n C i j ∧ (gateAt C i).op = GateOp.and ∧
      gateVal n C i (pairInput u v) = true := by
    by_contra h
    apply hno
    refine ⟨j.isLt,hja,hjval,?_⟩
    intro i hi hc ha
    cases hv : gateVal n C i (pairInput u v)
    · rfl
    · exact False.elim (h ⟨i,hi,hc,ha,hv⟩)
  obtain ⟨i,hi,hc,ha,hval⟩ := hex
  exact ⟨⟨i,by omega⟩,j,hi,hc,ha,hja,hval,hjval,hclean⟩

end Zero1764
#print axioms Zero1764.unclean_count_zero
#print axioms Zero1764.unclean_edge_active_nested
