import itertools,json
n=10;edges={tuple(sorted((i,(i+1)%5))) for i in range(5)}|{(i,i+5) for i in range(5)}|{tuple(sorted((5+i,5+(i+2)%5))) for i in range(5)}
indeps=[]
for S in itertools.chain.from_iterable(itertools.combinations(range(n),k) for k in range(n+1)):
 if any(a in S and b in S for a,b in edges):continue
 if any(not any(a in S+(v,) and b in S+(v,) for a,b in edges) for v in range(n) if v not in S):continue
 indeps.append(S)
clauses=[sorted(set(range(n))-set(S)) for S in indeps];gs=[];outs=[]
for cl in clauses:
 a=cl[0]
 for b in cl[1:]:gs.append(('or',[a,b]));a=n+len(gs)-1
 outs.append(a)
a=outs[0]
for b in outs[1:]:gs.append(('and',[a,b]));a=n+len(gs)-1
for mask in range(1<<n):
 v=[bool(mask>>i&1) for i in range(n)]
 for op,(x,y) in gs:v.append(v[x] or v[y] if op=='or' else v[x] and v[y])
 assert v[a]==any(v[x] and v[y] for x,y in edges)
first=next(i for i,g in enumerate(gs) if g[0]=='and')
for pair in itertools.combinations(range(n),2):
 if pair in edges:continue
 v=[i in pair for i in range(n)]
 for op,(x,y) in gs:v.append(v[x] or v[y] if op=='or' else v[x] and v[y])
 if v[n+first]:print('unsafe witness',pair);break
print('clauses',clauses,'gates',gs,'output',a,'firstAND',first)
json.dump({'n':n,'edges':sorted(edges),'clauses':clauses,'gates':gs,'output':a,'first':first,'unsafe':pair},open('/tmp/pnp/prep1762/obstruction1764-petersen.json','w'))
