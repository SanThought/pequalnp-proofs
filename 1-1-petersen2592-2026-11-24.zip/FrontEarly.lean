import TenPrefix
namespace PetersenTen2592
namespace PetersenGroupBFS
set_option maxRecDepth 20000
set_option maxHeartbeats 0
def front0 : List Nat := [0]
theorem front0_eq : frontier petersenNine 0 = front0 := by
  decide +kernel
def front1 : List Nat := [0,1,2,4,8,16,32,64,128,256,512]
theorem front1_eq : frontier petersenNine 1 = front1 := by
  rw [frontier,front0_eq]
  decide +kernel
def front2 : List Nat := [0,1,2,4,8,16,32,64,128,256,512,3,5,9,17,33,65,129,257,513,6,10,18,34,66,130,258,514,12,20,36,68,132,260,516,24,40,72,136,264,520,48,80,144,272,528,96,160,288,544,192,320,576,384,640,768]
theorem front2_eq : frontier petersenNine 2 = front2 := by
  rw [frontier,front1_eq]
  decide +kernel

end PetersenGroupBFS
end PetersenTen2592
