import FrontFour
namespace PetersenTen2592
namespace PetersenGroupBFS
set_option maxRecDepth 20000
set_option maxHeartbeats 0
theorem no_step_full : ∀ m ∈ front4, fullMask petersenNine ∉ step petersenNine m := by
  decide +kernel
theorem petersen_ten_no_five : fullMask petersenNine ∉ frontier petersenNine 5 := by
  rw [frontier, front4_eq, List.mem_eraseDups, List.mem_flatMap]
  rintro ⟨m, hm, hs⟩
  exact no_step_full m hm hs
end PetersenGroupBFS
end PetersenTen2592
