# Global zero-diagonal permanent-level bound

November 24, 2026. Checked partial result for L-gct-232, not a proof of the full probe.

## The theorem

Let L be any complex linear subspace of 4 by 4 matrices. Suppose every matrix in L is symmetric, every diagonal entry is zero, and permanent(J+t)=24 for every t in L, where J is the all-ones matrix. Then dim(L) is at most 2.

This is a global bound over all zero-diagonal subspaces. It is stronger than showing that the previously exhibited two-dimensional star plane has no extension. The star plane reaches dimension 2, so the bound is sharp within the zero-diagonal class.

The assigned L-gct-232 statement allows nonzero diagonals. That case is not settled here. No upstream proof submission or accepted credit is claimed.

## Checked proof route

1. Expand the permanent along a line J+zM for a zero-diagonal symmetric M. The six off-diagonal coordinates sum to zero.
2. Eliminate the sixth coordinate. The remaining five coordinates x satisfy

       q(x) = x0^2 + x0*x1 + x0*x2 + x0*x3 + x0*x4 - x1*x4 - x2*x3 = 0.

3. The polar form 2q has the symmetric matrix

       [2  1  1  1  1]
       [1  0  0  0 -1]
       [1  0  0 -1  0]
       [1  0 -1  0  0]
       [1 -1  0  0  0]

   Its determinant is 6, so it is nondegenerate over the complex numbers.
4. Polarization makes the coordinate subspace totally isotropic. Inclusion in its orthogonal complement gives dimension at most 2 in a nondegenerate five-dimensional space.
5. The five-coordinate map from the original matrix subspace is injective. Symmetry, zero diagonals, and the zero sum recover every other matrix entry. Therefore the original subspace has dimension at most 2 too.

All five steps, including the coordinate bridge, are in `ZeroDiagonalBound.lean`. The final theorem is `Gct232Dimension.zero_diagonal_subspace_bound`. It was checked successfully with Lean 4.36.0 in the existing pequalnp-proofs Mathlib environment. `bridge4.log` records compiler output and the final axioms: propext, Classical.choice, Quot.sound. There is no sorry or new axiom. The archive contains the self-contained source and successful log.

Earlier sharp example and star-plane maximality:
https://github.com/SanThought/pequalnp-proofs/commit/b1ef137a3b47266df0e11c742c304a77d6baa85a

Earlier necessary-condition notebook, now extended by the global zero-diagonal dimension theorem:
https://github.com/SanThought/pequalnp-proofs/commit/4f1380f5c8a6ba4417959725719dbb04d2a319cf
