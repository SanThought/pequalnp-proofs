import Mathlib.LinearAlgebra.BilinearForm.Orthogonal
import Mathlib.Basic.Complex.Basic
import Mathlib.LinearAlgebra.Matrix.BilinearForm
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Linarith
import Lean.Elab.Tactic.Omega
import PEqualNP.Defs
namespace Gct232
noncomputable section

def p0 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,1,2,3] (by decide)
def p1 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,1,3,2] (by decide)
def p2 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,2,1,3] (by decide)
def p3 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,2,3,1] (by decide)
def p4 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,3,1,2] (by decide)
def p5 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,3,2,1] (by decide)
def p6 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,0,2,3] (by decide)
def p7 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,0,3,2] (by decide)
def p8 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,2,0,3] (by decide)
def p9 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,2,3,0] (by decide)
def p10 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,3,0,2] (by decide)
def p11 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,3,2,0] (by decide)
def p12 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,0,1,3] (by decide)
def p13 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,0,3,1] (by decide)
def p14 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,1,0,3] (by decide)
def p15 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,1,3,0] (by decide)
def p16 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,3,0,1] (by decide)
def p17 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,3,1,0] (by decide)
def p18 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,0,1,2] (by decide)
def p19 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,0,2,1] (by decide)
def p20 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,1,0,2] (by decide)
def p21 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,1,2,0] (by decide)
def p22 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,2,0,1] (by decide)
def p23 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,2,1,0] (by decide)

lemma all_perms : (Finset.univ : Finset (Equiv.Perm (Fin 4))) = {p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23} := by decide

lemma permanent_four (M : Matrix (Fin 4) (Fin 4) ℂ) :
    M.permanent =
    M 0 0 * M 1 1 * M 2 2 * M 3 3 +
    M 0 0 * M 1 1 * M 3 2 * M 2 3 +
    M 0 0 * M 2 1 * M 1 2 * M 3 3 +
    M 0 0 * M 2 1 * M 3 2 * M 1 3 +
    M 0 0 * M 3 1 * M 1 2 * M 2 3 +
    M 0 0 * M 3 1 * M 2 2 * M 1 3 +
    M 1 0 * M 0 1 * M 2 2 * M 3 3 +
    M 1 0 * M 0 1 * M 3 2 * M 2 3 +
    M 1 0 * M 2 1 * M 0 2 * M 3 3 +
    M 1 0 * M 2 1 * M 3 2 * M 0 3 +
    M 1 0 * M 3 1 * M 0 2 * M 2 3 +
    M 1 0 * M 3 1 * M 2 2 * M 0 3 +
    M 2 0 * M 0 1 * M 1 2 * M 3 3 +
    M 2 0 * M 0 1 * M 3 2 * M 1 3 +
    M 2 0 * M 1 1 * M 0 2 * M 3 3 +
    M 2 0 * M 1 1 * M 3 2 * M 0 3 +
    M 2 0 * M 3 1 * M 0 2 * M 1 3 +
    M 2 0 * M 3 1 * M 1 2 * M 0 3 +
    M 3 0 * M 0 1 * M 1 2 * M 2 3 +
    M 3 0 * M 0 1 * M 2 2 * M 1 3 +
    M 3 0 * M 1 1 * M 0 2 * M 2 3 +
    M 3 0 * M 1 1 * M 2 2 * M 0 3 +
    M 3 0 * M 2 1 * M 0 2 * M 1 3 +
    M 3 0 * M 2 1 * M 1 2 * M 0 3 := by
  unfold Matrix.permanent
  rw [all_perms]
  norm_num [Finset.sum_insert, Finset.sum_singleton, Fin.prod_univ_succ, Equiv.ext_iff, Fin.forall_fin_succ, Equiv.coe_ofBijective, p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23]
  <;> ring


namespace ZeroDiagonal

def off (b c d f g i : ℂ) : Matrix (Fin 4) (Fin 4) ℂ :=
  !![0,b,c,d;b,0,f,g;c,f,0,i;d,g,i,0]

def poly (b c d f g i z : ℂ) : ℂ :=
  24 + 12*(b+c+d+f+g+i)*z +
  2*(b^2+c^2+d^2+f^2+g^2+i^2+2*b*c+2*b*d+2*b*f+2*b*g+4*b*i+2*c*d+2*c*f+4*c*g+2*c*i+4*d*f+2*d*g+2*d*i+2*f*g+2*f*i+2*g*i)*z^2 +
  2*(b^2*i+b*c*f+b*c*g+b*c*i+b*d*f+b*d*g+b*d*i+b*f*i+b*g*i+b*i^2+c^2*g+c*d*f+c*d*g+c*d*i+c*f*g+c*g^2+c*g*i+d^2*f+d*f^2+d*f*g+d*f*i+f*g*i)*z^3 +
  (b^2*i^2+c^2*g^2+d^2*f^2+2*b*c*g*i+2*b*d*f*i+2*c*d*f*g)*z^4

lemma off_expansion (b c d f g i z : ℂ) :
    Matrix.permanent (Matrix.of fun r s => 1 + z * off b c d f g i r s) = poly b c d f g i z := by
  rw [permanent_four]
  norm_num [off,poly,Matrix.of_apply]
  ring

lemma necessary (b c d f g i : ℂ)
    (h : ∀ z : ℂ, Matrix.permanent (Matrix.of fun r s => 1 + z * off b c d f g i r s) = 24) :
    b+c+d+f+g+i = 0 ∧ b^2+b*c+b*d+b*f+b*g-c*g-d*f = 0 := by
  have h1 := h 1
  have hn := h (-1)
  have h2 := h 2
  have hm := h (-2)
  simp only [off_expansion,poly] at h1 hn h2 hm
  have hs : b+c+d+f+g+i = 0 := by
    linear_combination h1 / 18 - hn / 18 - h2 / 144 + hm / 144
  refine ⟨hs, ?_⟩
  have hi : i = -b-c-d-f-g := by linear_combination hs
  subst i
  linear_combination -h1 / 6 - hn / 6 + h2 / 96 + hm / 96
end ZeroDiagonal
end
end Gct232
#print axioms Gct232.ZeroDiagonal.necessary

set_option maxHeartbeats 20000
namespace Gct232Dimension
noncomputable section
open LinearMap Module

theorem isotropic_dimension (B : LinearMap.BilinForm ℂ (Fin 5 → ℂ))
    (nd : B.Nondegenerate) (L : Submodule ℂ (Fin 5 → ℂ))
    (h : ∀ x ∈ L, ∀ y ∈ L, B x y = 0) : finrank ℂ L ≤ 2 := by
  have le : L ≤ B.orthogonal L := by
    intro x hx
    rw [LinearMap.BilinForm.mem_orthogonal_iff]
    intro y hy
    exact h y hy x hx
  have dim := Submodule.finrank_mono le
  rw [B.finrank_orthogonal nd] at dim
  have ambient : finrank ℂ (Fin 5 → ℂ) = 5 := by simp
  rw [ambient] at dim
  have upper : finrank ℂ L ≤ 5 := by
    simpa using Submodule.finrank_le L
  omega

def H : Matrix (Fin 5) (Fin 5) ℂ :=
  !![2,1,1,1,1;1,0,0,0,-1;1,0,0,-1,0;1,0,-1,0,0;1,-1,0,0,0]

def q (x : Fin 5 → ℂ) : ℂ :=
  x 0 ^ 2 + x 0*x 1 + x 0*x 2 + x 0*x 3 + x 0*x 4 - x 1*x 4 - x 2*x 3

lemma diagonal (x : Fin 5 → ℂ) : H.toBilin' x x = 2 * q x := by
  simp [Matrix.toBilin'_apply, H, Fin.sum_univ_succ, q]
  ring

lemma nondegenerate : H.toBilin'.Nondegenerate := by
  apply LinearMap.BilinForm.nondegenerate_toBilin'_of_det_ne_zero'
  norm_num [H, Matrix.det_succ_row_zero, Matrix.det_fin_one, Fin.sum_univ_succ, Fin.succAbove, Fin.insertNth]

theorem quadratic_subspace_bound (L : Submodule ℂ (Fin 5 → ℂ))
    (h : ∀ x ∈ L, q x = 0) : finrank ℂ L ≤ 2 := by
  apply isotropic_dimension H.toBilin' nondegenerate L
  intro x hx y hy
  have hx0 : H.toBilin' x x = 0 := by rw [diagonal,h x hx]; ring
  have hy0 : H.toBilin' y y = 0 := by rw [diagonal,h y hy]; ring
  have hxy0 : H.toBilin' (x+y) (x+y) = 0 := by rw [diagonal,h (x+y) (L.add_mem hx hy)]; ring
  have symm : H.toBilin' y x = H.toBilin' x y := by
    simp [Matrix.toBilin'_apply,H,Fin.sum_univ_succ]
    ring
  simp only [map_add,LinearMap.add_apply] at hxy0
  rw [hx0,hy0,symm] at hxy0
  linear_combination hxy0/2
end
end Gct232Dimension
#print axioms Gct232Dimension.isotropic_dimension

#print axioms Gct232Dimension.quadratic_subspace_bound
namespace Gct232Dimension

def parametrization : (Fin 5 → ℂ) →ₗ[ℂ] (Fin 4 × Fin 4 → ℂ) where
  toFun x ij := Gct232.ZeroDiagonal.off (x 0) (x 1) (x 2) (x 3) (x 4) (-x 0-x 1-x 2-x 3-x 4) ij.1 ij.2
  map_add' x y := by
    funext ij
    rcases ij with ⟨i,j⟩
    fin_cases i <;> fin_cases j <;> simp [Gct232.ZeroDiagonal.off] <;> ring
  map_smul' c x := by
    funext ij
    rcases ij with ⟨i,j⟩
    fin_cases i <;> fin_cases j <;> simp [Gct232.ZeroDiagonal.off] <;> ring

lemma parametrization_injective : Function.Injective parametrization := by
  intro x y h
  have h01 := congrFun h (0,1)
  have h02 := congrFun h (0,2)
  have h03 := congrFun h (0,3)
  have h12 := congrFun h (1,2)
  have h13 := congrFun h (1,3)
  funext i
  fin_cases i <;> simpa [parametrization,Gct232.ZeroDiagonal.off] using (by assumption)

theorem parametrized_permanent_bound (L : Submodule ℂ (Fin 5 → ℂ))
    (h : ∀ x ∈ L, ∀ z : ℂ, Matrix.permanent (Matrix.of fun r s => 1 + z * parametrization x (r,s)) = 24) :
    Module.finrank ℂ L ≤ 2 := by
  apply quadratic_subspace_bound L
  intro x hx
  have hn := Gct232.ZeroDiagonal.necessary (x 0) (x 1) (x 2) (x 3) (x 4) (-x 0-x 1-x 2-x 3-x 4) (h x hx)
  exact hn.2
end Gct232Dimension
#print axioms Gct232Dimension.parametrized_permanent_bound
namespace Gct232Dimension
noncomputable section

def coordinates (L : Submodule ℂ (Fin 4 × Fin 4 → ℂ)) : L →ₗ[ℂ] (Fin 5 → ℂ) where
  toFun t := ![t.val (0,1),t.val (0,2),t.val (0,3),t.val (1,2),t.val (1,3)]
  map_add' x y := by ext i; fin_cases i <;> rfl
  map_smul' c x := by ext i; fin_cases i <;> rfl

lemma off_reconstruct (t : Fin 4 × Fin 4 → ℂ)
    (symm : ∀ i j, t (i,j) = t (j,i)) (zero : ∀ i, t (i,i) = 0) :
    (fun r s => t (r,s)) = Gct232.ZeroDiagonal.off (t (0,1)) (t (0,2)) (t (0,3)) (t (1,2)) (t (1,3)) (t (2,3)) := by
  funext r s
  fin_cases r <;> fin_cases s <;> simp [Gct232.ZeroDiagonal.off,zero,symm] <;> exact symm _ _

theorem zero_diagonal_subspace_bound (L : Submodule ℂ (Fin 4 × Fin 4 → ℂ))
    (symm : ∀ t ∈ L, ∀ i j, t (i,j) = t (j,i))
    (zero : ∀ t ∈ L, ∀ i, t (i,i) = 0)
    (level : ∀ t ∈ L, Matrix.permanent (Matrix.of fun r s => 1 + t (r,s)) = 24) :
    Module.finrank ℂ L ≤ 2 := by
  have hn (t : L) :
      t.val (0,1)+t.val (0,2)+t.val (0,3)+t.val (1,2)+t.val (1,3)+t.val (2,3) = 0 ∧
      q (coordinates L t) = 0 := by
    have line : ∀ z : ℂ, Matrix.permanent (Matrix.of fun r s => 1 + z * t.val (r,s)) = 24 := by
      intro z
      exact level (z • t.val) (L.smul_mem z t.property)
    have re := off_reconstruct t.val (symm t.val t.property) (zero t.val t.property)
    have hx := Gct232.ZeroDiagonal.necessary (t.val (0,1)) (t.val (0,2)) (t.val (0,3)) (t.val (1,2)) (t.val (1,3)) (t.val (2,3)) (by
      intro z
      simpa only [← re] using line z)
    exact ⟨hx.1, by simpa [q,coordinates] using hx.2⟩
  have inj : Function.Injective (coordinates L) := by
    intro x y h
    have hc : ∀ i, coordinates L x i = coordinates L y i := congrFun h
    have h0 := hc 0; have h1 := hc 1; have h2 := hc 2; have h3 := hc 3; have h4 := hc 4
    norm_num [coordinates] at h0 h1 h2 h3 h4
    have h5 : x.val (2,3) = y.val (2,3) := by linear_combination (hn x).1 - (hn y).1 - h0 - h1 - h2 - h3 - h4
    apply Subtype.ext
    funext ij
    rcases ij with ⟨i,j⟩
    have rx := off_reconstruct x.val (symm x.val x.property) (zero x.val x.property)
    have ry := off_reconstruct y.val (symm y.val y.property) (zero y.val y.property)
    have ex := congrFun (congrFun rx i) j
    have ey := congrFun (congrFun ry i) j
    rw [h0,h1,h2,h3,h4,h5] at ex
    exact ex.trans ey.symm
  have range_bound : Module.finrank ℂ (LinearMap.range (coordinates L)) ≤ 2 := by
    apply quadratic_subspace_bound
    rintro x ⟨t,rfl⟩
    exact (hn t).2
  rw [LinearMap.finrank_range_of_inj inj] at range_bound
  exact range_bound
end
end Gct232Dimension
#print axioms Gct232Dimension.zero_diagonal_subspace_bound
