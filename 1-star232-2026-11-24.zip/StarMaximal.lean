import PEqualNP.Defs
namespace Gct232
noncomputable section

def p0 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,1,2,3] (by decide)
def p1 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,1,3,2] (by decide)
def p2 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,2,1,3] (by decide)
def p3 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,2,3,1] (by decide)
def p4 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,3,1,2] (by decide)
def p5 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,3,2,1] (by decide)
def p6 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,0,2,3] (by decide)
def p7 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,0,3,2] (by decide)
def p8 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,2,0,3] (by decide)
def p9 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,2,3,0] (by decide)
def p10 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,3,0,2] (by decide)
def p11 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,3,2,0] (by decide)
def p12 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,0,1,3] (by decide)
def p13 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,0,3,1] (by decide)
def p14 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,1,0,3] (by decide)
def p15 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,1,3,0] (by decide)
def p16 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,3,0,1] (by decide)
def p17 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,3,1,0] (by decide)
def p18 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,0,1,2] (by decide)
def p19 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,0,2,1] (by decide)
def p20 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,1,0,2] (by decide)
def p21 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,1,2,0] (by decide)
def p22 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,2,0,1] (by decide)
def p23 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,2,1,0] (by decide)

lemma all_perms : (Finset.univ : Finset (Equiv.Perm (Fin 4))) = {p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23} := by decide

lemma permanent_four (M : Matrix (Fin 4) (Fin 4) ℂ) :
    M.permanent =
    M 0 0 * M 1 1 * M 2 2 * M 3 3 +
    M 0 0 * M 1 1 * M 3 2 * M 2 3 +
    M 0 0 * M 2 1 * M 1 2 * M 3 3 +
    M 0 0 * M 2 1 * M 3 2 * M 1 3 +
    M 0 0 * M 3 1 * M 1 2 * M 2 3 +
    M 0 0 * M 3 1 * M 2 2 * M 1 3 +
    M 1 0 * M 0 1 * M 2 2 * M 3 3 +
    M 1 0 * M 0 1 * M 3 2 * M 2 3 +
    M 1 0 * M 2 1 * M 0 2 * M 3 3 +
    M 1 0 * M 2 1 * M 3 2 * M 0 3 +
    M 1 0 * M 3 1 * M 0 2 * M 2 3 +
    M 1 0 * M 3 1 * M 2 2 * M 0 3 +
    M 2 0 * M 0 1 * M 1 2 * M 3 3 +
    M 2 0 * M 0 1 * M 3 2 * M 1 3 +
    M 2 0 * M 1 1 * M 0 2 * M 3 3 +
    M 2 0 * M 1 1 * M 3 2 * M 0 3 +
    M 2 0 * M 3 1 * M 0 2 * M 1 3 +
    M 2 0 * M 3 1 * M 1 2 * M 0 3 +
    M 3 0 * M 0 1 * M 1 2 * M 2 3 +
    M 3 0 * M 0 1 * M 2 2 * M 1 3 +
    M 3 0 * M 1 1 * M 0 2 * M 2 3 +
    M 3 0 * M 1 1 * M 2 2 * M 0 3 +
    M 3 0 * M 2 1 * M 0 2 * M 1 3 +
    M 3 0 * M 2 1 * M 1 2 * M 0 3 := by
  unfold Matrix.permanent
  rw [all_perms]
  norm_num [Finset.sum_insert, Finset.sum_singleton, Fin.prod_univ_succ, Equiv.ext_iff, Fin.forall_fin_succ, Equiv.coe_ofBijective, p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23]
  <;> ring

def star (a b : ℂ) : Fin 4 × Fin 4 → ℂ := fun ij => if ij = (0,1) ∨ ij = (1,0) then a else if ij = (0,2) ∨ ij = (2,0) then b else if ij = (0,3) ∨ ij = (3,0) then -a-b else 0

lemma star_constant (a b : ℂ) : Matrix.permanent (Matrix.of fun (i j : Fin 4) => (1 : ℂ)+star a b (i,j)) = 24 := by
  unfold Matrix.permanent
  rw [all_perms]
  norm_num [Finset.sum_insert, Finset.sum_singleton, Matrix.of_apply, Fin.prod_univ_succ, Equiv.ext_iff, Fin.forall_fin_succ, Equiv.coe_ofBijective, star, p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23]
  ring

def starMap : (Fin 2 → ℂ) →ₗ[ℂ] (Fin 4 × Fin 4 → ℂ) where
  toFun x := star (x 0) (x 1)
  map_add' x y := by
    funext ij
    simp only [Pi.add_apply,star]
    split_ifs <;> ring
  map_smul' c x := by
    funext ij
    simp only [Pi.smul_apply,smul_eq_mul,star,RingHom.id_apply]
    split_ifs <;> ring

lemma starMap_injective : Function.Injective starMap := by
  intro x y h
  have h0 := congrFun h (0,1)
  have h1 := congrFun h (0,2)
  have he0 : x 0 = y 0 := by simpa [starMap,star] using h0
  have he1 : x 1 = y 1 := by simpa [starMap,star] using h1
  funext i
  fin_cases i <;> assumption

lemma star_range_finrank : Module.finrank ℂ (LinearMap.range starMap) = 2 := by
  rw [LinearMap.finrank_range_of_inj starMap_injective]
  simp

lemma star_symmetric (a b : ℂ) (i j : Fin 4) : star a b (i,j) = star a b (j,i) := by
  fin_cases i <;> fin_cases j <;> simp [star]

lemma two_dimensional_boundary : ∃ L : Submodule ℂ (Fin 4 × Fin 4 → ℂ),
    Module.finrank ℂ L = 2 ∧ (∀ t ∈ L, ∀ i j : Fin 4, t (i,j) = t (j,i)) ∧
    ∀ t ∈ L, Matrix.permanent (Matrix.of fun (i j : Fin 4) => (1 : ℂ)+t (i,j)) = 24 := by
  refine ⟨LinearMap.range starMap,star_range_finrank,?_,?_⟩
  · intro t ht
    obtain ⟨x,rfl⟩ := ht
    exact star_symmetric (x 0) (x 1)
  · intro t ht
    obtain ⟨x,rfl⟩ := ht
    exact star_constant (x 0) (x 1)

def reduced (d a b c : ℂ) : Matrix (Fin 4) (Fin 4) ℂ :=
  ![![-9*d-2*(a+b+c),a,b,c],![a,d,d,d],![b,d,d,d],![c,d,d,d]]

lemma reduced_identity (d a b c z : ℂ) :
    (Matrix.of fun i j => 1+z*reduced d a b c i j).permanent =
    24 + 2*((a+b+c)^2-6*d*(a+b+c)-63*d^2)*z^2 +
      4*d*((a+b+c)^2-6*d*(a+b+c)-39*d^2)*z^3 +
      2*d^2*(-9*d+a+b+c)*(3*d+a+b+c)*z^4 := by
  rw [permanent_four]
  norm_num [reduced,Matrix.of_apply]
  ring

lemma reduced_no_extension (d a b c : ℂ)
    (h : ∀ z : ℂ, (Matrix.of fun i j => 1+z*reduced d a b c i j).permanent = 24) :
    d = 0 ∧ a+b+c = 0 := by
  have h1 := h 1
  have hn1 := h (-1)
  have h2 := h 2
  have hn2 := h (-2)
  rw [reduced_identity] at h1 hn1 h2 hn2
  have hc3 : 4*d*((a+b+c)^2-6*d*(a+b+c)-39*d^2) = 0 := by
    linear_combination (h1-hn1)/2
  have hc2 : 2*((a+b+c)^2-6*d*(a+b+c)-63*d^2) = 0 := by
    linear_combination (16*h1+16*hn1-h2-hn2)/24
  have hd3 : d^3 = 0 := by
    linear_combination (hc3-2*d*hc2)/96
  have hd : d = 0 := (pow_eq_zero_iff (by decide : (3:ℕ) ≠ 0)).mp hd3
  subst d
  have hs : (a+b+c)^2 = 0 := by linear_combination hc2/2
  exact ⟨rfl,(pow_eq_zero_iff (by decide : (2:ℕ) ≠ 0)).mp hs⟩

def direction (d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 : ℂ) : Matrix (Fin 4) (Fin 4) ℂ :=
  ![![d0,x01,x02,x03],![x01,d1,x12,x13],![x02,x12,d2,x23],![x03,x13,x23,d3]]

def derivative (d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 a b : ℂ) : ℂ :=
  a^2*d1+a^2*d3-2*a^2*x13+2*a*b*d3+2*a*b*x12-2*a*b*x13-2*a*b*x23
  -4*a*d1+4*a*d3-4*a*x12+4*a*x23+b^2*d2+b^2*d3-2*b^2*x23
  -4*b*d2+4*b*d3-4*b*x12+4*b*x13+6*d0+6*d1+6*d2+6*d3
  +12*x01+12*x02+12*x03+12*x12+12*x13+12*x23

lemma compatible_derivative (d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 a b : ℂ)
    (h : ∀ z : ℂ, (Matrix.of fun i j => 1+star a b (i,j)+z*direction d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 i j).permanent = 24) :
    derivative d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 a b = 0 := by
  have h1 := h 1
  have hn1 := h (-1)
  have h2 := h 2
  have hn2 := h (-2)
  rw [permanent_four] at h1 hn1 h2 hn2
  norm_num [Matrix.of_apply,star,direction] at h1 hn1 h2 hn2
  unfold derivative
  linear_combination (8*h1-8*hn1-h2+hn2)/12

lemma compatible_normal_form (d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 : ℂ)
    (h : ∀ a b z : ℂ, (Matrix.of fun i j => 1+star a b (i,j)+z*direction d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 i j).permanent = 24) :
    d1=d3 ∧ d2=d3 ∧ x12=d3 ∧ x13=d3 ∧ x23=d3 ∧ d0 = -9*d3-2*(x01+x02+x03) := by
  have h0 := compatible_derivative d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 0 0 (h 0 0)
  have h1 := compatible_derivative d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 1 0 (h 1 0)
  have hn1 := compatible_derivative d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 (-1) 0 (h (-1) 0)
  have h2 := compatible_derivative d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 0 1 (h 0 1)
  have hn2 := compatible_derivative d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 0 (-1) (h 0 (-1))
  have h3 := compatible_derivative d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 1 1 (h 1 1)
  norm_num [derivative] at h0 h1 hn1 h2 hn2 h3
  refine ⟨?_,?_,?_,?_,?_,?_⟩
  · linear_combination (-2/3:ℂ)*h0+(5/12:ℂ)*h1+(1/4:ℂ)*hn1+(1/3:ℂ)*h2-(1/3:ℂ)*h3
  · linear_combination (-2/3:ℂ)*h0+(1/3:ℂ)*h1+(5/12:ℂ)*h2+(1/4:ℂ)*hn2-(1/3:ℂ)*h3
  · linear_combination (5/6:ℂ)*h0-(3/8:ℂ)*h1-(1/8:ℂ)*hn1-(3/8:ℂ)*h2-(1/8:ℂ)*hn2+(1/6:ℂ)*h3
  · linear_combination (1/6:ℂ)*h0-(1/24:ℂ)*h1-(1/8:ℂ)*hn1+(1/6:ℂ)*h2-(1/6:ℂ)*h3
  · linear_combination (1/6:ℂ)*h0+(1/6:ℂ)*h1-(1/24:ℂ)*h2-(1/8:ℂ)*hn2-(1/6:ℂ)*h3
  · linear_combination (-5/6:ℂ)*h0-(1/4:ℂ)*h1+(1/4:ℂ)*hn1-(1/4:ℂ)*h2+(1/4:ℂ)*hn2+h3

lemma compatible_direction (d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 : ℂ)
    (h : ∀ a b z : ℂ, (Matrix.of fun i j => 1+star a b (i,j)+z*direction d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 i j).permanent = 24) :
    ∀ i j, direction d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 i j = star x01 x02 (i,j) := by
  obtain ⟨hd1,hd2,h12,h13,h23,hd0⟩ := compatible_normal_form d0 x01 x02 x03 d1 x12 x13 d2 x23 d3 h
  have hh : ∀ z : ℂ, (Matrix.of fun i j => 1+z*reduced d3 x01 x02 x03 i j).permanent = 24 := by
    intro z
    have hz := h 0 0 z
    simpa [star,direction,reduced,hd1,hd2,h12,h13,h23,hd0] using hz
  obtain ⟨hd,hs⟩ := reduced_no_extension d3 x01 x02 x03 hh
  have hx : x03 = -x01-x02 := by linear_combination hs
  intro i j
  fin_cases i <;> fin_cases j <;> simp [direction,star,hd1,hd2,h12,h13,h23,hd0,hd,hx] <;> ring

lemma star_maximal (L : Submodule ℂ (Fin 4 × Fin 4 → ℂ))
    (hcontains : LinearMap.range starMap ≤ L)
    (hsym : ∀ t ∈ L, ∀ i j, t (i,j) = t (j,i))
    (hperm : ∀ t ∈ L, (Matrix.of fun i j => (1 : ℂ)+t (i,j)).permanent = 24) :
    L = LinearMap.range starMap := by
  apply le_antisymm _ hcontains
  intro t ht
  have hdir : ∀ i j, direction (t (0,0)) (t (0,1)) (t (0,2)) (t (0,3)) (t (1,1)) (t (1,2)) (t (1,3)) (t (2,2)) (t (2,3)) (t (3,3)) i j = t (i,j) := by
    intro i j
    fin_cases i <;> fin_cases j <;> simp only [direction, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.cons_val_two, Matrix.cons_val_three] <;> first | rfl | exact hsym t ht _ _ | exact (hsym t ht _ _).symm
  have hall (a b z : ℂ) :
      (Matrix.of fun i j => 1+star a b (i,j)+z*direction (t (0,0)) (t (0,1)) (t (0,2)) (t (0,3)) (t (1,1)) (t (1,2)) (t (1,3)) (t (2,2)) (t (2,3)) (t (3,3)) i j).permanent = 24 := by
    have hm : star a b ∈ L := hcontains ⟨![a,b],by ext ij; simp [starMap]⟩
    have hp := hperm (star a b + z • t) (L.add_mem hm (L.smul_mem z ht))
    simpa only [Pi.add_apply,Pi.smul_apply,smul_eq_mul,hdir,add_assoc] using hp
  have he := compatible_direction (t (0,0)) (t (0,1)) (t (0,2)) (t (0,3)) (t (1,1)) (t (1,2)) (t (1,3)) (t (2,2)) (t (2,3)) (t (3,3)) hall
  refine ⟨![(t (0,1)),(t (0,2))],?_⟩
  funext ij
  obtain ⟨i,j⟩ := ij
  simpa [starMap,hdir] using (he i j).symm

end
end Gct232
#print axioms Gct232.star_constant

#print axioms Gct232.two_dimensional_boundary

#print axioms Gct232.reduced_no_extension

#print axioms Gct232.compatible_normal_form

#print axioms Gct232.star_maximal
