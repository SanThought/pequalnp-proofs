import PEqualNP.Defs
import Mathlib.Data.List.FinRange
import Mathlib.Tactic.IntervalCases

namespace SecondNot3057
open PEqualNP.CircuitLowerBounds

def normalizedPin (A : List Nat) : Nat :=
  if A.headD 10 < 10 then A.headD 10 else 10

theorem normalizedPin_bound (A : List Nat) : normalizedPin A < 11 := by
  unfold normalizedPin
  split <;> omega

theorem not_reads_first (A : List Nat) (w : List Bool) :
    GateOp.not.eval (A.map (fun i => w.getD i false)) =
      !(w.getD (A.headD w.length) false) := by
  cases A with
  | nil => simp [GateOp.eval, List.getD_eq_default]
  | cons a as => rfl

theorem second_not_normalized (A : List Nat) (x : Fin 9 → Bool) :
    let w := List.ofFn x ++ [!x 0]
    GateOp.not.eval (A.map (fun i => w.getD i false)) =
      if normalizedPin A < 9 then !(x (Fin.ofNat 9 (normalizedPin A)))
      else if normalizedPin A = 9 then x 0 else true := by
  dsimp only
  rw [not_reads_first]
  cases A with
  | nil => simp [normalizedPin, List.getD_eq_default]
  | cons a as =>
    simp only [List.headD_cons]
    by_cases ha : a < 9
    · have hn : normalizedPin (a :: as) = a := by simp [normalizedPin]; omega
      rw [hn, if_pos ha]
      rw [List.getD_append _ _ _ _ (by simpa)]
      interval_cases a <;> rfl
    · by_cases he : a = 9
      · subst a
        simp [normalizedPin]
      · have hn : normalizedPin (a :: as) = 10 := by simp [normalizedPin]; omega
        rw [hn]
        have hout : (List.ofFn x ++ [!x 0]).getD a false = false := by
          apply List.getD_eq_default
          simp
          omega
        simp only [show ¬ (10 : Nat) < 9 by decide, ite_false, show ¬ (10 : Nat) = 9 by decide]
        rw [hout]
        rfl
end SecondNot3057
#print axioms SecondNot3057.second_not_normalized
