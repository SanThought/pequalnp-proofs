import PEqualNP.Defs
import Mathlib.Tactic.NormNum
namespace Heawood2876
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
def baseline : Circuit := ⟨[
⟨.or, [7, 8]⟩,
⟨.or, [14, 10]⟩,
⟨.and, [0, 15]⟩,
⟨.or, [7, 9]⟩,
⟨.or, [17, 13]⟩,
⟨.and, [1, 18]⟩,
⟨.or, [8, 12]⟩,
⟨.or, [20, 13]⟩,
⟨.and, [2, 21]⟩,
⟨.or, [7, 11]⟩,
⟨.or, [23, 12]⟩,
⟨.and, [3, 24]⟩,
⟨.or, [10, 11]⟩,
⟨.or, [26, 13]⟩,
⟨.and, [4, 27]⟩,
⟨.or, [9, 10]⟩,
⟨.or, [29, 12]⟩,
⟨.and, [5, 30]⟩,
⟨.or, [8, 9]⟩,
⟨.or, [32, 11]⟩,
⟨.and, [6, 33]⟩,
⟨.or, [16, 19]⟩,
⟨.or, [35, 22]⟩,
⟨.or, [36, 25]⟩,
⟨.or, [37, 28]⟩,
⟨.or, [38, 31]⟩,
⟨.or, [39, 34]⟩], 40⟩
def positive : List Nat := [129, 130, 136, 257, 260, 320, 514, 544, 576, 1025, 1040, 1056, 2056, 2064, 2112, 4100, 4104, 4128, 8194, 8196, 8208]
def negative : List Nat := [127, 244, 314, 432, 541, 660, 792, 1102, 1220, 1290, 1548, 2087, 2212, 2338, 2565, 3078, 3716, 4179, 4304, 4370, 4625, 5008, 5186, 6147, 7426, 8297, 8416, 8488, 8713, 9288, 9992, 10273, 10656, 12353, 13504, 14849, 16256]
set_option maxRecDepth 10000
set_option maxHeartbeats 0
theorem budget27 : Monotone2 baseline ∧ NestedCover.ReadsBack 14 baseline ∧ baseline.size = 27 ∧ (∀ r ∈ positive, circuitFun 14 baseline (fun v => r.testBit v.val) = true) ∧ (∀ r ∈ negative, circuitFun 14 baseline (fun v => r.testBit v.val) = false) := by
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · intro g hg
    simp only [baseline, List.mem_cons, List.not_mem_nil, or_false] at hg
    rcases hg with h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h <;> subst g <;> norm_num
  · unfold NestedCover.ReadsBack NestedCover.gateAt
    change ∀ j < 27, ∀ i ∈ (baseline.gates.getD j ⟨.or, []⟩).inputs, i < 14 + j
    decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
end Heawood2876
#print axioms Heawood2876.budget27
