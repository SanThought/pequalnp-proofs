import PEqualNP.Defs
import Mathlib.Data.List.Count
import Lean.Elab.Tactic.Omega

namespace TwoLeadingNot3057
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

def nonNot (gs : List Gate) : Nat := gs.countP (fun g => match g.op with | .not => false | _ => true)

theorem count_partition (gs : List Gate) :
    nonNot gs + gs.countP (fun g => match g.op with | .not => true | _ => false) = gs.length := by
  induction gs with
  | nil => rfl
  | cons g gs ih =>
    rcases g with ⟨op,ins⟩
    cases op <;> simp_all [nonNot, List.countP_cons] <;> omega

theorem no_additional_NOT (gs : List Gate) (budget : gs.length ≤ 13)
    (lower : 13 ≤ nonNot (⟨.not,[0]⟩ :: ⟨.not,[1]⟩ :: gs)) :
    gs.length = 13 ∧ ∀ g ∈ gs, g.op ≠ .not := by
  have low : 13 ≤ nonNot gs := by simpa [nonNot] using lower
  have part := count_partition gs
  have zero : gs.countP (fun g => match g.op with | .not => true | _ => false) = 0 := by omega
  refine ⟨by omega, ?_⟩
  intro g hg hn
  have z := List.countP_eq_zero.mp zero g hg
  rw [hn] at z
  contradiction

theorem monotone_suffix (C : Circuit) (fan : FanInTwo C)
    (noNOT : ∀ g ∈ C.gates, g.op ≠ .not) : Monotone2 C := by
  intro g hg
  obtain ⟨op, len⟩ := fan g hg
  refine ⟨?_,len⟩
  rcases op with h | h | h
  · exact Or.inl h
  · exact Or.inr h
  · exact False.elim (noNOT g hg h)
end TwoLeadingNot3057
#print axioms TwoLeadingNot3057.no_additional_NOT
#print axioms TwoLeadingNot3057.monotone_suffix
