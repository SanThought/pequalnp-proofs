import PEqualNP.Defs
namespace Gct232
noncomputable section

def p0 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,1,2,3] (by decide)
def p1 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,1,3,2] (by decide)
def p2 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,2,1,3] (by decide)
def p3 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,2,3,1] (by decide)
def p4 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,3,1,2] (by decide)
def p5 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,3,2,1] (by decide)
def p6 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,0,2,3] (by decide)
def p7 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,0,3,2] (by decide)
def p8 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,2,0,3] (by decide)
def p9 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,2,3,0] (by decide)
def p10 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,3,0,2] (by decide)
def p11 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,3,2,0] (by decide)
def p12 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,0,1,3] (by decide)
def p13 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,0,3,1] (by decide)
def p14 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,1,0,3] (by decide)
def p15 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,1,3,0] (by decide)
def p16 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,3,0,1] (by decide)
def p17 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,3,1,0] (by decide)
def p18 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,0,1,2] (by decide)
def p19 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,0,2,1] (by decide)
def p20 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,1,0,2] (by decide)
def p21 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,1,2,0] (by decide)
def p22 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,2,0,1] (by decide)
def p23 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,2,1,0] (by decide)

lemma all_perms : (Finset.univ : Finset (Equiv.Perm (Fin 4))) = {p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23} := by decide

lemma permanent_four (M : Matrix (Fin 4) (Fin 4) ℂ) :
    M.permanent =
    M 0 0 * M 1 1 * M 2 2 * M 3 3 +
    M 0 0 * M 1 1 * M 3 2 * M 2 3 +
    M 0 0 * M 2 1 * M 1 2 * M 3 3 +
    M 0 0 * M 2 1 * M 3 2 * M 1 3 +
    M 0 0 * M 3 1 * M 1 2 * M 2 3 +
    M 0 0 * M 3 1 * M 2 2 * M 1 3 +
    M 1 0 * M 0 1 * M 2 2 * M 3 3 +
    M 1 0 * M 0 1 * M 3 2 * M 2 3 +
    M 1 0 * M 2 1 * M 0 2 * M 3 3 +
    M 1 0 * M 2 1 * M 3 2 * M 0 3 +
    M 1 0 * M 3 1 * M 0 2 * M 2 3 +
    M 1 0 * M 3 1 * M 2 2 * M 0 3 +
    M 2 0 * M 0 1 * M 1 2 * M 3 3 +
    M 2 0 * M 0 1 * M 3 2 * M 1 3 +
    M 2 0 * M 1 1 * M 0 2 * M 3 3 +
    M 2 0 * M 1 1 * M 3 2 * M 0 3 +
    M 2 0 * M 3 1 * M 0 2 * M 1 3 +
    M 2 0 * M 3 1 * M 1 2 * M 0 3 +
    M 3 0 * M 0 1 * M 1 2 * M 2 3 +
    M 3 0 * M 0 1 * M 2 2 * M 1 3 +
    M 3 0 * M 1 1 * M 0 2 * M 2 3 +
    M 3 0 * M 1 1 * M 2 2 * M 0 3 +
    M 3 0 * M 2 1 * M 0 2 * M 1 3 +
    M 3 0 * M 2 1 * M 1 2 * M 0 3 := by
  unfold Matrix.permanent
  rw [all_perms]
  norm_num [Finset.sum_insert, Finset.sum_singleton, Fin.prod_univ_succ, Equiv.ext_iff, Fin.forall_fin_succ, Equiv.coe_ofBijective, p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23]
  <;> ring


namespace ZeroDiagonal

def off (b c d f g i : ℂ) : Matrix (Fin 4) (Fin 4) ℂ :=
  !![0,b,c,d;b,0,f,g;c,f,0,i;d,g,i,0]

def poly (b c d f g i z : ℂ) : ℂ :=
  24 + 12*(b+c+d+f+g+i)*z +
  2*(b^2+c^2+d^2+f^2+g^2+i^2+2*b*c+2*b*d+2*b*f+2*b*g+4*b*i+2*c*d+2*c*f+4*c*g+2*c*i+4*d*f+2*d*g+2*d*i+2*f*g+2*f*i+2*g*i)*z^2 +
  2*(b^2*i+b*c*f+b*c*g+b*c*i+b*d*f+b*d*g+b*d*i+b*f*i+b*g*i+b*i^2+c^2*g+c*d*f+c*d*g+c*d*i+c*f*g+c*g^2+c*g*i+d^2*f+d*f^2+d*f*g+d*f*i+f*g*i)*z^3 +
  (b^2*i^2+c^2*g^2+d^2*f^2+2*b*c*g*i+2*b*d*f*i+2*c*d*f*g)*z^4

lemma off_expansion (b c d f g i z : ℂ) :
    Matrix.permanent (Matrix.of fun r s => 1 + z * off b c d f g i r s) = poly b c d f g i z := by
  rw [permanent_four]
  norm_num [off,poly,Matrix.of_apply]
  ring

lemma necessary (b c d f g i : ℂ)
    (h : ∀ z : ℂ, Matrix.permanent (Matrix.of fun r s => 1 + z * off b c d f g i r s) = 24) :
    b+c+d+f+g+i = 0 ∧ b^2+b*c+b*d+b*f+b*g-c*g-d*f = 0 := by
  have h1 := h 1
  have hn := h (-1)
  have h2 := h 2
  have hm := h (-2)
  simp only [off_expansion,poly] at h1 hn h2 hm
  have hs : b+c+d+f+g+i = 0 := by
    linear_combination h1 / 18 - hn / 18 - h2 / 144 + hm / 144
  refine ⟨hs, ?_⟩
  have hi : i = -b-c-d-f-g := by linear_combination hs
  subst i
  linear_combination -h1 / 6 - hn / 6 + h2 / 96 + hm / 96
end ZeroDiagonal
end
end Gct232
#print axioms Gct232.ZeroDiagonal.necessary
