import json,itertools
adj=[1408,8832,12544,6272,11264,5632,2816]
edges=[(p,l) for p in range(7) for l in range(7,14) if adj[p]>>l&1]
pos=[(1<<a)|(1<<b) for a,b in edges];neg=[]
for p in range(128):
 m=p
 for l in range(7,14):
  if not any(p>>a&1 for a,b in edges if b==l):m|=1<<l
 if all(m>>a&1 or any(m>>b&1 for c,b in edges if c==a) for a in range(7)):neg.append(m)
neg=sorted(set(neg));rows=pos+neg
assert len(pos)==21 and len(neg)==37
cases=[('or',129,130),('or',129,260),('or',129,544)]+[('and',a,b) for a,b in [(127,244),(127,432),(127,3716),(127,16256),(244,314),(244,432),(244,792),(244,1290),(244,3716),(244,7426),(432,660),(432,1220),(432,1548)]]
n=14;t=25;clauses=[];nv=0
def var():
 global nv
 nv+=1;return nv
def onehot(xs):
 clauses.append(xs)
 for a,b in itertools.combinations(xs,2):clauses.append([-a,-b])
sel=[var() for _ in cases];onehot(sel);vals=[[var() for _ in range(n+t)] for _ in rows]
for row,v in zip(rows,vals):
 for i in range(n):clauses.append([v[i] if row>>i&1 else -v[i]])
 for c,(op,x,y) in zip(sel,cases):
  a,b=v[-2:]
  if row==x:clauses.extend([[-c,a],[-c,-b]])
  if row==y:clauses.extend([[-c,-a],[-c,b]])
  if row in pos:
   if op=='or':
    if row not in [x,y]:clauses.append([-c,a,b])
   else:clauses.extend([[-c,a],[-c,b]])
  else:
   if op=='and':
    if row not in [x,y]:clauses.append([-c,-a,-b])
   else:clauses.extend([[-c,-a],[-c,-b]])
gates=[]
for j in range(t):
 k=n+j;sa=[var() for _ in range(k)];sb=[var() for _ in range(k)];op=var();onehot(sa);onehot(sb);gates.append((sa,sb,op))
 for a in range(k):
  for b in range(a):clauses.append([-sa[a],-sb[b]])
 for v in vals:
  a,b=var(),var();z=v[k]
  for i in range(k):clauses.extend([[-sa[i],-a,v[i]],[-sa[i],a,-v[i]],[-sb[i],-b,v[i]],[-sb[i],b,-v[i]]])
  clauses.extend([[-op,-z,a],[-op,-z,b],[-op,z,-a,-b],[op,z,-a],[op,z,-b],[op,-z,a,b]])
with open('/tmp/pnp/meta2876/search.cnf','w') as f:
 f.write(f'p cnf {nv} {len(clauses)}\n')
 for c in clauses:f.write(' '.join(map(str,c))+' 0\n')
json.dump({'cases':cases,'sel':sel,'gates':gates,'rows':rows},open('/tmp/pnp/meta2876/map.json','w'));print(nv,len(clauses),flush=True)
