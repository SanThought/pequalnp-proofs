import json,random,itertools,subprocess,time
p=json.load(open('/tmp/pnp/meta2876/stochastic-best.json'));rows=p['rows'];gs=p['gates'];n=14;t=26
for attempt in range(10):
 nv=0;clauses=[]
 def var():
  global nv
  nv+=1;return nv
 def onehot(xs):
  clauses.append(xs)
  for a,b in itertools.combinations(xs,2):clauses.append([-a,-b])
 vals=[[var() for _ in range(n+t)] for _ in rows];gates=[]
 for row,v in zip(rows,vals):
  for i in range(n):clauses.append([v[i] if row>>i&1 else -v[i]])
  clauses.append([v[-1] if row.bit_count()==2 else -v[-1]])
 free=set(random.sample(range(t),7))
 for j in range(t):
  k=n+j;sa=[var() for _ in range(k)];sb=[var() for _ in range(k)];op=var();onehot(sa);onehot(sb);gates.append((sa,sb,op))
  if j not in free:
   ty,a,b=gs[j];clauses.extend([[sa[a]],[sb[b]],[-op if ty else op]])
  for v in vals:
   a,b=var(),var();z=v[k]
   for i in range(k):clauses.extend([[-sa[i],-a,v[i]],[-sa[i],a,-v[i]],[-sb[i],-b,v[i]],[-sb[i],b,-v[i]]])
   clauses.extend([[-op,-z,a],[-op,-z,b],[-op,z,-a,-b],[op,z,-a],[op,z,-b],[op,-z,a,b]])
 with open('/tmp/pnp/meta2876/repair.cnf','w') as f:
  f.write(f'p cnf {nv} {len(clauses)}\n')
  for c in clauses:f.write(' '.join(map(str,c))+' 0\n')
 r=subprocess.run(['/home/sandbox/.elan/toolchains/leanprover--lean4---v4.36.0/bin/cadical','-t','9','/tmp/pnp/meta2876/repair.cnf'],capture_output=True,text=True)
 print(attempt,r.returncode,sorted(free),flush=True)
 if 's SATISFIABLE' in r.stdout:
  open('/tmp/pnp/meta2876/repair-model.log','w').write(r.stdout);json.dump(gates,open('/tmp/pnp/meta2876/repair-map.json','w'));break
