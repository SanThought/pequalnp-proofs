import json,random,time,math
p=json.load(open('/tmp/pnp/meta2876/map.json'));rows=p['rows'];n=14;target=(1<<21)-1
inp=[sum(((r>>i)&1)<<j for j,r in enumerate(rows)) for i in range(n)]
adj=[1408,8832,12544,6272,11264,5632,2816]
g=[];outs=[]
for a in range(7):
 ns=[b for b in range(7,14) if adj[a]>>b&1];g.append((1,ns[0],ns[1]));g.append((1,n+len(g)-1,ns[2]));g.append((0,a,n+len(g)-1));outs.append(n+len(g)-1)
s=outs[0]
for x in outs[1:]:g.append((1,s,x));s=n+len(g)-1
assert len(g)==27
def score(gs):
 v=inp.copy()
 for op,a,b in gs:v.append(v[a]|v[b] if op else v[a]&v[b])
 return (v[-1]^target).bit_count()
def drop(gs,d,operand):
 out=[]
 for i,(op,a,b) in enumerate(gs):
  if i==d:continue
  def rep(x):
   if x==n+d:x=gs[d][operand]
   return x-1 if x>n+d else x
  out.append((op,rep(a),rep(b)))
 return out
start=time.time();count=0;best=100;elite=[]
while time.time()-start<110:
 if elite and random.random()<.5:gs=random.choice(elite).copy()
 else:gs=drop(g,random.randrange(26),random.choice([1,2]))
 val=score(gs)
 for j in range(2200):
  count+=1;i=random.randrange(26);old=gs[i];op,a,b=old;q=random.randrange(5)
  if q==0:op=1-op
  elif q<3:a=random.randrange(n+i)
  else:b=random.randrange(n+i)
  gs[i]=(op,a,b);new=score(gs);temp=.14+.7*(1-j/2200)
  if new<=val or random.random()<math.exp((val-new)/temp):val=new
  else:gs[i]=old
  if val<best:
   best=val;print('best',best,'iters',count,'elapsed',round(time.time()-start,1),flush=True);json.dump({'gates':gs,'errors':val,'rows':rows},open('/tmp/pnp/meta2876/stochastic-best.json','w'));elite=[gs.copy()]
  elif val==best and random.random()<.001:elite=(elite+[gs.copy()])[-12:]
  if val==0:break
 if val==0:break
print('done',best,count,flush=True)
