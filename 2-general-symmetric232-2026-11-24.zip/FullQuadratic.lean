import Mathlib.LinearAlgebra.Matrix.BilinearForm
import Mathlib.LinearAlgebra.BilinearForm.Orthogonal
import PEqualNP.Defs
namespace Gct232
noncomputable section

def p0 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,1,2,3] (by decide)
def p1 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,1,3,2] (by decide)
def p2 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,2,1,3] (by decide)
def p3 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,2,3,1] (by decide)
def p4 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,3,1,2] (by decide)
def p5 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![0,3,2,1] (by decide)
def p6 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,0,2,3] (by decide)
def p7 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,0,3,2] (by decide)
def p8 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,2,0,3] (by decide)
def p9 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,2,3,0] (by decide)
def p10 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,3,0,2] (by decide)
def p11 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![1,3,2,0] (by decide)
def p12 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,0,1,3] (by decide)
def p13 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,0,3,1] (by decide)
def p14 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,1,0,3] (by decide)
def p15 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,1,3,0] (by decide)
def p16 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,3,0,1] (by decide)
def p17 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![2,3,1,0] (by decide)
def p18 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,0,1,2] (by decide)
def p19 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,0,2,1] (by decide)
def p20 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,1,0,2] (by decide)
def p21 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,1,2,0] (by decide)
def p22 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,2,0,1] (by decide)
def p23 : Equiv.Perm (Fin 4) := Equiv.ofBijective ![3,2,1,0] (by decide)

lemma all_perms : (Finset.univ : Finset (Equiv.Perm (Fin 4))) = {p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23} := by decide

lemma permanent_four (M : Matrix (Fin 4) (Fin 4) ℂ) :
    M.permanent =
    M 0 0 * M 1 1 * M 2 2 * M 3 3 +
    M 0 0 * M 1 1 * M 3 2 * M 2 3 +
    M 0 0 * M 2 1 * M 1 2 * M 3 3 +
    M 0 0 * M 2 1 * M 3 2 * M 1 3 +
    M 0 0 * M 3 1 * M 1 2 * M 2 3 +
    M 0 0 * M 3 1 * M 2 2 * M 1 3 +
    M 1 0 * M 0 1 * M 2 2 * M 3 3 +
    M 1 0 * M 0 1 * M 3 2 * M 2 3 +
    M 1 0 * M 2 1 * M 0 2 * M 3 3 +
    M 1 0 * M 2 1 * M 3 2 * M 0 3 +
    M 1 0 * M 3 1 * M 0 2 * M 2 3 +
    M 1 0 * M 3 1 * M 2 2 * M 0 3 +
    M 2 0 * M 0 1 * M 1 2 * M 3 3 +
    M 2 0 * M 0 1 * M 3 2 * M 1 3 +
    M 2 0 * M 1 1 * M 0 2 * M 3 3 +
    M 2 0 * M 1 1 * M 3 2 * M 0 3 +
    M 2 0 * M 3 1 * M 0 2 * M 1 3 +
    M 2 0 * M 3 1 * M 1 2 * M 0 3 +
    M 3 0 * M 0 1 * M 1 2 * M 2 3 +
    M 3 0 * M 0 1 * M 2 2 * M 1 3 +
    M 3 0 * M 1 1 * M 0 2 * M 2 3 +
    M 3 0 * M 1 1 * M 2 2 * M 0 3 +
    M 3 0 * M 2 1 * M 0 2 * M 1 3 +
    M 3 0 * M 2 1 * M 1 2 * M 0 3 := by
  unfold Matrix.permanent
  rw [all_perms]
  norm_num [Finset.sum_insert, Finset.sum_singleton, Fin.prod_univ_succ, Equiv.ext_iff, Fin.forall_fin_succ, Equiv.coe_ofBijective, p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23]
  <;> ring



end
end Gct232
namespace Gct232Full

noncomputable section
open LinearMap Module

theorem isotropic_dimension (B : LinearMap.BilinForm ℂ (Fin 9 → ℂ))
    (nd : B.Nondegenerate) (L : Submodule ℂ (Fin 9 → ℂ))
    (h : ∀ x ∈ L, ∀ y ∈ L, B x y = 0) : finrank ℂ L ≤ 4 := by
  have le : L ≤ B.orthogonal L := by
    intro x hx
    rw [LinearMap.BilinForm.mem_orthogonal_iff]
    intro y hy
    exact h y hy x hx
  have dim := Submodule.finrank_mono le
  rw [B.finrank_orthogonal nd] at dim
  have ambient : finrank ℂ (Fin 9 → ℂ) = 9 := by simp
  rw [ambient] at dim
  have upper : finrank ℂ L ≤ 9 := by
    simpa using Submodule.finrank_le L
  omega


def direction (a b c d e f g h i : ℂ) : Matrix (Fin 4) (Fin 4) ℂ :=
  !![a,b,c,d;b,e,f,g;c,f,h,i;d,g,i,-a - 2*b - 2*c - 2*d - e - 2*f - 2*g - h - 2*i]
def q (a b c d e f g h i : ℂ) : ℂ := -a^2 - 4*a*b - 4*a*c - 2*a*d - a*e - 2*a*f - a*h - 3*b^2 - 6*b*c - 2*b*d - 4*b*e - 6*b*f - 2*b*g - 2*b*h - 3*c^2 - 2*c*d - 2*c*e - 6*c*f - 4*c*h - 2*c*i + d^2 + 2*d*g + 2*d*i - e^2 - 4*e*f - 2*e*g - e*h - 3*f^2 - 2*f*g - 4*f*h - 2*f*i + g^2 + 2*g*i - h^2 - 2*h*i + i^2
def poly (a b c d e f g h i z : ℂ) : ℂ := 24 + 2 * q a b c d e f g h i * z^2 + (-a^2*e - 2*a^2*f - a^2*h - a*b^2 - 2*a*b*c - 2*a*b*e - 6*a*b*f - 4*a*b*h - a*c^2 - 4*a*c*e - 6*a*c*f - 2*a*c*h - 2*a*d*e - 4*a*d*f - 2*a*d*h - a*e^2 - 4*a*e*f - 2*a*e*g - 2*a*e*h - 4*a*f^2 - 2*a*f*g - 4*a*f*h - 2*a*f*i + a*g^2 + 2*a*g*i - a*h^2 - 2*a*h*i + a*i^2 - 2*b^3 - 6*b^2*c - 2*b^2*d - b^2*e - 6*b^2*f - 2*b^2*g - 4*b^2*h - 6*b*c^2 - 4*b*c*d - 6*b*c*e - 10*b*c*f - 2*b*c*g - 6*b*c*h - 2*b*c*i - 2*b*d*f + 2*b*d*g - 2*b*d*h + 2*b*d*i - 2*b*e*f - 4*b*e*h - 6*b*f^2 - 4*b*f*g - 6*b*f*h - 2*b*f*i - 2*b*g*h + 2*b*g*i - 2*b*h^2 - 4*b*h*i + 2*b*i^2 - 2*c^3 - 2*c^2*d - 4*c^2*e - 6*c^2*f - c^2*h - 2*c^2*i - 2*c*d*e - 2*c*d*f + 2*c*d*g + 2*c*d*i - 2*c*e^2 - 6*c*e*f - 4*c*e*g - 4*c*e*h - 2*c*e*i - 6*c*f^2 - 2*c*f*g - 2*c*f*h - 4*c*f*i + 2*c*g^2 + 2*c*g*i + d^2*e + 2*d^2*f + d^2*h + 2*d*e*i + 2*d*f*g + 2*d*f*i + 2*d*g*h - e^2*h - e*f^2 - 2*e*f*h - 2*e*g*h - e*h^2 - 2*e*h*i + e*i^2 - 2*f^3 - 2*f^2*g - f^2*h - 2*f^2*i + 2*f*g*i + g^2*h)*z^3 + (-a^2*e*h - a^2*f^2 - a*b^2*h - 2*a*b*c*f - 2*a*b*e*h - 2*a*b*f^2 - a*c^2*e - 2*a*c*e*h - 2*a*c*f^2 - 2*a*d*e*h - 2*a*d*f^2 - a*e^2*h - a*e*f^2 - 2*a*e*f*h - 2*a*e*g*h - a*e*h^2 - 2*a*e*h*i + a*e*i^2 - 2*a*f^3 - 2*a*f^2*g - a*f^2*h - 2*a*f^2*i + 2*a*f*g*i + a*g^2*h - 2*b^3*h - 4*b^2*c*f - 2*b^2*c*h - 2*b^2*d*h - b^2*e*h - 2*b^2*f*h - 2*b^2*g*h - b^2*h^2 - 2*b^2*h*i + b^2*i^2 - 2*b*c^2*e - 4*b*c^2*f - 4*b*c*d*f - 2*b*c*e*f - 4*b*c*f^2 - 4*b*c*f*g - 2*b*c*f*h - 4*b*c*f*i + 2*b*c*g*i + 2*b*d*f*i + 2*b*d*g*h - 2*c^3*e - 2*c^2*d*e - c^2*e^2 - 2*c^2*e*f - 2*c^2*e*g - c^2*e*h - 2*c^2*e*i + c^2*g^2 + 2*c*d*e*i + 2*c*d*f*g + d^2*e*h + d^2*f^2)*z^4
lemma expansion (a b c d e f g h i z : ℂ) : Matrix.permanent (Matrix.of fun row col => 1+z*direction a b c d e f g h i row col) = poly a b c d e f g h i z := by
  rw [Gct232.permanent_four]
  norm_num [direction,poly,q,Matrix.of_apply]
  ring
lemma necessary (a b c d e f g h i : ℂ) (hyp : ∀ z : ℂ, Matrix.permanent (Matrix.of fun row col => 1+z*direction a b c d e f g h i row col) = 24) : q a b c d e f g h i = 0 := by
  have h1 := hyp 1
  have hn := hyp (-1)
  have h2 := hyp 2
  have hm := hyp (-2)
  simp only [expansion,poly] at h1 hn h2 hm
  linear_combination h1/3 + hn/3 - h2/48 - hm/48
def H : Matrix (Fin 9) (Fin 9) ℂ := !![-2,-4,-4,-2,-1,-2,0,-1,0;-4,-6,-6,-2,-4,-6,-2,-2,0;-4,-6,-6,-2,-2,-6,0,-4,-2;-2,-2,-2,2,0,0,2,0,2;-1,-4,-2,0,-2,-4,-2,-1,0;-2,-6,-6,0,-4,-6,-2,-4,-2;0,-2,0,2,-2,-2,2,0,2;-1,-2,-4,0,-1,-4,0,-2,-2;0,0,-2,2,0,-2,2,-2,2]
lemma diagonal (x : Fin 9 → ℂ) : H.toBilin' x x = 2 * q (x 0) (x 1) (x 2) (x 3) (x 4) (x 5) (x 6) (x 7) (x 8) := by
  simp [Matrix.toBilin'_apply,H,Fin.sum_univ_succ,q]
  ring
lemma separating (x : Fin 9 → ℂ) (hx : ∀ y, H.toBilin' x y = 0) : x = 0 := by
  have h0 := hx (Pi.single 0 1)
  have h1 := hx (Pi.single 1 1)
  have h2 := hx (Pi.single 2 1)
  have h3 := hx (Pi.single 3 1)
  have h4 := hx (Pi.single 4 1)
  have h5 := hx (Pi.single 5 1)
  have h6 := hx (Pi.single 6 1)
  have h7 := hx (Pi.single 7 1)
  have h8 := hx (Pi.single 8 1)
  norm_num [Matrix.toBilin'_apply,H,Fin.sum_univ_succ,Pi.single_apply] at h0 h1 h2 h3 h4 h5 h6 h7 h8
  funext k
  fin_cases k
  · change x 0 = 0
    linear_combination (7/16)*h0 + (-11/48)*h1 + (-11/48)*h2 + (-11/48)*h3 + (5/48)*h4 + (5/48)*h5 + (5/48)*h6 + (5/48)*h7 + (5/48)*h8
  · change x 1 = 0
    linear_combination (-11/48)*h0 + (13/48)*h1 + (-1/16)*h2 + (-1/16)*h3 + (-11/48)*h4 + (-1/16)*h5 + (-1/16)*h6 + (5/48)*h7 + (5/48)*h8
  · change x 2 = 0
    linear_combination (-11/48)*h0 + (-1/16)*h1 + (13/48)*h2 + (-1/16)*h3 + (5/48)*h4 + (-1/16)*h5 + (5/48)*h6 + (-11/48)*h7 + (-1/16)*h8
  · change x 3 = 0
    linear_combination (-11/48)*h0 + (-1/16)*h1 + (-1/16)*h2 + (13/48)*h3 + (5/48)*h4 + (5/48)*h5 + (-1/16)*h6 + (5/48)*h7 + (-1/16)*h8
  · change x 4 = 0
    linear_combination (5/48)*h0 + (-11/48)*h1 + (5/48)*h2 + (5/48)*h3 + (7/16)*h4 + (-11/48)*h5 + (-11/48)*h6 + (5/48)*h7 + (5/48)*h8
  · change x 5 = 0
    linear_combination (5/48)*h0 + (-1/16)*h1 + (-1/16)*h2 + (5/48)*h3 + (-11/48)*h4 + (13/48)*h5 + (-1/16)*h6 + (-11/48)*h7 + (-1/16)*h8
  · change x 6 = 0
    linear_combination (5/48)*h0 + (-1/16)*h1 + (5/48)*h2 + (-1/16)*h3 + (-11/48)*h4 + (-1/16)*h5 + (13/48)*h6 + (5/48)*h7 + (-1/16)*h8
  · change x 7 = 0
    linear_combination (5/48)*h0 + (5/48)*h1 + (-11/48)*h2 + (5/48)*h3 + (5/48)*h4 + (-11/48)*h5 + (5/48)*h6 + (7/16)*h7 + (-11/48)*h8
  · change x 8 = 0
    linear_combination (5/48)*h0 + (5/48)*h1 + (-1/16)*h2 + (-1/16)*h3 + (5/48)*h4 + (-1/16)*h5 + (-1/16)*h6 + (-11/48)*h7 + (13/48)*h8
end
end Gct232Full
#print axioms Gct232Full.separating
namespace Gct232Full
noncomputable section
lemma form_symm (x y : Fin 9 → ℂ) : H.toBilin' y x = H.toBilin' x y := by
  simp [Matrix.toBilin'_apply,H,Fin.sum_univ_succ]
  ring
lemma nondegenerate : H.toBilin'.Nondegenerate := by
  refine ⟨separating, ?_⟩
  intro x hx
  apply separating x
  intro y
  rw [← form_symm]
  exact hx y

def Q (x : Fin 9 → ℂ) : ℂ := q (x 0) (x 1) (x 2) (x 3) (x 4) (x 5) (x 6) (x 7) (x 8)

theorem quadratic_bound (L : Submodule ℂ (Fin 9 → ℂ)) (h : ∀ x ∈ L, Q x = 0) : Module.finrank ℂ L ≤ 4 := by
  apply isotropic_dimension H.toBilin' nondegenerate L
  intro x hx y hy
  have hx0 : H.toBilin' x x = 0 := by rw [diagonal,show q (x 0) (x 1) (x 2) (x 3) (x 4) (x 5) (x 6) (x 7) (x 8) = 0 from h x hx]; ring
  have hy0 : H.toBilin' y y = 0 := by rw [diagonal,show q (y 0) (y 1) (y 2) (y 3) (y 4) (y 5) (y 6) (y 7) (y 8) = 0 from h y hy]; ring
  have hxy0 : H.toBilin' (x+y) (x+y) = 0 := by rw [diagonal,show q ((x+y) 0) ((x+y) 1) ((x+y) 2) ((x+y) 3) ((x+y) 4) ((x+y) 5) ((x+y) 6) ((x+y) 7) ((x+y) 8) = 0 from h (x+y) (L.add_mem hx hy)]; ring
  simp only [map_add,LinearMap.add_apply] at hxy0
  rw [hx0,hy0,form_symm] at hxy0
  linear_combination hxy0/2

def general (a b c d e f g h i j : ℂ) : Matrix (Fin 4) (Fin 4) ℂ := !![a,b,c,d;b,e,f,g;c,f,h,i;d,g,i,j]
lemma tangent (a b c d e f g h i j : ℂ)
    (hyp : ∀ z : ℂ, Matrix.permanent (Matrix.of fun row col => 1+z*general a b c d e f g h i j row col) = 24) :
    a+2*b+2*c+2*d+e+2*f+2*g+h+2*i+j = 0 := by
  have h1 := hyp 1
  have hn := hyp (-1)
  have h2 := hyp 2
  have hm := hyp (-2)
  rw [Gct232.permanent_four] at h1 hn h2 hm
  norm_num [general,Matrix.of_apply] at h1 hn h2 hm
  linear_combination (8*h1-8*hn-h2+hm)/72
end
end Gct232Full
#print axioms Gct232Full.quadratic_bound
#print axioms Gct232Full.tangent

namespace Gct232Full
noncomputable section
def coordinates (L : Submodule ℂ (Fin 4 × Fin 4 → ℂ)) : L →ₗ[ℂ] (Fin 9 → ℂ) where
  toFun t := ![t.val (0,0),t.val (0,1),t.val (0,2),t.val (0,3),t.val (1,1),t.val (1,2),t.val (1,3),t.val (2,2),t.val (2,3)]
  map_add' x y := by ext i; fin_cases i <;> rfl
  map_smul' c x := by ext i; fin_cases i <;> rfl
lemma reconstruct (t : Fin 4 × Fin 4 → ℂ) (symm : ∀ i j, t (i,j) = t (j,i)) :
  (fun r c => t (r,c)) = general (t (0,0)) (t (0,1)) (t (0,2)) (t (0,3)) (t (1,1)) (t (1,2)) (t (1,3)) (t (2,2)) (t (2,3)) (t (3,3)) := by
  funext r c
  fin_cases r <;> fin_cases c <;> simp [general,symm] <;> exact symm _ _
theorem symmetric_level_bound (L : Submodule ℂ (Fin 4 × Fin 4 → ℂ))
    (symm : ∀ t ∈ L, ∀ i j, t (i,j) = t (j,i))
    (level : ∀ t ∈ L, Matrix.permanent (Matrix.of fun r c => 1+t (r,c)) = 24) :
    Module.finrank ℂ L ≤ 4 := by
  have line (t : L) : ∀ z : ℂ, Matrix.permanent (Matrix.of fun r c => 1+z*general (t.val (0,0)) (t.val (0,1)) (t.val (0,2)) (t.val (0,3)) (t.val (1,1)) (t.val (1,2)) (t.val (1,3)) (t.val (2,2)) (t.val (2,3)) (t.val (3,3)) r c) = 24 := by
    intro z
    rw [← reconstruct t.val (symm t.val t.property)]
    exact level (z • t.val) (L.smul_mem z t.property)
  have ht (t : L) := tangent _ _ _ _ _ _ _ _ _ _ (line t)
  have qzero (t : L) : Q (coordinates L t) = 0 := by
    have last : t.val (3,3) = -t.val (0,0)-2*t.val (0,1)-2*t.val (0,2)-2*t.val (0,3)-t.val (1,1)-2*t.val (1,2)-2*t.val (1,3)-t.val (2,2)-2*t.val (2,3) := by linear_combination ht t
    apply necessary
    intro z
    have hl := line t z
    rw [last] at hl
    simpa [direction,general,coordinates,Q] using hl
  have inj : Function.Injective (coordinates L) := by
    intro x y eq
    have h0 := congrFun eq 0
    have h1 := congrFun eq 1
    have h2 := congrFun eq 2
    have h3 := congrFun eq 3
    have h4 := congrFun eq 4
    have h5 := congrFun eq 5
    have h6 := congrFun eq 6
    have h7 := congrFun eq 7
    have h8 := congrFun eq 8
    norm_num [coordinates] at h0 h1 h2 h3 h4 h5 h6 h7 h8
    have h9 : x.val (3,3) = y.val (3,3) := by linear_combination ht x - ht y - h0 - 2*h1 - 2*h2 - 2*h3 - h4 - 2*h5 - 2*h6 - h7 - 2*h8
    apply Subtype.ext
    funext ij
    rcases ij with ⟨r,c⟩
    have rx := congrFun (congrFun (reconstruct x.val (symm x.val x.property)) r) c
    have ry := congrFun (congrFun (reconstruct y.val (symm y.val y.property)) r) c
    rw [h0,h1,h2,h3,h4,h5,h6,h7,h8,h9] at rx
    exact rx.trans ry.symm
    
  have bound : Module.finrank ℂ (LinearMap.range (coordinates L)) ≤ 4 := by
    apply quadratic_bound
    rintro x ⟨t,rfl⟩
    exact qzero t
  rw [LinearMap.finrank_range_of_inj inj] at bound
  exact bound
end
end Gct232Full
#print axioms Gct232Full.symmetric_level_bound
