Unverified diagnostic encodings and timeout logs. No witness, no UNSAT certificate, no completeness theorem. Not a proof of any assigned statement.
