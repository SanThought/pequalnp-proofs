import itertools,json
n=9;t=15;nv=0;clauses=[]
def var():
 global nv
 nv+=1;return nv
def onehot(xs):
 clauses.append(xs)
 for a,b in itertools.combinations(xs,2):clauses.append([-a,-b])
edges=[(0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(5,7),(6,8),(8,5)]
values=[[var() for _ in range(n+t)] for _ in range(512)]
for x,v in enumerate(values):
 for i in range(1,n):clauses.append([v[i] if x>>i&1 else -v[i]])
 clauses.append([v[0] if x&1 else -v[0]])
 target=any(x>>a&1 and x>>b&1 for a,b in edges);clauses.append([v[-1] if target else -v[-1]])
gates=[];nots=[]
for j in range(t):
 k=n+j;sa=[var() for _ in range(k)];sb=[var() for _ in range(k)];op=var();nt=var();nots.append(nt);onehot(sa);onehot(sb);gates.append((sa,sb,op,nt))
 for a in range(k):
  for b in range(a):clauses.append([nt,-sa[a],-sb[b]])
 for v in values:
  a,b=var(),var();z=v[k]
  for i in range(k):clauses.extend([[-sa[i],-a,v[i]],[-sa[i],a,-v[i]],[-sb[i],-b,v[i]],[-sb[i],b,-v[i]]])
  clauses.extend([[nt,-op,-z,a],[nt,-op,-z,b],[nt,-op,z,-a,-b],[nt,op,z,-a],[nt,op,z,-b],[nt,op,-z,a,b],[-nt,-z,-a],[-nt,z,a]])
clauses.extend([[gates[0][0][0]],[gates[0][1][2]],[-gates[0][2]],[-gates[0][3]]])
for j in range(7):clauses.append([-nots[j]])
clauses.append([nots[7]])
onehot(nots[8:])
with open('/tmp/pnp/meta3202/search.cnf','w') as f:
 f.write(f'p cnf {nv} {len(clauses)}\n')
 for c in clauses:f.write(' '.join(map(str,c))+' 0\n')
json.dump({'gates':gates},open('/tmp/pnp/meta3202/search-map.json','w'));print(nv,len(clauses),flush=True)
